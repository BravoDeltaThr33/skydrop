skydrop screenshots

Live weather for ZIP code 75201, taken in a test terminal that draws the
pictures the way kitty and Ghostty do (the mode- pictures show the other drawing modes).
warnings-map.png shows a made-up severe weather day: the watches and warnings
in it are simulated. now-precipitation.png shows made-up hours of rain turning
to ice and snow, to show the Next 12 hours chart's colors.

now.png  Now
hourly.png  Hourly
ten-day.png  10-Day
radar.png  Radar
stations.png  Stations
alerts.png  Alerts
air.png  Air & UV
sky.png  Sky & Almanac
nws-radio.png  NWS & Radio
settings.png  Settings
local8s.png  Local on the 8s (L)
warnings-map.png  Alerts: warnings map (simulated outbreak)
now-precipitation.png  Now: rain turning to ice and snow (simulated)
theme-midnight.png  Theme: midnight
theme-retro8s.png  Theme: retro8s
theme-star4000.png  Theme: star4000
theme-magnetic.png  Theme: magnetic
crt-green.png  CRT mode: green phosphor
crt-amber.png  CRT mode: amber phosphor
crt-color.png  CRT mode: color phosphor
narrow-110x40.png  A smaller window (110 x 40)
mode-sixel.png  Sixel: Windows Terminal, iTerm2, foot
mode-blocks.png  Blocks: Tilix, GNOME Terminal, macOS Terminal
mode-ascii.png  Plain characters (ASCII)
index.png  all of them on one sheet
