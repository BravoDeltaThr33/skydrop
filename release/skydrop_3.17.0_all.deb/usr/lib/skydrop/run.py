"""Starts skydrop from its install folder (keeps the current folder out of sys.path)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from skydrop.cli import main  # noqa: E402

sys.exit(main())
