"""Screen renderers. Each returns a dict:

  lines         main content (scrolls)
  sticky        how many top lines stay put
  cursor        line index of the selection (kept on screen)
  footer        detail pane lines (bottom), footer_title
  side          sidebar lines (right, doesn't scroll), side_w
  fixed         True when the content is sized to the screen (no scrolling)
  rowmap        {line index: selection index} for mouse clicks
"""

import datetime as dt
import re
import textwrap
import time

from . import icons, ui
from .charts import daily_chart, daily_text, hourly_chart, hourly_text
from .fmt import wind_text
from .text import (block, seglen, fit_columns, kv_grid, labeled_wrap, padto, restyle, side_by_side, spark, stacked,
                   table_header, table_row, table_width, unit_cols, wrap, clip)
from .theme import alert_style, pop_style, temp_style, wind_style
from .util import cap, first, iso_epoch, sum_opt
from .wxmath import (LIGHTNING_LAL, OWM_AQI, OWM_AQI_STYLE, SYNODIC, aqi_cat, beaufort, comfort, compass,
                     grid_weather_text, hazard_text, heatrisk_label, moon_info, moon_name, next_moon_phases,
                     nws_wind_range, sun_altitude, sun_day, uv_cat)


def heatrisk_seg(val, short=False):
    label, style = heatrisk_label(val)
    if not label:
        return [("--", "dim")]
    if short:
        label = "None" if label.startswith("Little") else label
    return [(f"{int(round(val))} {label}", style)]


def minutely_summary(mins):
    wet = [(p or 0) >= 0.1 for _, p in mins[:61]]
    if not any(wet):
        return "No precipitation expected in the next hour"
    if wet[0]:
        if all(wet):
            return "Precipitation continuing through the hour"
        return f"Precipitation ending in about {wet.index(False)} min"
    return f"Precipitation starting in about {wet.index(True)} min"


CLOUD_WORDS = {"FEW": "few", "SCT": "scattered", "BKN": "broken", "OVC": "overcast",
               "CLR": "clear", "SKC": "clear", "VV": "obscured"}


def sky_text(layers, F):
    if not layers:
        return "--"
    parts = []
    for amount, base in layers:
        word = CLOUD_WORDS.get(amount or "", (amount or "").lower())
        parts.append(f"{word} at {F.height(base)}" if base is not None else word)
    return cap(", ".join(parts))


def with_side(L, side, side_w, printing, out=None):
    out = out or {}
    out["lines"] = L
    if side:
        if side_w and not printing:
            out["side"], out["side_w"] = side, side_w
        else:
            L.append([])
            L.extend(side)
    return out


# ----------------------------------------------------------------------------
# 1 Now
# ----------------------------------------------------------------------------

def runin(label, text, width, indent=2, hang=4):
    """'Tonight  Mostly cloudy, with ...' wrapped with a hanging indent: the label takes no column."""
    first = indent + len(label) + 2
    words = str(text or "").split()
    lines, cur, x = [], [(" " * indent + label + "  ", "label")], first
    for w in words:
        if x + len(w) > width and x > first - 0:
            lines.append(cur)
            cur, x = [(" " * hang, "text")], hang
        cur.append((w + " ", "text"))
        x += len(w) + 1
    lines.append(cur)
    return lines


def render_now(m, v, W, H, printing=False):
    F = v.fmt
    cur, obs, st = m["current"], m["obs"], m["station"]
    main_w, side_w = ui.sidebar_split(W, want=50) if not printing else (W, 0)
    L = []
    if not cur and not obs:
        busy = not m["errors"]
        L.append([("  Loading current conditions…" if busy else
                   "  Current conditions aren't available right now.", "dim")])
        L += ui.error_lines(m, ("loc", "owm_onecall", "owm_current", "om_forecast", "nws_points", "nws_station",
                                "nws_obs"), main_w)
        return {"lines": L}
    today = ui.today_row(m, F)
    now = m.get("now") or {}
    temp, feels = now.get("temp"), first(now.get("feels"), now.get("temp"))
    desc = cap(now.get("desc"))
    kind = now.get("kind") or icons.from_text(desc)
    is_day = now.get("is_day")
    if is_day is None:
        sr, ss, _ = ui.sun_pair(m, F)
        is_day = bool(sr and ss and sr <= time.time() <= ss)
    dew = now.get("dew")
    uvi = now.get("uvi")

    side = [
        [("Current conditions", "title")],
        [(desc or "--", "value")],
        [("Feels like ", "label"), (F.t(feels), temp_style(feels))],
        [("High ", "label"), (F.t(today.get("hi")), temp_style(today.get("hi"))),
         ("   Low ", "label"), (F.t(today.get("lo")), temp_style(today.get("lo")))],
    ]
    seg = [("Precip ", "label"), (F.pct(today.get("pop")), pop_style(today.get("pop")))]
    if uvi is not None:
        lab, sty = uv_cat(uvi)
        seg += [("   UV ", "label"), (f"{uvi:.0f} {lab}", sty)]
    side.append(seg)
    extra = []
    if dew is not None:
        lab, sty = comfort(dew)
        extra += [(lab, sty), (f"   dew point {F.t(dew)}", "label")]
    if today.get("heatrisk") is not None:
        extra += [("   HeatRisk ", "label")] + heatrisk_seg(today["heatrisk"])
    if extra:
        side.append(extra)
    big = ui.big_temp(v, F.t(temp))
    icon = ui.icon_block(v, kind, is_day, 13, 5, slot="nowicon") if main_w >= 60 else []
    bw = max(len(r) for r in big) + 4
    # sun and air in the free space beside the current conditions (instead of a section further down)
    sr, ss, how = ui.sun_pair(m, F)
    air = m.get("air") or {}
    info_w = max(seglen(x) for x in side) + 4
    third = []
    if main_w - (16 if icon else 1) - bw - info_w >= 24:
        third = [[("Sun and air", "title")],
                 [("Sunrise  ", "label"), (F.time(sr), "value")],
                 [("Sunset   ", "label"), (F.time(ss), "value")],
                 [("Daylight ", "label"), (F.duration(ss - sr) if sr and ss else "--", "value")]]
        if air.get("us") is not None:
            lab, sty, _ = ui.aqi_cat(air["us"])
            third.append([("Air      ", "label"), (f"{air['us']} {lab}", sty)])
    L.append([])
    for i in range(max(5, len(side), len(third))):
        row = [(" " * ((16 if icon else 1) + bw), "text")] if i >= 5 else [(" ", "text")]
        if i < 5:
            if icon:
                row += padto(icon[i], 13) + [("  ", "text")]
            row.append(((" " + (big[i] if i < len(big) else "")).ljust(bw), temp_style(temp)))
        if third:
            row += padto(side[i] if i < len(side) else [], info_w) + (third[i] if i < len(third) else [])
        else:
            row += side[i] if i < len(side) else []
        L.append(row)
    if today.get("hazards"):
        L.append([])
        L.append([("  NWS hazards today  ", "label"), (", ".join(today["hazards"]), "warn")])

    mins = m.get("minutely") or []
    if mins:
        vals = [p or 0.0 for _, p in mins[:60]]
        if main_w < 120:
            vals = [max(vals[i:i + 2]) for i in range(0, len(vals), 2)]
        L.append([])
        L.append([("  Next hour   ", "label"), (spark(vals, 0, max(2.0, max(vals)), zero="▁", ascii_only=v.ascii),
                                                "rain"), ("  " + minutely_summary(mins), "text")])
    q = m.get("min15") or []
    if q:
        q = q[:24]
        temps = [r.get("temp") for r in q]
        tv = [t for t in temps if t is not None]
        if not mins:
            L.append([])
        if tv:
            L.append([("  Next 6 hr   ", "label"), (spark(temps, ascii_only=v.ascii), temp_style(max(tv))),
                      (f"  {F.t(min(tv))} to {F.t(max(tv))} in 15-minute steps", "dim")])
        rain = [r.get("rain") for r in q]
        pops = [r.get("pop") for r in q]
        if any(p for p in pops if p):
            peak = max((p or 0, r["t"]) for p, r in zip(pops, q))
            L.append([("  Rain 6 hr   ", "label"), (spark(pops, 0, 100, zero="▁", ascii_only=v.ascii), "rain"),
                      (f"  best chance {peak[0]:.0f}% around {F.time(peak[1])}", "dim")])
        elif any(r for r in rain if r):
            peak = max((r or 0, x["t"]) for r, x in zip(rain, q))
            L.append([("  Rain 6 hr   ", "label"), (spark(rain, 0, max(1.0, peak[0]), zero="▁", ascii_only=v.ascii),
                                                    "rain"), (f"  heaviest around {F.time(peak[1])}", "dim")])
        elif not mins:
            L.append([("  Rain 6 hr   ", "label"), ("No precipitation expected in the next six hours", "dim")])
    periods = ui.periods_text(m, 3)
    if m.get("overview"):
        L.append([])
        L.append([("  Today's outlook", "title"), ("   OpenWeather summary", "dim")])
        L += wrap(m["overview"], min(main_w, 110), "text", 4)
    if periods:
        L.append([])
        L.append([("  Local forecast", "title"), ("   National Weather Service   press s to hear it", "dim")])
        for name, text in periods:
            if main_w >= 110:
                L += labeled_wrap(name, text, min(main_w, 120), lw=18, style="text", indent=4)
            else:             # narrow: the period name runs into its text, which gets the whole width
                L += runin(name, text, main_w)
    ext = ui.extended_strip(v, m, main_w, 7, "nowext")
    if ext:
        L.append([])
        L.append([("  Extended forecast", "title"), ("   press 3 for all days", "dim")])
        L += ext

    blocks = []
    cur_rows = obs_rows = []
    if cur:
        c = cur
        lab, sty = comfort(c.get("dew"))
        bf = beaufort(c.get("wind"))
        rows = [
            ("Temperature", F.t(c.get("temp"), True), temp_style(c.get("temp"))),
            ("Feels like", F.t(c.get("feels"), True), temp_style(c.get("feels"))),
            ("Humidity", F.pct(c.get("humidity"))),
            ("Dew point", [(F.t(c.get("dew"), True), "value"), ("  " + lab, sty)]),
            ("Pressure", F.press(c.get("pressure"))),
            ("Sea level", F.press(c.get("sea_level"))) if c.get("sea_level") else None,
            ("Visibility", F.vis(c.get("vis"))),
            ("Cloud cover", F.pct(c.get("clouds"))),
            ("UV index", [(f"{c['uvi']:.1f}", "value"), ("  " + uv_cat(c["uvi"])[0], uv_cat(c["uvi"])[1])])
            if c.get("uvi") is not None else None,
            ("Wind", wind_text(F, c.get("wind_deg"), c.get("wind")), wind_style(c.get("wind"))),
            ("Gusts", F.wind(c.get("gust")) if c.get("gust") else "none reported"),
            ("Wind force", f"Beaufort {bf[0]}, {bf[1].lower()}") if bf else None,
            ("Rain, last hr", F.precip(c.get("rain_1h"))) if c.get("rain_1h") is not None else None,
            ("Snow, last hr", F.precip(c.get("snow_1h"))) if c.get("snow_1h") else None,
        ]
        sub = f"as of {F.time(c.get('dt'))}" if c.get("dt") else ""
        cur_rows = rows
        blocks.append(block(c["src"] if c.get("src") != "Open-Meteo" else "Open-Meteo model", sub, rows))
    if obs:
        o = obs
        press = F.press(o.get("press"))
        trend = []
        if o.get("trend") is not None:
            tr = o["trend"]
            word = "rising" if tr > 0.6 else "falling" if tr < -0.6 else "steady"
            trend = [(f"  {word} ({F.press_delta(tr)}/3 hr)", "dim")]
        hi_lo = []
        if o.get("max24") is not None:
            hi_lo = [(F.t(o["max24"]), temp_style(o["max24"])), (" / ", "label"),
                     (F.t(o.get("min24")), temp_style(o.get("min24")))]
        rows = [
            ("Conditions", o.get("desc") or "--"),
            ("Weather", cap("; ".join(o["present"]))) if o.get("present") else None,
            ("Temperature", F.t(o.get("temp"), True), temp_style(o.get("temp"))),
            ("Dew point", F.t(o.get("dew"), True)),
            ("Humidity", F.pct(o.get("rh"))),
            ("Heat index", F.t(o["heat"], True), temp_style(o["heat"])) if o.get("heat") is not None else None,
            ("Wind chill", F.t(o["chill"], True), temp_style(o["chill"])) if o.get("chill") is not None else None,
            ("Wind", wind_text(F, o.get("wind_deg"), o.get("wind")), wind_style(o.get("wind"))),
            ("Gusts", F.wind(o["gust"]) if o.get("gust") else "none reported"),
            ("Pressure", [(press, "value")] + trend),
            ("Visibility", F.vis(o.get("vis"))),
            ("Sky", sky_text(o.get("clouds"), F)),
            ("Precip, 1 hr", F.precip(o["p1"])) if o.get("p1") is not None else None,
            ("Precip, 6 hr", F.precip(o["p6"])) if o.get("p6") is not None else None,
            ("Precip, 24 hr", [(F.precip(o["p24"]), "value"), ("  approx.", "dim")])
            if o.get("p24") is not None else None,
            ("24-hr high/low", hi_lo) if hi_lo else None,
            ("Elevation", F.height(o["elevation"])) if o.get("elevation") is not None else None,
        ]
        sub = f"observed {F.time(o['t'])}" + ("  (last full report)" if o.get("fallback") else "")
        obs_rows = rows
        blk = block(f"NWS station {st.get('id') or o.get('station_id') or ''}".strip(), sub, rows)
        sname = st.get("name") or o.get("station_name")
        if sname:
            blk.insert(1, [("  " + sname, "dim")])
        blocks.append(blk)
    if blocks:
        L.append([])
        if len(blocks) > 1 and main_w >= 96:
            L += side_by_side(blocks, main_w)
        elif main_w >= 70:
            # the readings in two or three columns rather than one long list per report
            for k, (blk, rows_) in enumerate(zip(blocks, [r for r in (cur_rows, obs_rows) if r])):
                head = [ln for ln in blk if not (len(ln) >= 2 and ln[0][1] == "label")]
                if k:
                    L.append([])
                L += [[("  ", "text")] + ln for ln in head] + kv_grid([r for r in rows_ if r], main_w, label_w=15,
                                                                      indent=4, min_col=34)
        else:
            L += stacked(blocks)

    if not third:
        L.append([])
        L.append([("  Sun and air", "title")])
        L.append([("    Sunrise ", "label"), (F.time(sr), "value"), ("    Sunset ", "label"), (F.time(ss), "value"),
                  ("    Daylight ", "label"), (F.duration(ss - sr) if sr and ss else "--", "value"),
                  (f"    from {how}" if how else "", "dim")])
        if air.get("us") is not None:
            lab, sty, _ = ui.aqi_cat(air["us"])
            L.append([("    Air quality ", "label"), (f"{air['us']}  {lab}", sty),
                      (f"    driven by {air['dominant']}; details on screen 7", "dim")])
    if obs.get("metar"):
        L.append([])
        L += labeled_wrap("  METAR", obs["metar"], main_w, lw=10, style="dim")
    pts = m.get("pts") or {}
    if pts.get("gridId"):
        tail = f"   radar {pts['radarStation']}" if pts.get("radarStation") else ""
        nwr = (pts.get("nwr") or {}).get("transmitter")
        tail += f"   NOAA radio {nwr}" if nwr else ""
        L.append([(f"  NWS office {pts['gridId']}   grid {pts.get('gridX')},{pts.get('gridY')}{tail}", "dim")])
    for name, note in (m.get("oc_notes") or {}).items():
        if name != "summary":
            L += wrap(f"OpenWeather {name}: {note}", main_w, "warn")
    L += ui.error_lines(m, ("owm_current", "om_forecast", "nws_obs", "nws_station"), main_w)

    sidebar = []
    if side_w or printing:
        sw = side_w or W
        panels = [p for p in (ui.stations_panel(m, F, sw, 5), ui.almanac_panel(m, F, sw), ui.outlook_panel(m, F, sw),
                              ui.air_panel(m, F, sw)) if p]          # sun times are already in the main area
        if v.radar is not None and not printing:
            want = max(8, min(18, int(sw * (0.42 if v.gmode != "ascii" else 0.3))))
            room = H - sum(len(p) + 1 for p in panels) - 4      # the radar shrinks before anything scrolls
            sidebar += ui.mini_radar_panel(v, m, sw, max(8, min(want, room)))
            sidebar.append([])
        for panel in panels:
            sidebar += panel + [[]]
    return with_side(L, sidebar, side_w, printing)


# ----------------------------------------------------------------------------
# 2 Hourly
# ----------------------------------------------------------------------------

HOURLY_COLS = [
    ("time", "Time", 9, "l", 0),
    ("temp", "Temp", 4, "r", 0),
    ("feels", "Feels", 5, "r", 3),
    ("desc", "Conditions", 16, "l", 0),
    ("pop", "Rain", 4, "r", 0),
    ("amt", "Amt {precip}", 6, "r", 4),
    ("wind", "Wind {wind}", 10, "l", 1),
    ("gust", "Gust", 4, "r", 5),
    ("hum", "Hum", 4, "r", 2),
    ("dew", "Dew", 4, "r", 3),
    ("cloud", "Cloud", 5, "r", 6),
    ("uv", "UV", 3, "r", 6),
    ("tstm", "Tstm", 4, "r", 7),
    ("wbgt", "WBGT", 4, "r", 9),
    ("press", "{press}", 5, "r", 8),
    ("vis", "Vis {vis}", 6, "r", 8),
]


def hour_detail(r, F, W):
    src = r.get("src")
    owm = src == "owm"
    head = []
    if owm and r.get("desc"):
        head += labeled_wrap("OpenWeather", cap(r["desc"]), W)
    if r.get("nws_desc"):
        head += labeled_wrap("NWS", r["nws_desc"], W)
    if src == "om" or r.get("om_desc"):
        head += labeled_wrap("Open-Meteo", r.get("om_desc") or r.get("desc"), W, style="dim" if src != "om" else "text")
    wx = grid_weather_text(r.get("grid_wx"))
    if wx:
        head += labeled_wrap("NWS weather", wx, W)
    hz = hazard_text(r.get("hazards"))
    if hz:
        head += labeled_wrap("NWS hazards", hz, W, style="warn")
    pairs = []
    t = F.t(r.get("temp"), True)
    if owm and r.get("nws_temp") is not None:
        t += f"  (NWS {F.t(r['nws_temp'])})"
    if r.get("trend"):
        t += f"  {r['trend']}"
    pairs.append(("Temperature", t, temp_style(r.get("temp"))))
    fl = F.t(r.get("feels"), True)
    if owm and r.get("apparent") is not None:
        fl += f"  (NWS {F.t(r['apparent'])})"
    pairs.append(("Feels like", fl, temp_style(r.get("feels"))))
    if r.get("heat_index") is not None and r["heat_index"] >= 26.7:
        pairs.append(("Heat index", F.t(r["heat_index"], True), temp_style(r["heat_index"])))
    if r.get("wind_chill") is not None and r["wind_chill"] <= 10:
        pairs.append(("Wind chill", F.t(r["wind_chill"], True), temp_style(r["wind_chill"])))
    if r.get("wbgt") is not None:
        pairs.append(("Wet bulb globe", F.t(r["wbgt"], True), temp_style(r["wbgt"])))
    if r.get("heatrisk") is not None:
        pairs.append(("HeatRisk", heatrisk_seg(r["heatrisk"])))
    lab, sty = comfort(r.get("dew"))
    pairs.append(("Dew point", [(F.t(r.get("dew"), True), "value"), ("  " + lab, sty)]))
    pairs.append(("Humidity", F.pct(r.get("hum"))))
    w = wind_text(F, r.get("wind_deg"), r.get("wind"))
    if r.get("gust"):
        w += f", gusts {F.wind(r['gust'])}"
    pairs.append(("Wind", w, wind_style(r.get("wind"))))
    if owm and r.get("nws_wind_dir"):
        nw = f"{r['nws_wind_dir']} {nws_wind_range(F, r.get('nws_wind_raw'))}".strip()
        if r.get("nws_gust"):
            nw += f", gusts {F.wind(r['nws_gust'])}"
        pairs.append(("NWS wind", nw))
    bf = beaufort(r.get("wind"))
    if bf:
        pairs.append(("Wind force", f"Beaufort {bf[0]}, {bf[1].lower()}"))
    for key, label in (("p_gust40", f"Gusts over {F.wind(40 * 0.44704)}"), ("p_gust60", f"Gusts over {F.wind(60 * 0.44704)}"),
                       ("p_ts_wind", "Tropical wind"), ("p_hu_wind", "Hurricane wind")):
        if r.get(key):
            pairs.append((label, F.pct(r[key]), "warn"))
    pp = F.pct(r.get("pop"))
    if owm and r.get("nws_pop") is not None:
        pp += f"  (NWS {r['nws_pop']:.0f}%)"
    pairs.append(("Precip chance", pp, pop_style(r.get("pop"))))
    if r.get("thunder") is not None:
        pairs.append(("Thunder chance", F.pct(r["thunder"]), "warn" if r["thunder"] >= 30 else "value"))
    if r.get("cape") is not None and r["cape"] >= 500:
        pairs.append(("Storm energy", f"CAPE {r['cape']:.0f} J/kg", "warn" if r["cape"] >= 1500 else "value"))
    if r.get("lal") is not None and r["lal"] >= 2:
        pairs.append(("Lightning", LIGHTNING_LAL.get(int(r["lal"]), f"level {r['lal']:.0f}"), "warn"))
    if owm or src == "om":
        pairs.append(("Rain / snow", f"{F.precip(r.get('rain') or 0)} / {F.precip(r.get('snow') or 0)}"))
    for key, label in (("qpf", "NWS rainfall"), ("snowfall", "NWS snowfall"), ("ice", "NWS ice")):
        blk = r.get(key)
        if blk and blk[0] is not None and (key == "qpf" or blk[0] > 0):
            pairs.append((label, f"{F.precip(blk[0])}, {F.hour(blk[1])} to {F.hour(blk[1] + blk[2])}"))
    if r.get("snow_level") is not None and r.get("temp") is not None and r["temp"] < 7:
        pairs.append(("Snow level", F.height(r["snow_level"])))
    cl = F.pct(r.get("clouds"))
    if owm and r.get("sky") is not None:
        cl += f"  (NWS {r['sky']:.0f}%)"
    pairs.append(("Cloud cover", cl))
    if r.get("ceiling") is not None:
        pairs.append(("Cloud ceiling", F.height(r["ceiling"])))
    if r.get("uvi") is not None:
        lab, sty = uv_cat(r["uvi"])
        pairs.append(("UV index", [(f"{r['uvi']:.1f}", "value"), ("  " + lab, sty)]))
    if r.get("press") is not None:
        pairs.append(("Pressure", F.press(r["press"])))
    if r.get("vis") is not None:
        pairs.append(("Visibility", F.vis(r["vis"])))
    if r.get("mixing") is not None:
        pairs.append(("Mixing height", F.height(r["mixing"])))
    if r.get("transport") is not None:
        pairs.append(("Transport wind", F.wind(r["transport"])))
    if r.get("fire_danger") is not None:
        pairs.append(("Grass fire index", f"{r['fire_danger']:.0f}"))
    if r.get("red_flag") is not None and r["red_flag"] > 0:
        pairs.append(("Red flag threat", f"{r['red_flag']:.0f}", "warn"))
    return head + kv_grid(pairs, W)


def render_hourly(m, v, W, H, printing=False):
    F = v.fmt
    rows = m.get("hourly") or []
    L = []
    if not rows:
        L.append([("  The hourly forecast hasn't loaded yet.", "dim")])
        L += ui.error_lines(m, ("owm_onecall", "nws_points", "nws_hourly", "om_forecast"), W)
        return {"lines": L}
    wide = W >= 140 and not printing
    side_w = max(44, min(60, W // 3)) if wide else 0
    main_w = W - side_w - 1 if side_w else W
    sel = max(0, min(v.sel.get("hourly", 0), len(rows) - 1))
    srcs = []
    if m.get("oc_ok"):
        srcs.append(f"OpenWeather One Call {m.get('oc_version')}")
    if any(r.get("src") == "nws" for r in rows):
        srcs.append("NWS hourly + gridpoints")
    if any(r.get("src") == "om" or r.get("om_temp") is not None for r in rows):
        srcs.append("Open-Meteo")
    L.append([(f"  Next {len(rows)} hours", "title"), ("   " + ", ".join(srcs), "dim")])
    chart_rows = 9 if H >= 13 + len(rows) else 6 if H >= 30 else 5   # a shorter chart before more scrolling
    if v.gmode in ("kitty", "sixel") and main_w >= 60 and not printing:
        cols = main_w - 4
        ch = v.images.block("hourlychart", f"hchart:{m.get('updated')}:{F.imp}:{len(rows)}:{v.theme.name}",
                            cols, chart_rows,
                            lambda mode, w, h: hourly_chart(rows, F, w, h, v.theme.rgb("bg"), theme=v.theme) if mode == "pixels"
                            else hourly_text(rows, F, w, h, mode == "ascii"))
        L += [[("  ", "text")] + ln for ln in ch]
    else:
        tl = hourly_text(rows, F, min(main_w - 4, len(rows) * 2 + 6), chart_rows - 1, v.ascii)
        L += [[("  ", "text")] + ln for ln in tl]
    temps = [r.get("temp") for r in rows]
    tv = [(t, r["t"]) for t, r in zip(temps, rows) if t is not None]
    if tv:
        hi, lo = max(tv), min(tv)
        pops = [(r.get("pop") or 0, r["t"]) for r in rows]
        peak = max(pops)
        note = (f"best rain chance {peak[0]:.0f}% at {F.hour(peak[1])}" if peak[0] >= 5
                else "little or no rain expected")
        L.append([("  ", "text"), (f"High {F.t(hi[0])} at {F.hour(hi[1])}, low {F.t(lo[0])} at {F.hour(lo[1])}; {note}", "dim")])
    cols = fit_columns(unit_cols(HOURLY_COLS, F), main_w, "desc", 32)
    L.append(table_header(cols))
    L.append([("  " + "─" * table_width(cols), "faint")])
    sticky = len(L)
    cursor = None
    rowmap = {}
    # when all the hours won't fit, the second day goes in 2-hour (or 3-hour) steps
    room = H - sticky - (0 if side_w or printing else 6)
    shown = list(range(len(rows)))
    step = 1
    if not printing and len(rows) > room and len(rows) > 24:
        step = 2 if 24 + (len(rows) - 24 + 1) // 2 + 1 <= room else 3
        shown = list(range(24)) + list(range(24, len(rows), step))
    v.hourly_shown = shown if step > 1 else None
    if step > 1 and sel not in shown:
        sel = max(x for x in shown if x <= sel)
    for i in shown:
        r = rows[i]
        if step > 1 and i >= 24:
            grp = rows[i:i + step]
            r = dict(r, pop=max((g.get("pop") or 0) for g in grp), rain=sum_opt(*[g.get("rain") for g in grp]),
                     snow=sum_opt(*[g.get("snow") for g in grp]),
                     gust=max((g["gust"] for g in grp if g.get("gust") is not None), default=None),
                     thunder=max((g["thunder"] for g in grp if g.get("thunder") is not None), default=None))
            if i == 24:
                note = f"── every {step} hours from here (the highest rain chance and gust, the total rain) "
                L.append([(("  " + note + "─" * 200)[:table_width(cols) + 2], "faint")])
        d = F.local(r["t"])
        stamp = F.hour(r["t"])
        if i == 0 or d.hour == 0:
            stamp = f"{d:%a} {stamp}"
        amt = sum_opt(r.get("rain"), r.get("snow"))
        uvi = r.get("uvi")
        cells = {
            "time": (stamp, "label"),
            "temp": (F.t(r.get("temp")), temp_style(r.get("temp"))),
            "feels": (F.t(r.get("feels")), temp_style(r.get("feels"))),
            "desc": (cap(r.get("desc")), "warn" if r.get("hazards") else "text"),
            "pop": (F.pct(r.get("pop")), pop_style(r.get("pop"))),
            "amt": (F.precip(amt, False), "rain" if amt else "dim"),
            "wind": (wind_text(F, r.get("wind_deg"), r.get("wind"), False), wind_style(r.get("wind"))),
            "gust": (F.wind(r.get("gust"), False), wind_style(r.get("gust"))),
            "hum": (F.pct(r.get("hum")), "text"),
            "dew": (F.t(r.get("dew")), comfort(r.get("dew"))[1]),
            "cloud": (F.pct(r.get("clouds")), "text"),
            "uv": ("--" if uvi is None else f"{uvi:.0f}", uv_cat(uvi)[1]),
            "tstm": (F.pct(r.get("thunder")), "warn" if (r.get("thunder") or 0) >= 30 else "text"),
            "wbgt": (F.t(r.get("wbgt")), temp_style(r.get("wbgt"))),
            "press": (F.press(r.get("press"), False), "text"),
            "vis": (F.vis(r.get("vis"), False), "text"),
        }
        chosen = i == sel and not printing
        line = table_row(cols, cells, prefix=("▸ " if chosen else "  ", "accent"))
        if chosen:
            line = [line[0]] + restyle(line[1:], "sel")
            cursor = len(L)
        rowmap[len(L)] = i
        L.append(line)
    out = {"lines": L, "sticky": sticky, "cursor": cursor, "rowmap": rowmap}
    if not printing:
        r = rows[sel]
        title = f"{F.local(r['t']):%A} {F.hour(r['t'])}"
        if side_w:
            det = [ui.section(title, side_w)] + hour_detail(r, F, side_w)
            det += [[]] + hourly_highlights(rows, F, side_w)
            det += [[]] + best_outside(m, rows, F, side_w)
            out["side"], out["side_w"] = det, side_w
        else:
            out["footer_title"] = title
            out["footer"] = hour_detail(r, F, W)
    return out


def hourly_highlights(rows, F, width):
    out = [ui.section("Highlights", width, f"next {len(rows)} hours")]
    temps = [(r["temp"], r["t"]) for r in rows if r.get("temp") is not None]
    if temps:
        hi, lo = max(temps), min(temps)
        out.append(ui.kv("Warmest", [(F.t(hi[0]), temp_style(hi[0])), (f"  {F.local(hi[1]):%a} {F.hour(hi[1])}", "dim")], width, 14))
        out.append(ui.kv("Coolest", [(F.t(lo[0]), temp_style(lo[0])), (f"  {F.local(lo[1]):%a} {F.hour(lo[1])}", "dim")], width, 14))
    wind = [(first(r.get("gust"), r.get("wind")) or 0, r) for r in rows]
    if wind:
        g, r = max(wind, key=lambda x: x[0])
        if g >= 0.5:
            out.append(ui.kv("Windiest", [(wind_text(F, r.get("wind_deg"), g), wind_style(g)),
                                          (f"  {F.local(r['t']):%a} {F.hour(r['t'])}", "dim")], width, 14))
    pops = [(r.get("pop") or 0, r["t"]) for r in rows]
    p, t = max(pops)
    out.append(ui.kv("Rain chance", [(f"{p:.0f}%", pop_style(p)), (f"  peak {F.local(t):%a} {F.hour(t)}" if p >= 5 else "  low all period", "dim")], width, 14))
    hums = [r.get("hum") for r in rows if r.get("hum") is not None]
    if hums:
        out.append(ui.kv("Humidity", f"{min(hums):.0f}% to {max(hums):.0f}%", width, 14))
    dews = [r.get("dew") for r in rows if r.get("dew") is not None]
    if dews:
        lab, sty = comfort(max(dews))
        out.append(ui.kv("Muggiest", [(F.t(max(dews)), sty), (f"  dew point, {lab.lower()}", "dim")], width, 14))
    return out


def best_outside(m, rows, F, width):
    """Daylight hours that are comfortable: mild, fairly dry and not too windy."""
    out = [ui.section("Best times outside", width)]
    good = []
    for r in rows:
        t = r.get("temp")
        tf = t * 9 / 5 + 32 if t is not None else None
        day = r.get("is_day")
        if day is None:
            sr, ss, _ = ui.sun_pair(m, F, F.local(r["t"]).date())
            day = bool(sr and ss and sr <= r["t"] < ss)
        ok = (tf is not None and day and 55 <= tf <= 85 and (r.get("pop") or 0) < 25
              and (first(r.get("gust"), r.get("wind")) or 0) < 8.9)
        good.append((r["t"], ok, tf))
    spans = []
    for t, ok, tf in good:
        if ok and spans and spans[-1][1] == t - 3600:
            spans[-1][1] = t
            spans[-1][2].append(tf)
        elif ok:
            spans.append([t, t, [tf]])
    spans = [s_ for s_ in spans if s_[1] - s_[0] >= 3600]
    if not spans:
        out += wrap("No stretch of mild, dry, calm daylight in the next couple of days.", width, "dim", 2)
        return out
    for a, b, tfs in spans[:4]:
        avg = sum(tfs) / len(tfs)
        feel = "cool" if avg < 62 else "pleasant" if avg < 76 else "warm"
        out.append(clip([("  " + f"{F.local(a):%a}".ljust(5), "label"),
                         (f"{F.hour(a)} to {F.hour(b + 3600)}", "good"), (f"   {feel}", "dim")], width))
    out += wrap(f"Daylight, {F.t(12.8)} to {F.t(29.4)}, rain chance under 25% and wind under {F.wind(8.9)}.",
                width, "faint", 2)
    return out


# ----------------------------------------------------------------------------
# 3 10-Day
# ----------------------------------------------------------------------------

DAILY_COLS = [
    ("day", "Day", 9, "l", 0),
    ("hi", "High", 4, "r", 0),
    ("lo", "Low", 4, "r", 0),
    ("bar", "", 14, "l", 3),
    ("desc", "Conditions", 18, "l", 0),
    ("pop", "Rain", 4, "r", 0),
    ("amt", "Amt {precip}", 6, "r", 2),
    ("wind", "Wind {wind}", 10, "l", 1),
    ("gust", "Gust", 4, "r", 4),
    ("hum", "Hum", 4, "r", 4),
    ("dew", "Dew", 4, "r", 4),
    ("uv", "UV", 3, "r", 2),
    ("risk", "HeatRisk", 10, "l", 5),
    ("sun", "Sunrise-sunset", 15, "l", 6),
    ("moon", "Moon", 15, "l", 7),
]


def range_bar(lo, hi, gmin, gmax, width, ascii_only=False):
    if lo is None or hi is None or gmin is None or width < 3:
        return [(" " * width, "text")]
    span = (gmax - gmin) or 1.0
    a = int(round((lo - gmin) / span * (width - 1)))
    b = max(a, int(round((hi - gmin) / span * (width - 1))))
    dot, bar = (".", "=") if ascii_only else ("·", "━")
    return [(dot * a, "faint"), (bar * (b - a + 1), temp_style(hi)), (dot * (width - b - 1), "faint")]


def day_moon(r, tz):
    frac = r.get("moon_phase")
    if frac is None:
        d = r["date"]
        noon = dt.datetime(d.year, d.month, d.day, 12, tzinfo=tz) if tz else dt.datetime(d.year, d.month, d.day, 12)
        age, _illum, name = moon_info(noon.timestamp())
        return name, age / SYNODIC
    return moon_name(frac), frac


def nws_period_line(p, F):
    wind = f"{p['dir']} {nws_wind_range(F, p.get('speed'))}".strip()
    if p.get("gust_ms"):
        wind += f", gusts {F.wind(p['gust_ms'])}"
    bits = [F.t(p["temp"]), f"precip {F.pct(p['pop'])}", f"wind {wind or '--'}"]
    if p.get("trend"):
        bits.append(f"temperature {p['trend']}")
    return "   " + "   ".join(bits)


def day_detail(r, F, W, m):
    L = []
    if r.get("error"):
        L += wrap(f"Long-range data for this day didn't load: {r['error']}", W, "warn")
    if r.get("hazards"):
        L.append([("  NWS hazards     ", "label"), (", ".join(r["hazards"]), "warn")])
    if r.get("summary"):
        L += labeled_wrap("OpenWeather", r["summary"], W)
    for key in ("nws_day", "nws_night"):
        p = r.get(key)
        if not p:
            continue
        L.append([])
        L.append([("  " + p["name"], "title")])
        L.append([(nws_period_line(p, F), "dim")])
        L += wrap(p["text"], min(W, 120), "text", 4)
    if r.get("src") == "long-range":
        L.append([])
        L += wrap("This day comes from OpenWeather's long-range daily aggregation, so it has less "
                  "detail and more uncertainty than the days before it.", W, "dim")
    if r.get("src") == "Open-Meteo":
        L.append([])
        if m.get("pts"):
            L += wrap("This day comes from the Open-Meteo model blend beyond the NWS forecast range, so expect "
                      "more uncertainty.", W, "dim")
        else:
            L += wrap("This day comes from the Open-Meteo model blend; forecasts further ahead carry "
                      "more uncertainty.", W, "dim")
    if r.get("partial"):
        L += wrap("OpenWeather's free 3-hour forecast only covers part of this day.", W, "dim")
    temps = [("morning", "morn"), ("afternoon", "noon"), ("evening", "eve"), ("night", "night")]
    L.append([])
    if any(r.get(k) is not None for _, k in temps):
        seg = [("  " + "Temperature".ljust(16), "label")]
        for name, k in temps:
            seg += [(name + " ", "label"), (F.t(r.get(k)), temp_style(r.get(k))), ("   ", "text")]
        L.append(seg)
    dew_lab, dew_sty = comfort(r.get("dew"))
    pairs = [
        ("High / low", f"{F.t(r.get('hi'))} / {F.t(r.get('lo'))}"),
        ("Feels like", f"{F.t(r.get('f_hi'))} / {F.t(r.get('f_lo'))}") if r.get("f_hi") is not None else None,
        ("HeatRisk", heatrisk_seg(r["heatrisk"])) if r.get("heatrisk") is not None else None,
        ("Precip chance", F.pct(r.get("pop")), pop_style(r.get("pop"))),
        ("Rain", F.precip(r.get("rain")) + ("  (Open-Meteo)" if r.get("rain_src") else "")) if r.get("rain") is not None else None,
        ("Snow", F.precip(r.get("snow"))) if r.get("snow") else None,
        ("Precip hours", f"{r['precip_hours']:.0f}") if r.get("precip_hours") else None,
        ("Wind", wind_text(F, r.get("wind_deg"), r.get("wind")), wind_style(r.get("wind"))),
        ("Gusts", F.wind(r.get("gust"))) if r.get("gust") is not None else None,
        ("Humidity", F.pct(r.get("hum"))) if r.get("hum") is not None else None,
        ("Dew point", [(F.t(r.get("dew"), True), "value"), ("  " + dew_lab, dew_sty)]) if r.get("dew") is not None else None,
        ("Pressure", F.press(r.get("press"))) if r.get("press") is not None else None,
        ("Cloud cover", F.pct(r.get("clouds"))) if r.get("clouds") is not None else None,
        ("Sunshine", F.duration(r["sunshine"])) if r.get("sunshine") is not None else None,
    ]
    if r.get("uvi") is not None:
        lab, sty = uv_cat(r["uvi"])
        pairs.append(("UV index", [(f"{r['uvi']:.1f}", "value"), ("  " + lab, sty)]))
    sr, ss = r.get("sunrise"), r.get("sunset")
    if not sr or not ss:
        sr, ss, _how = ui.sun_pair(m, F, r["date"])
    pairs.append(("Sunrise/sunset", f"{F.time(sr)} / {F.time(ss)}"))
    pairs.append(("Daylight", F.duration(ss - sr) if sr and ss else "--"))
    if r.get("moonrise") or r.get("moonset"):
        pairs.append(("Moonrise/set", f"{F.time(r.get('moonrise'))} / {F.time(r.get('moonset'))}"))
    pairs.append(("Moon", day_moon(r, F.tz)[0]))
    L += kv_grid([p for p in pairs if p], W)
    return L


def render_daily(m, v, W, H, printing=False):
    F = v.fmt
    rows = m.get("daily") or []
    L = []
    if not rows:
        L.append([("  The extended forecast hasn't loaded yet.", "dim")])
        L += ui.error_lines(m, ("owm_onecall", "owm_forecast", "nws_points", "nws_forecast", "om_forecast"), W)
        return {"lines": L}
    wide = W >= 140 and not printing
    side_w = max(46, min(64, W // 3)) if wide else 0
    main_w = W - side_w - 1 if side_w else W
    sel = max(0, min(v.sel.get("daily", 0), len(rows) - 1))
    srcs = sorted({r.get("src") for r in rows if r.get("src")}, key=lambda s: (s != "NWS", s))
    L.append([(f"  {len(rows)}-day forecast", "title"), ("   " + ", ".join(srcs), "dim")])
    strip = ui.extended_strip(v, m, main_w, None, "dayicon") if not printing else []
    if strip and H >= 30:
        L.append([])
        L += strip
    L.append([])
    cols = fit_columns(unit_cols(DAILY_COLS, F), main_w, "desc", 34)
    his = [r["hi"] for r in rows if r.get("hi") is not None]
    los = [r["lo"] for r in rows if r.get("lo") is not None]
    temps = los + his
    gmin, gmax = (min(temps), max(temps)) if temps else (None, None)
    barw = next((c[2] for c in cols if c[0] == "bar"), 0)
    L.append(table_header(cols))
    L.append([("  " + "─" * table_width(cols), "faint")])
    sticky = len(L) if H >= 40 or not strip else 0
    cursor = None
    rowmap = {}
    for i, r in enumerate(rows):
        amt = sum_opt(r.get("rain"), r.get("snow"))
        sr, ss = r.get("sunrise"), r.get("sunset")
        if not sr or not ss:
            sr, ss, _how = ui.sun_pair(m, F, r["date"])
        uvi = r.get("uvi")
        faded = r.get("src") in ("long-range", "Open-Meteo")
        risk = r.get("heatrisk")
        desc = cap(r.get("desc")) or ("unavailable" if r.get("error") else "--")
        cells = {
            "day": (F.day_label(r["date"]), "label"),
            "hi": (F.t(r.get("hi")), temp_style(r.get("hi"))),
            "lo": (F.t(r.get("lo")), temp_style(r.get("lo"))),
            "bar": range_bar(r.get("lo"), r.get("hi"), gmin, gmax, barw, v.ascii),
            "desc": (("▲ " + desc) if r.get("hazards") else desc,
                     "warn" if r.get("hazards") else "dim" if faded else "text"),
            "pop": (F.pct(r.get("pop")), pop_style(r.get("pop"))),
            "amt": (F.precip(amt, False), "rain" if amt else "dim"),
            "wind": (wind_text(F, r.get("wind_deg"), r.get("wind"), False), wind_style(r.get("wind"))),
            "gust": (F.wind(r.get("gust"), False), wind_style(r.get("gust"))),
            "hum": (F.pct(r.get("hum")), "text"),
            "dew": (F.t(r.get("dew")), comfort(r.get("dew"))[1]),
            "uv": ("--" if uvi is None else f"{uvi:.0f}", uv_cat(uvi)[1]),
            "risk": heatrisk_seg(risk, short=True) if risk is not None else ("--", "dim"),
            "sun": (f"{F.time(sr)}-{F.time(ss)}".replace(" AM", "a").replace(" PM", "p"), "text"),
            "moon": (day_moon(r, F.tz)[0], "text"),
        }
        chosen = i == sel and not printing
        line = table_row(cols, cells, prefix=("▸ " if chosen else "  ", "accent"))
        if chosen:
            line = [line[0]] + restyle(line[1:], "sel")
            cursor = len(L)
        rowmap[len(L)] = i
        L.append(line)
    ins = outlook_insights(m, rows, F, main_w)
    if ins and (printing or H - len(L) >= len(ins) + 2):
        L.append([])
        L += ins
    room = H - len(L) - 6
    if not printing and room >= 7 and main_w >= 50:
        crow = min(12, room - 2)
        L.append([])
        L.append([("  Highs, lows and rain chances", "title"), (f"   next {len(rows)} days", "dim")])
        if v.gmode in ("kitty", "sixel"):
            ch = v.images.block("dailychart", f"dchart:{m.get('updated')}:{F.imp}:{len(rows)}:{v.theme.name}",
                                main_w - 4, crow,
                                lambda mode, w, h: daily_chart(rows, F, w, h, v.theme.rgb("bg"), theme=v.theme) if mode == "pixels"
                                else daily_text(rows, F, w, h, mode == "ascii"))
        else:
            ch = daily_text(rows, F, main_w - 4, crow, v.ascii)
        L += [[("  ", "text")] + ln for ln in ch]
    out = {"lines": L, "sticky": sticky, "cursor": cursor, "rowmap": rowmap}
    if printing:
        for r in rows:
            L.append([])
            L.append([("  " + f"{r['date']:%A, %B} {r['date'].day}", "title"), (f"   {r.get('src') or ''}", "dim")])
            L += day_detail(r, F, W, m)
    else:
        r = rows[sel]
        title = f"{r['date']:%A, %B} {r['date'].day}"
        if side_w:
            det = [ui.section(title, side_w, r.get("src") or "")]
            ic = ui.icon_block(v, r.get("kind"), True, 13, 5, slot="daydetail")
            info = [[(cap(r.get("desc")) or "", "value")],
                    [("High ", "label"), (F.t(r.get("hi")), temp_style(r.get("hi"))), ("  Low ", "label"),
                     (F.t(r.get("lo")), temp_style(r.get("lo")))],
                    [("Precip ", "label"), (F.pct(r.get("pop")), pop_style(r.get("pop")))]]
            for k in range(5):
                det.append([(" ", "text")] + padto(ic[k], 14) + (info[k] if k < len(info) else []))
            det += day_detail(r, F, side_w, m)
            hrs = day_hours(m, F, r["date"])
            if hrs:
                det += [[], ui.section("Hour by hour", side_w, "every 3 hours")]
                for h_ in hrs:
                    det.append(clip([("  " + F.hour(h_["t"]).rjust(5) + "  ", "label"),
                                     (F.t(h_.get("temp")).rjust(4), temp_style(h_.get("temp"))),
                                     ("  " + (icons.label(h_.get("kind")) or cap(h_.get("desc") or ""))[:15].ljust(15), "text"),
                                     (F.pct(h_.get("pop")).rjust(5), pop_style(h_.get("pop"))),
                                     ("  " + wind_text(F, h_.get("wind_deg"), h_.get("wind")), wind_style(h_.get("wind")))],
                                    side_w))
            out["side"], out["side_w"] = det, side_w
        else:
            out["footer_title"] = f"{title}   {r.get('src') or ''}"
            out["footer"] = day_detail(r, F, W, m)
    return out


def day_hours(m, F, date, step=3):
    """Hourly rows for one calendar day (merged forecast first, Open-Meteo beyond it)."""
    rows = [r for r in m.get("hourly") or [] if r.get("t") and F.local(r["t"]).date() == date]
    if len(rows) < 6:
        om = (m.get("om") or {}).get("hourly") or {}
        more = [om[t] for t in sorted(om) if F.local(t).date() == date]
        if len(more) > len(rows):
            rows = more
    now = time.time() - 1800
    return [r for r in rows if F.local(r["t"]).hour % step == 0 and r["t"] >= now]


def outlook_insights(m, rows, F, width):
    """Plain-language takeaways from the daily forecast."""
    if not rows:
        return []
    out = [[("  The outlook at a glance", "title")]]
    his = [(r["hi"], r) for r in rows if r.get("hi") is not None]
    los = [(r["lo"], r) for r in rows if r.get("lo") is not None]
    if his:
        t, r = max(his, key=lambda x: x[0])
        out.append([("  Warmest      ", "label"), (f"{F.day_label(r['date'])}  {F.t(t)}", temp_style(t))])
    if los:
        t, r = min(los, key=lambda x: x[0])
        out.append([("  Coolest      ", "label"), (f"{F.day_label(r['date'])} night  {F.t(t)}", temp_style(t))])
    wet = [r for r in rows if (r.get("pop") or 0) >= 30]
    if wet:
        r = wet[0]
        out.append([("  Next rain    ", "label"), (f"{F.day_label(r['date'])}  {r['pop']:.0f}%  ", "rain"),
                    (cap(r.get("desc") or ""), "text")])
    else:
        out.append([("  Next rain    ", "label"), ("none likely in this forecast", "good")])
    tot = sum((r.get("rain") or 0) + (r.get("snow") or 0) for r in rows)
    if tot > 0.2:
        out.append([("  Total precip ", "label"), (f"about {F.precip(tot)} over {len(rows)} days", "rain")])
    gusty = [(r.get("gust") or r.get("wind") or 0, r) for r in rows]
    g, r = max(gusty, key=lambda x: x[0])
    if g >= 9:
        out.append([("  Windiest     ", "label"), (f"{F.day_label(r['date'])}  gusts {F.wind(g)}", "warn")])
    frost = [r for r in rows if r.get("lo") is not None and r["lo"] <= 1.5]
    if frost:
        out.append([("  Frost risk   ", "label"), (", ".join(F.day_label(r["date"]) for r in frost[:5]), "t_cold")])
    hot = [r for r in rows if r.get("hi") is not None and r["hi"] >= 32.2]
    if hot:
        out.append([("  Heat         ", "label"), (", ".join(F.day_label(r["date"]) for r in hot[:5]) + f" at {F.t(32.2)} or more", "t_scorch")])
    a = m.get("almanac") or {}
    if a.get("normal_hi") is not None and his:
        diffs = [h - a["normal_hi"] for h, _r in his[:7]]
        avg = sum(diffs) / len(diffs)
        word = "above" if avg > 1 else "below" if avg < -1 else "near"
        out.append([("  Vs normal    ", "label"), (f"highs average {F.tdelta(avg)} ({word} the normal {F.t(a['normal_hi'])})",
                                                  "warn" if avg > 3 else "rain" if avg < -3 else "text")])
    return out


# ----------------------------------------------------------------------------
# 6 Alerts
# ----------------------------------------------------------------------------

def render_alerts(m, v, W, H, printing=False):
    F = v.fmt
    alerts = m.get("alerts") or []
    main_w, side_w = ui.sidebar_split(W, want=46) if not printing else (W, 0)
    width = min(main_w, 110)
    L = []
    if not alerts:
        why = ((m.get("off") or {}).get("nws_alerts") and "the National Weather Service source is turned off in Settings"
               or (m.get("notes") or {}).get("nws_alerts")
               or (m["errors"].get("nws_alerts") and f"the alerts check failed ({m['errors']['nws_alerts']})")
               or (m["errors"].get("nws_points") and f"the NWS point lookup failed ({m['errors']['nws_points']})"))
        if why:
            L += wrap(f"Alerts aren't available: {why}.", main_w, "warn", 2)
        elif m.get("alerts_at"):
            L.append([("  No active watches, warnings, or advisories for your location.", "good")])
            L.append([(f"  Checked with the National Weather Service at {F.time(m['alerts_at'])}.", "dim")])
        else:
            L.append([("  Checking for watches, warnings and advisories…", "dim")])
    else:
        L.append([(f"  {len(alerts)} active alert{'s' if len(alerts) != 1 else ''}", "title"),
                  ("   press s to hear them", "dim")])
    for a in alerts:
        L.append([])
        L.append([(f" {a['event']} ".ljust(min(main_w - 2, 60)), alert_style(a["event"]))])
        meta = " / ".join(x for x in (a.get("severity"), a.get("urgency"), a.get("certainty"),
                                      a.get("msgtype")) if x)
        L.append([("  " + (meta + "   " if meta else "") + f"from {a['src']}", "dim")])
        if a.get("nws_headline"):
            L += wrap(a["nws_headline"], width, "value", 2)
        elif a.get("headline"):
            L += wrap(a["headline"], width, "value", 2)
        span = f"{F.dtime(a.get('start'))} to {F.dtime(a.get('end'))}" if a.get("end") else F.dtime(a.get("start"))
        L += labeled_wrap("In effect", span, main_w, lw=14)
        if a.get("sender"):
            L += labeled_wrap("Issued by", a["sender"], main_w, lw=14)
        if a.get("area"):
            L += labeled_wrap("Areas", a["area"], main_w, lw=14, style="dim")
        for label, val in a.get("extras") or []:
            L += labeled_wrap(label, val, main_w, lw=14, style="warn")
        if a.get("desc"):
            L.append([])
            L += wrap(a["desc"], width, "text", 4)
        if a.get("instruction"):
            L.append([])
            L.append([("  What to do", "title")])
            L += wrap(a["instruction"], width, "text", 4)
        if a.get("note"):
            L += labeled_wrap("Note", a["note"], main_w, lw=14, style="dim")
        L.append([("  " + "─" * (width - 4), "faint")])
    # nearby storm-based warnings (polygons) from IEM
    sbw = [w for w in m.get("sbw") or [] if (w.get("dist") or 0) <= 150]
    if sbw:
        L.append([])
        L.append([("  Warnings nearby", "title"), ("   storm-based polygons within 150 mi, drawn on the radar", "dim")])
        for w in sbw[:10]:
            where = "YOUR LOCATION IS INSIDE" if w["inside"] else f"{F.dist(w['dist'])} {compass(w['bearing'])}"
            tags = []
            if w.get("tornado"):
                tags.append(f"tornado {str(w['tornado']).lower()}")
            if w.get("hail"):
                tags.append(f"hail {F.precip(w['hail'] * 25.4)}")
            if w.get("wind"):
                tags.append(f"wind {F.wind(w['wind'] * 0.44704)}")
            if w.get("emergency"):
                tags.append("EMERGENCY")
            L.append(clip([("  ▌", ("rgb", w["rgb"], None, "b")), (f"{w['name']:<30}", "value"),
                           (f"{where:<26}", "bad" if w["inside"] else "text"),
                           (f"until {F.time(w['expire'])}" if w.get("expire") else "", "dim"),
                           (("   " + ", ".join(tags)) if tags else "", "warn")], main_w))
    wat = [w for w in m.get("watches") or [] if (w.get("dist") or 0) <= 250]
    if wat:
        L.append([])
        L.append([("  SPC watches", "title")])
        for w in wat:
            L.append(clip([("  ▌", ("rgb", w["rgb"], None, "b")), (w["name"].ljust(32), "value"),
                           ("covers your location" if w["inside"] else f"{F.dist(w['dist'])} away", "bad" if w["inside"] else "dim"),
                           (f"   until {F.time(w['expire'])}" if w.get("expire") else "", "dim")], main_w))
    ol = m.get("outlooks") or []
    if ol:
        L.append([])
        L.append([("  Outlooks for your point", "title"), ("   Storm Prediction Center and Weather Prediction Center", "dim")])
        today = F.today()
        for o in ol:
            day = today + dt.timedelta(days=(o["day"] or 1) - 1)
            lab = "Today" if day == today else "Tomorrow" if day == today + dt.timedelta(days=1) else f"{day:%A}"
            L.append(clip([("  " + lab.ljust(11), "label"), (o["kind"].ljust(16), "text"), (o["word"], o["style"]),
                           ((f"  ({o['level']} of 5)" if o.get("level") and o["category"] == "CATEGORICAL" and o["type"] == "C" else ""), "dim")],
                          main_w))
    lsrs = m.get("lsrs") or []
    if lsrs:
        L.append([])
        L.append([("  Storm reports, last 48 hours", "title"), ("   within 60 mi, from local NWS offices", "dim")])
        for r in lsrs[:15]:
            mag = f" {r['mag']:g} {r['unit'].lower()}" if r.get("mag") else ""
            where = f"{r['city'].title()}, {r['state']}"
            dist = f"{F.dist(r['dist'])} {compass(r['bearing'])}" if r.get("dist") is not None else ""
            L.append(clip([("  " + F.dtime(r["t"]).ljust(17), "dim"), ((r["type"] or "") + mag, "warn"),
                           ("  " + where, "text"), ("  " + dist, "dim")], main_w))
            if r.get("remark"):
                L += wrap(r["remark"], width, "dim", 6)
    elif not printing:
        L.append([])
        L.append([("  No storm reports within 60 miles in the last 48 hours.", "dim")])
    L += ui.error_lines(m, ("nws_alerts", "iem_outlook", "iem_lsr", "iem_sbw"), main_w)
    room = H - len(L) - 3
    if v.radar is not None and not printing and room >= 10 and main_w >= 50:
        L.append([])
        L.append([("  Regional radar", "title"), ("   480 miles across, with warning boxes", "dim")])
        lines, _res = ui.radar_block(v, m, main_w - 4, room - 1, slot="regional", mini=True, span=480)
        L += [[("  ", "text")] + ln for ln in lines]
    side = []
    if side_w or printing:
        sw = side_w or W
        side += ui.outlook_panel(m, F, sw)
        side += [[]] + spc_scale(m, F, sw, v.ascii)
        hw = hwo_summary(m.get("hwo"))
        if hw:
            office = (m.get("hwo") or {}).get("office") or ""
            side += [[], ui.section("Hazardous weather outlook", sw, f"NWS {office}".strip())]
            for head, when, body in hw:
                side.append(clip([("  " + head, "label"), (("  " + when) if when else "", "dim")], sw))
                side += wrap(body, sw, "text", 4)
        else:
            off = m.get("office") or {}
            items = [(x["title"], x.get("text") or "") for x in off.get("stories") or [] if x.get("title")][:3]
            items += [(x["title"], "") for x in off.get("headlines") or [] if x.get("title")][:3]
            if items:
                side += [[], ui.section("From your NWS office", sw, "press 9 for more")]
                for title, text in items[:4]:
                    side += wrap(title, sw, "label", 2)
                    if text:
                        side += wrap(text[:220] + ("…" if len(text) > 220 else ""), sw, "dim", 4)
        if v.radar is not None and not printing:
            # the radar takes what the panels leave (8 to 18 rows); the office notes give way first
            want = max(8, min(18, int(sw * 0.42)))
            rh = max(8, min(want, H - len(side) - 4))
            radar = ui.mini_radar_panel(v, m, sw, rh) + [[]]
            room = H - len(radar)
            if len(side) > room > 6:
                side = side[:room - 1] + [[("  … more on screen 9 (NWS & Radio)", "dim")]]
            side = radar + side
    return with_side(L, side, side_w, printing)


def hwo_summary(prod):
    """The sections of a Hazardous Weather Outlook: [(heading, when, text)]."""
    text = (prod or {}).get("text") or ""
    seg = text.split("$$")[0]
    out = []
    for mt in re.finditer(r"^\.([A-Z][A-Z \-]+?)\.\.\.(.*?)$(.*?)(?=^\.[A-Z]|\Z)", seg, re.S | re.M):
        head = mt.group(1).strip().capitalize()
        when = mt.group(2).strip().rstrip(".")
        body = " ".join(mt.group(3).split())
        if body:
            out.append((head, when, body))
    return out


SPC_SCALE = [("TSTM", "Thunder", "label"), ("MRGL", "Marginal", "good"), ("SLGT", "Slight", "warn"),
             ("ENH", "Enhanced", "accent"), ("MDT", "Moderate", "bad"), ("HIGH", "High", "bad")]


def spc_scale(m, F, width, ascii_only=False):
    """Day 1-3 severe-storm risk at your point on the SPC 0-5 scale."""
    out = [ui.section("Storm risk scale", width, "SPC days 1-3")]
    today = F.today()
    best = {}
    for o in m.get("outlooks") or []:
        if o["type"] == "C" and o["category"] == "CATEGORICAL" and o["day"] in (1, 2, 3):
            lvl = [k for k, _n, _s in SPC_SCALE].index(o["threshold"]) if o["threshold"] in [k for k, _n, _s in SPC_SCALE] else -1
            best[o["day"]] = max(best.get(o["day"], -1), lvl)
    for day in (1, 2, 3):
        d = today + dt.timedelta(days=day - 1)
        lab = "Today" if day == 1 else f"{d:%a}"
        lvl = best.get(day, -1)
        segs = [("  " + lab.ljust(6), "label")]
        for i, (_k, name, sty) in enumerate(SPC_SCALE):
            mark = ("#" if ascii_only else "█") if i <= lvl else ("." if ascii_only else "·")
            segs.append((mark * 2, sty if i <= lvl else "faint"))
        segs.append(("  " + (SPC_SCALE[lvl][1] if lvl >= 0 else "none"), SPC_SCALE[lvl][2] if lvl >= 0 else "good"))
        out.append(clip(segs, width))
    out += wrap("SPC risk of severe storms: Thunder, 1 Marginal, 2 Slight, 3 Enhanced, 4 Moderate, 5 High.",
                width, "dim", 2)
    return out


# ----------------------------------------------------------------------------
# 7 Air & UV
# ----------------------------------------------------------------------------

def render_air(m, v, W, H, printing=False):
    F = v.fmt
    air = m.get("air") or {}
    main_w, side_w = ui.sidebar_split(W, want=44) if not printing else (W, 0)
    L = []
    if not air:
        L.append([("  Air quality hasn't loaded yet.", "dim")])
        L += ui.error_lines(m, ("owm_air", "owm_air_fc", "om_air"), main_w)
        return {"lines": L}
    aqi = air.get("us")
    lab, sty, advice = aqi_cat(aqi)
    L.append([("  Air quality", "title"), (f"   {air.get('src')}, as of {F.time(air.get('t'))}", "dim")])
    L.append([])
    big = ui.big_temp(v, str(aqi) if aqi is not None else "--")
    owm = int(air["owm"]) if air.get("owm") else None
    side_txt = [
        [(lab, sty)],
        [("US AQI " + ("from OpenWeather concentrations" if air.get("src") == "OpenWeather" else "(EPA scale)"), "dim")],
        [("Driven by ", "label"), (air.get("dominant") or "--", "value")],
        [("OpenWeather index ", "label"), (f"{owm} of 5, {OWM_AQI.get(owm, '').lower()}", OWM_AQI_STYLE.get(owm, "value"))]
        if owm else [],
    ]
    bw = max(len(r) for r in big) + 6
    for i in range(5):
        L.append([(("  " + big[i]).ljust(bw), sty)] + (side_txt[i] if i < len(side_txt) else []))
    L.append([])
    L += wrap(advice, min(main_w, 100), "text", 2)
    L.append([])
    L.append([("  Pollutants", "title")])
    cols = [("pol", "Pollutant", 24, "l", 0), ("conc", "ug/m3", 8, "r", 0),
            ("conv", "Converted", 12, "r", 3), ("aqi", "AQI", 4, "r", 0), ("cat", "US category", 30, "l", 1),
            ("owm", "OpenWeather", 11, "l", 2)]
    cols = fit_columns(cols, main_w, "cat", 30)
    L.append(table_header(cols))
    L.append([("  " + "─" * table_width(cols), "faint")])
    for row in air.get("rows") or []:
        clab, csty, _ = aqi_cat(row["aqi"]) if row["aqi"] is not None else ("--", "dim", "")
        conv = "--" if row["conv"] is None else (
            f"{row['conv']:.2f} {row['unit']}" if row["unit"] == "ppm" else f"{row['conv']:.1f} {row['unit']}")
        lvl = row.get("owm")
        L.append(table_row(cols, {
            "pol": (f"{row['pol']}  {row['name'].lower()}", "text"),
            "conc": ("--" if row["conc"] is None else f"{row['conc']:.1f}", "value"),
            "conv": (conv, "dim"),
            "aqi": ("--" if row["aqi"] is None else str(row["aqi"]), csty),
            "cat": (clab, csty),
            "owm": (f"{lvl} {OWM_AQI[lvl].lower()}" if lvl else "--", OWM_AQI_STYLE.get(lvl, "dim")),
        }))
    for row in air.get("extra") or []:
        L.append(table_row(cols, {
            "pol": (f"{row['pol']}  {row['name'].lower()}", "text"),
            "conc": ("--" if row["conc"] is None else f"{row['conc']:.1f}", "value"),
            "conv": ("", "dim"), "aqi": ("", "dim"), "cat": ("no AQI scale", "dim"), "owm": ("", "dim"),
        }))
    past = air.get("history") or []
    if past:
        vals = [a for _, a, _pm in past]
        hi = max(past, key=lambda x: x[1])
        L.append([])
        L.append([("  Past 24 hours", "title")])
        L.append([("  AQI   ", "label"), (spark(vals, 0, max(100, max(vals)), ascii_only=v.ascii), aqi_cat(hi[1])[1]),
                  (f"   high {hi[1]} ({aqi_cat(hi[1])[0].lower()}) at {F.time(hi[0])}, low {min(vals)}", "dim")])
        pm = [p for _, _a, p in past if p is not None]
        if pm:
            L.append([("  PM2.5 ", "label"), (spark([p for _, _a, p in past], ascii_only=v.ascii), "accent"),
                      (f"   {min(pm):.1f} to {max(pm):.1f} ug/m3, 24-hour average {sum(pm) / len(pm):.1f}", "dim")])
    fc = air.get("forecast") or []
    now = time.time()
    nxt = [(t, a) for t, a in fc if now - 3600 <= t <= now + 24 * 3600]
    if nxt:
        vals = [a for _, a in nxt]
        peak = max(nxt, key=lambda x: x[1])
        L.append([])
        L.append([("  Next 24 hours", "title")])
        L.append([("  AQI   ", "label"), (spark(vals, 0, max(100, max(vals)), ascii_only=v.ascii), aqi_cat(peak[1])[1]),
                  (f"   peak {peak[1]} ({aqi_cat(peak[1])[0].lower()}) at {F.hour(peak[0])}", "dim")])
    days = {}
    for t, a in fc:
        d = F.local(t).date()
        days[d] = max(days.get(d, 0), a)
    if days:
        L.append([])
        L.append([("  Daily peak", "title"), ("   forecast", "dim")])
        for d in sorted(days)[:5]:
            clab, csty, _ = aqi_cat(days[d])
            L.append([("  " + F.day_label(d).ljust(12), "label"), (f"{days[d]:>4}  ", csty), (clab, csty)])
    # UV forecast (Open-Meteo)
    uv_day, uv_word = uv_focus(m, F)
    if uv_day:
        peak = max(uv_day, key=lambda x: x[1])
        lab2, sty2 = uv_cat(peak[1])
        L.append([])
        L.append([(f"  UV index {uv_word}", "title"), ("   Open-Meteo", "dim")])
        L.append([("  UV    ", "label"), (spark([u for _, u in uv_day], 0, 11, zero="▁", ascii_only=v.ascii), sty2),
                  (f"   peak {peak[1]:.0f} ({lab2.lower()}) around {F.hour(peak[0])}", "dim")])
        if peak[1] >= 6:
            L += wrap("Sun protection recommended in the middle of the day: shade, a hat, and SPF 30+.", main_w, "warn", 2)
    om = m.get("air_om") or {}
    if air.get("src") == "OpenWeather" and om.get("us") is not None:
        clab, csty, _ = aqi_cat(om["us"])
        L.append([])
        L.append([("  Second opinion  ", "label"), (f"Open-Meteo (CAMS) US AQI {om['us']} {clab}", csty)])
    L.append([])
    L += wrap("US AQI values here are model estimates (OpenWeather or CAMS via Open-Meteo), so they can differ "
              "from AirNow's official monitor readings.", min(main_w, 100), "dim")
    L += ui.error_lines(m, ("owm_air", "owm_air_fc", "owm_air_hist", "om_air"), main_w)
    side = []
    if side_w or printing:
        sw = side_w or W
        side.append(ui.section("AQI scale", sw))
        prev_lim = -1
        for lim, name, st_, _adv in [(50, "Good", "aqi1", ""), (100, "Moderate", "aqi2", ""),
                                     (150, "Unhealthy (sensitive)", "aqi3", ""), (200, "Unhealthy", "aqi4", ""),
                                     (300, "Very unhealthy", "aqi5", ""), (500, "Hazardous", "aqi6", "")]:
            mark = " ◀" if aqi is not None and prev_lim < aqi <= lim else ""
            prev_lim = lim
            side.append([("  ", "text"), ("██" if not v.ascii else "##", st_), (f" {name:<24}", "text"),
                         (f"≤{lim}" if lim < 500 else "301+", "dim"), (mark, "accent")])
        side.append([])
        side.append(ui.section("UV scale", sw))
        for lo_, name, st_ in ((0, "Low 0-2", "good"), (3, "Moderate 3-5", "warn"), (6, "High 6-7", "warn"),
                               (8, "Very high 8-10", "bad"), (11, "Extreme 11+", "bad")):
            side.append([("  ", "text"), ("██" if not v.ascii else "##", st_), (" " + name, "text")])
        if om.get("dust") is not None:
            side.append([])
            side.append(ui.section("Aerosols", sw))
            side.append(ui.kv("Dust", f"{om['dust']:.0f} ug/m3", sw, 12))
            if om.get("aod") is not None:
                side.append(ui.kv("Haze (AOD)", f"{om['aod']:.2f}", sw, 12))
        side += [[]] + sun_safety(m, F, sw)
        side += [[]] + pollutant_guide(air, sw)
    return with_side(L, side, side_w, printing)


def uv_focus(m, F):
    """Today's UV curve, or tomorrow's once today's sun is done: (series, word)."""
    uv = (m.get("air_om") or {}).get("uv") or []
    today = F.today()
    rows = [(t, u) for t, u in uv if F.local(t).date() == today]
    if rows and max(u for _t, u in rows) >= 1:
        return rows, "today"
    tmr = today + dt.timedelta(days=1)
    rows2 = [(t, u) for t, u in uv if F.local(t).date() == tmr]
    if rows2:
        return rows2, "tomorrow"
    return rows, "today"


def sun_safety(m, F, width):
    rows, word = uv_focus(m, F)
    out = [ui.section("Sun safety", width, word)]
    if not rows:
        return out + [[("  No UV forecast yet.", "dim")]]
    t_pk, pk = max(rows, key=lambda x: x[1])
    lab, sty = uv_cat(pk)
    out.append(ui.kv("Peak UV", [(f"{pk:.0f} {lab}", sty), (f"  around {F.hour(t_pk)}", "dim")], width, 16))
    hot = [t for t, u in rows if u >= 3]
    if hot:
        out.append(ui.kv("UV 3 or higher", f"{F.hour(min(hot))} to {F.hour(max(hot) + 3600)}", width, 16))
        # erythemal dose: UV index 1 = 0.025 W/m2; ~250 J/m2 reddens fair (type II) skin
        mins = 250 / (pk * 0.025) / 60
        out.append(ui.kv("Burn time", f"~{mins:.0f} min, fair skin", width, 16))
        out += wrap("Sunscreen (SPF 30+), a hat and shade help most during those hours.", width, "dim", 4)
    else:
        out += wrap("UV stays low, so sunburn risk is minimal for most people.", width, "good", 2)
    return out


POLLUTANT_GUIDE = [
    ("PM2.5", "Fine particles from smoke, exhaust and industry, small enough to reach deep into the lungs."),
    ("PM10", "Coarser dust, pollen and mold that irritate the eyes, nose and throat."),
    ("O3", "Ground-level ozone, cooked up by sunlight from traffic and industrial fumes; worst on hot afternoons."),
    ("NO2", "Nitrogen dioxide, mostly from traffic and power plants; it inflames airways."),
    ("SO2", "Sulfur dioxide from burning coal and oil; it can trigger asthma."),
    ("CO", "Carbon monoxide, an odorless gas from incomplete burning that crowds oxygen out of the blood."),
]


def pollutant_guide(air, width):
    out = [ui.section("What they are", width)]
    dom = air.get("dominant")
    for pol, text in POLLUTANT_GUIDE:
        rows = runin(pol, ("(driving the AQI now) " if pol == dom else "") + text, width)
        rows[0] = [(t, ("accent" if pol == dom else "label") if k == 0 else "dim") for k, (t, _s) in enumerate(rows[0])]
        out += [rows[0]] + [[(t, "dim") for t, _s in r] for r in rows[1:]]
    return out


# ----------------------------------------------------------------------------
# 8 Sky & Almanac
# ----------------------------------------------------------------------------

def day_bar(s, day, tz, cells, ascii_only=False, lat=None, lon=None):
    """Daylight and twilight across the day.  Uses the event times in `s`, or
    the sun's height when an event doesn't happen (midnight sun, polar night)."""
    if tz:
        start = int(dt.datetime(day.year, day.month, day.day, tzinfo=tz).timestamp())
    else:
        start = int(time.mktime(day.timetuple()))
    step = 86400 / cells
    limits = {"sun": -0.833, "civil": -6.0, "nautical": -12.0, "astro": -18.0}

    def inside(t, name):
        pair = s[name]
        if pair[0] is not None and pair[1] is not None:
            return pair[0] <= t < pair[1]
        if lat is None or lon is None:
            return False
        return sun_altitude(t, lat, lon) > limits[name]

    chars = ("#", "=", "-", ".", " ") if ascii_only else ("█", "▓", "▒", "░", "·")
    segs = []
    for i in range(cells):
        t = start + (i + 0.5) * step
        if inside(t, "sun"):
            ch, sty = chars[0], "t_warm"
        elif inside(t, "civil"):
            ch, sty = chars[1], "t_hot"
        elif inside(t, "nautical"):
            ch, sty = chars[2], "accent"
        elif inside(t, "astro"):
            ch, sty = chars[3], "rain"
        else:
            ch, sty = chars[4], "faint"
        if segs and segs[-1][1] == sty:
            segs[-1] = (segs[-1][0] + ch, sty)
        else:
            segs.append((ch, sty))
    return segs, start, step


def render_sky(m, v, W, H, printing=False):
    F = v.fmt
    loc = m.get("loc") or {}
    main_w, side_w = ui.sidebar_split(W, want=40) if not printing else (W, 0)
    paired = main_w >= 96 and not printing         # sections side by side, in pairs
    L = []
    if loc.get("lat") is None:
        L.append([("  Waiting for the location lookup.", "dim")])
        L += ui.error_lines(m, ("loc",), W)
        return {"lines": L}
    lat, lon, tz = loc["lat"], loc["lon"], F.tz
    today = F.today()
    s = sun_day(today, lat, lon, tz)
    y = sun_day(today - dt.timedelta(days=1), lat, lon, tz)
    calc_len = s["length"]
    astro = m.get("astro") or {}
    if astro:
        for key, (a, b) in (("sun", ("sunrise", "sunset")), ("civil", ("civilTwilightBegin", "civilTwilightEnd")),
                            ("nautical", ("nauticalTwilightBegin", "nauticalTwilightEnd")),
                            ("astro", ("astronomicalTwilightBegin", "astronomicalTwilightEnd"))):
            if astro.get(a) and astro.get(b):
                s[key] = (astro[a], astro[b])
        s["noon"] = astro.get("transit") or s["noon"]
        if s["sun"][0] and s["sun"][1]:
            s["length"] = s["sun"][1] - s["sun"][0]
    source = "from NWS for this point" if astro else f"calculated for {lat:.4f}, {lon:.4f}"
    L.append([("  Sun", "title"), (f"   {source}", "dim")])
    change = ""
    if calc_len and y["length"] and not s.get("polar") and not y.get("polar"):
        diff = calc_len - y["length"]
        change = f"  ({abs(diff) // 60}m {abs(diff) % 60:02d}s {'longer' if diff >= 0 else 'shorter'} than yesterday)"
    gold = s["golden"]
    polar = {"day": "the sun stays up all day (midnight sun)",
             "night": "the sun stays below the horizon all day (polar night)"}.get(s.get("polar"))
    rows = [
        ("Sunrise", F.time(s["sun"][0]) if not polar else polar),
        ("Sunset", F.time(s["sun"][1]) if not polar else "--"),
        ("Solar noon", F.time(s["noon"])),
        ("Daylight", [(F.duration(s["length"]), "value"), (change, "dim")]),
        ("Civil twilight", f"{F.time(s['civil'][0])} to {F.time(s['civil'][1])}"),
        ("Nautical", f"{F.time(s['nautical'][0])} to {F.time(s['nautical'][1])}"),
        ("Astronomical", f"{F.time(s['astro'][0])} to {F.time(s['astro'][1])}"),
        ("Golden hour", f"until {F.time(gold[0])}, from {F.time(gold[1])}" if gold[0] and gold[1] else "--"),
    ]
    L += [[("  ", "text")] + ln for ln in block("", "", rows, lw=16)[1:]]
    m_tl = len(L)
    cells = max(24, min(96, main_w - 8))
    segs, start, step = day_bar(s, today, tz, cells, v.ascii, lat, lon)
    L.append([])
    now_i = int((time.time() - start) / step)
    if 0 <= now_i < cells:
        L.append([("  " + " " * now_i + ("v now" if v.ascii else "▼ now"), "value")])
    L.append([("  ", "text")] + segs)
    scale = [" "] * cells
    for frac, lab in ((0, "12a"), (0.25, "6a"), (0.5, "noon"), (0.75, "6p")):
        pos = int(frac * cells)
        for k, ch in enumerate(lab):
            if pos + k < cells:
                scale[pos + k] = ch
    L.append([("  " + "".join(scale), "dim")])
    L.append([("  ", "text"), ("█ day  " if not v.ascii else "# day  ", "t_warm"),
              ("▓ civil  " if not v.ascii else "= civil  ", "t_hot"),
              ("▒ nautical  " if not v.ascii else "- nautical  ", "accent"),
              ("░ astronomical  " if not v.ascii else ". astronomical  ", "rain"), ("· night", "faint")])

    m_moon = len(L)
    L.append([])
    L.append([("  Moon", "title")])
    now = time.time()
    age, illum, name = moon_info(now)
    drow = ui.today_row(m, F)
    if drow.get("moon_phase") is not None:
        name = moon_name(drow["moon_phase"])
    rows = [
        ("Phase", name),
        ("Illuminated", f"{illum * 100:.0f}%"),
        ("Age", f"{age:.1f} days into the cycle"),
        ("Moonrise", F.time(drow.get("moonrise"))) if drow.get("moonrise") else None,
        ("Moonset", F.time(drow.get("moonset"))) if drow.get("moonset") else None,
    ]
    phases = next_moon_phases(now, 4)
    for pname, t in phases:
        rows.append((f"{pname} {'moon' if pname in ('New', 'Full') else 'quarter'}",
                     f"{F.local(t):%a %b} {F.local(t).day}  (approx.)"))
    L += [[("  ", "text")] + ln for ln in block("", "", rows, lw=16)[1:]]
    m_alm = len(L)

    a = m.get("almanac") or {}
    if a:
        L.append([])
        st = a.get("station") or {}
        L.append([("  Almanac", "title"), (f"   {a.get('name') or st.get('name') or ''}  (NOAA ACIS"
                                            f"{', records since ' + st['since'][:4] if st.get('since') else ''})", "dim")])
        arows = [
            ("Normal high/low", [(F.t(a.get("normal_hi")), temp_style(a.get("normal_hi"))), (" / ", "dim"),
                                 (F.t(a.get("normal_lo")), temp_style(a.get("normal_lo")))]),
            ("Record high", [(F.t(a.get("rec_hi")), temp_style(a.get("rec_hi"))), (f"  set in {a.get('rec_hi_year')}", "dim")])
            if a.get("rec_hi") is not None else None,
            ("Record low", [(F.t(a.get("rec_lo")), temp_style(a.get("rec_lo"))), (f"  set in {a.get('rec_lo_year')}", "dim")])
            if a.get("rec_lo") is not None else None,
            ("Record rainfall", [(F.precip(a.get("rec_precip")), "rain"), (f"  in {a.get('rec_precip_year')}", "dim")])
            if a.get("rec_precip") else None,
            ("Yesterday", [(F.t(a.get("y_hi")), temp_style(a.get("y_hi"))), (" / ", "dim"),
                           (F.t(a.get("y_lo")), temp_style(a.get("y_lo"))),
                           (f"   precip {F.precip(a.get('y_precip'))}" if a.get("y_precip") is not None else "", "rain")])
            if a.get("y_hi") is not None else None,
            ("Month to date", [(F.precip(a.get("mtd_precip")), "rain"),
                               (f"   normal {F.precip(a.get('mtd_normal'))}" if a.get("mtd_normal") is not None else "", "dim")])
            if a.get("mtd_precip") is not None else None,
            ("Year to date", [(F.precip(a.get("ytd_precip")), "rain"),
                              (f"   normal {F.precip(a.get('ytd_normal'))}" if a.get("ytd_normal") is not None else "", "dim")])
            if a.get("ytd_precip") is not None else None,
            ("Month average", [(F.t1(a.get("mtd_avg")), temp_style(a.get("mtd_avg"))),
                               (f"   normal {F.t1(a['mtd_avg_normal'])}  ({F.tdelta(a['mtd_avg'] - a['mtd_avg_normal'])})"
                                if a.get("mtd_avg_normal") is not None else "", "dim")])
            if a.get("mtd_avg") is not None else None,
        ]
        L += [[("  ", "text")] + ln for ln in block("", "", [r for r in arows if r], lw=16)[1:]]
        days = [d for d in a.get("days") or [] if d.get("hi") is not None]
        if days and main_w >= 60:
            L.append([])
            L.append([("  This month", "label"), ("   daily high vs normal", "dim")])
            his = [d["hi"] - d["nhi"] for d in days if d.get("nhi") is not None]
            note = f"; {sum(1 for h in his if h > 0)} of {len(his)} days above normal" if his else ""
            sp = (spark([F.tv(d["hi"]) for d in days], ascii_only=v.ascii), "t_warm")
            txt = f"warmest {F.t(max(d['hi'] for d in days))}, coolest high {F.t(min(d['hi'] for d in days))}" + note
            if paired:
                L.append([("  ", "text"), sp])
                L += wrap(txt, (main_w - 3) // 2, "dim", 2)
            else:
                L.append([("  ", "text"), sp, ("   " + txt, "dim")])

    m_week = len(L)
    L.append([])
    L.append([("  Week ahead", "title")])
    cols = [("day", "Day", 10, "l", 0), ("rise", "Sunrise", 8, "r", 0), ("set", "Sunset", 8, "r", 0),
            ("len", "Daylight", 8, "r", 0), ("moon", "Moon", 16, "l", 1)]
    cols = fit_columns(cols, (main_w - 3) // 2 if paired else main_w, "moon", 16)
    L.append(table_header(cols))
    L.append([("  " + "─" * table_width(cols), "faint")])
    for i in range(7):
        d = today + dt.timedelta(days=i)
        sd = sun_day(d, lat, lon, tz)
        L.append(table_row(cols, {
            "day": (F.day_label(d), "label"),
            "rise": (F.time(sd["sun"][0]), "text"),
            "set": (F.time(sd["sun"][1]), "text"),
            "len": (F.duration(sd["length"]), "text"),
            "moon": (day_moon({"date": d}, tz)[0], "text"),
        }))
    m_err = len(L)
    L += ui.error_lines(m, ("acis",), main_w)
    if paired:
        def trim(part):
            while part and not part[0]:
                part = part[1:]
            return part
        col_w = (main_w - 3) // 2
        top, _w = ui.columns([trim(L[:m_tl]), trim(L[m_moon:m_alm])], 2, col_w, ascii_only=v.ascii)
        bottom, _w = ui.columns([trim(L[m_alm:m_week]), trim(L[m_week:m_err])], 2, col_w, ascii_only=v.ascii)
        L = top + [[]] + trim(L[m_tl:m_moon]) + [[]] + bottom + L[m_err:]
    side = []
    if side_w or printing:
        sw = side_w or W
        mrows = max(6, min(12, sw // 3))
        mcols = min(sw - 2, mrows * 2 + 2)
        side.append(ui.section("Tonight's moon", sw))
        mb = ui.moon_block(v, age / SYNODIC, mcols, mrows)
        pad = max(0, (sw - mcols) // 2)
        side += [[(" " * pad, "text")] + ln for ln in mb]
        side.append([(f"{name}, {illum * 100:.0f}% lit".center(sw), "t_mild")])
        if v.gmode in ("kitty", "sixel") and not printing:
            from .charts import sun_path_image
            day0 = int(dt.datetime(today.year, today.month, today.day, tzinfo=tz).timestamp()) if tz else int(now // 86400 * 86400)
            pts = [(day0 + k * 900, sun_altitude(day0 + k * 900, lat, lon)) for k in range(97)]
            side.append([])
            side.append(ui.section("Sun path today", sw))
            srows = max(5, sw // 5)
            sp = v.images.block("sunpath", f"sunpath:{today}:{int(now // 600)}:{sw}", sw - 2, srows,
                                lambda mode, w, h: sun_path_image(pts, now, F, w, h, v.theme.rgb("bg"), theme=v.theme))
            side += [[(" ", "text")] + ln for ln in sp]
        elif not printing:
            from .text import braille_plot
            day0 = int(dt.datetime(today.year, today.month, today.day, tzinfo=tz).timestamp()) if tz else int(now // 86400 * 86400)
            alts = [sun_altitude(day0 + k * 1800, lat, lon) for k in range(49)]
            side.append([])
            side.append(ui.section("Sun path today", sw))
            if v.ascii:
                side.append([("  ", "text"), (spark([max(0, x) for x in alts], 0, max(10, max(alts)), ascii_only=True), "t_warm")])
            else:
                plot = braille_plot([([max(-6.0, x) for x in alts], "t_warm")], sw - 4, 4, -6.0, max(10.0, max(alts)))
                side += [[("  ", "text")] + ln for ln in plot]
            side.append([("  12a" + " " * max(0, (sw - 4) // 2 - 6) + "noon" + " " * max(0, (sw - 4) // 2 - 7) + "12a", "dim")])
            side.append([("  ", "text"), (f"Highest today {max(alts):.0f}° above the horizon at {F.time(s['noon'])}", "dim")])
        side.append([])
        side += coming_up(F, tz, sw)
        side.append([])
        side += daylight_year(F, lat, lon, tz, sw, v.ascii)
        side.append([])
        side += ui.almanac_panel(m, F, sw) if not a else []
    return with_side(L, side, side_w, printing)


def daylight_year(F, lat, lon, tz, width, ascii_only=False):
    """Day length through the year as block bars, with today marked."""
    today = F.today()
    year = today.year
    pts = []
    d = dt.date(year, 1, 1)
    while d.year == year:
        pts.append((d, sun_day(d, lat, lon, tz)["length"]))
        d += dt.timedelta(days=4)
    lens = [x for _d, x in pts if x is not None]
    out = [ui.section("Daylight this year", width)]
    if not lens or max(lens) <= 0:
        return out
    pw = max(12, width - 4)
    vals = [x for _d, x in pts]
    samp = [vals[min(len(vals) - 1, int(i * len(vals) / pw))] for i in range(pw)]
    lo, hi = min(lens) * 0.9, max(lens)
    if hi - lo < 60:
        lo = max(0, hi - 3600)
    parts = " .:-=+*#" if ascii_only else " ▁▂▃▄▅▆▇"
    full = "#" if ascii_only else "█"
    pos = min(pw - 1, int((today.timetuple().tm_yday - 1) / 366 * pw))
    for row in range(3):
        base = (2 - row) * 8
        line = [("  ", "text")]
        for i, x in enumerate(samp):
            e = max(0, int(round((x - lo) / (hi - lo) * 24))) if x else 0
            k = e - base
            ch = full if k >= 8 else parts[k] if k > 0 else " "
            line.append((ch, "accent" if i == pos else "t_warm"))
        out.append(line)
    axis = [" "] * pw
    for mth in range(12):
        x = int(mth / 12 * pw)
        if x < pw:
            axis[x] = "JFMAMJJASOND"[mth]
    out.append([("  " + "".join(axis), "dim")])
    out.append([("  " + " " * pos + "▲ today", "accent")] if pos < pw - 8 else [("  " + " " * max(0, pos - 7) + "today ▲", "accent")])
    short = min(((dd, x) for dd, x in pts if x is not None), key=lambda p: p[1])
    long_ = max(((dd, x) for dd, x in pts if x is not None), key=lambda p: p[1])
    t0 = sun_day(today, lat, lon, tz)["length"]
    t1 = sun_day(today + dt.timedelta(days=1), lat, lon, tz)["length"]
    out.append(ui.kv("Shortest", f"{F.duration(short[1])} around {short[0]:%b} {short[0].day}", width, 12))
    out.append(ui.kv("Longest", f"{F.duration(long_[1])} around {long_[0]:%b} {long_[0].day}", width, 12))
    if t0 and t1 and 0 < t0 < 86400 and 0 < t1 < 86400:
        dd = t1 - t0
        out.append(ui.kv("Trend", f"{'gaining' if dd > 0 else 'losing'} {abs(dd) // 60}m {abs(dd) % 60:02d}s a day", width, 12))
    return out


def _season_dates(year):
    """Approximate equinox/solstice dates (good to a day)."""
    return [(dt.date(year, 3, 20), "Spring equinox"), (dt.date(year, 6, 21), "Summer solstice"),
            (dt.date(year, 9, 22), "Fall equinox"), (dt.date(year, 12, 21), "Winter solstice")]


def coming_up(F, tz, width):
    out = [ui.section("Coming up", width)]
    today = F.today()
    seasons = [x for x in _season_dates(today.year) + _season_dates(today.year + 1) if x[0] >= today][:1]
    for d, name in seasons:
        out.append(ui.kv(name, f"{d:%a %b} {d.day}  ({(d - today).days} days)", width, 17))
    if tz is not None:
        try:
            base = dt.datetime(today.year, today.month, today.day, 12, tzinfo=tz)
            off0 = base.utcoffset()
            for k in range(1, 200):
                dd = base + dt.timedelta(days=k)
                if dd.utcoffset() != off0:
                    word = "Clocks fall back 1 hour" if dd.utcoffset() < off0 else "Clocks spring forward 1 hour"
                    day = (base + dt.timedelta(days=k - 1)).date() + dt.timedelta(days=1)
                    out.append(ui.kv("Time change", f"{day:%a %b} {day.day}", width, 17))
                    out += wrap(word + " (2 AM).", width, "dim", 4)
                    break
        except Exception:
            pass
    return out


# ----------------------------------------------------------------------------
# 9 NWS office & NOAA Weather Radio
# ----------------------------------------------------------------------------

def product_lines(prod, title, F, W):
    if prod and prod.get("missing"):
        return [[("  " + title, "title")]] + wrap(
            f"NWS {prod.get('office') or 'your office'} doesn't issue this product, so there's nothing to show "
            "here. The Alerts screen (6) and the storm outlooks cover hazards instead.", W, "dim", 2)
    if not prod or not prod.get("text"):
        return [[("  " + title, "title")], [("  Not available from this office right now.", "dim")]]
    issued = iso_epoch(prod.get("issued"))
    L = [[("  " + title, "title"),
          (f"   NWS {prod.get('office') or ''}, issued {F.dtime(issued)}", "dim")]]
    para = []

    def flush():
        if para:
            for piece in textwrap.wrap(" ".join(para), max(20, W - 4)) or [""]:
                L.append([("  " + piece, "text")])
            para.clear()

    for raw in prod["text"].splitlines():
        s = raw.rstrip()
        style = "title" if re.match(r"^\.[A-Z]", s) else "dim" if s.strip() in ("&&", "$$") else "text"
        body = s.strip()
        prose = style == "text" and body and not re.search(r"\S {3,}\S", body) and re.search(r"[a-z]", body)
        bullet = prose and re.match(r"^[-*•] ", body)
        if prose and (bullet or not s.startswith((" ", "\t")) or para):
            # NWS hard-wraps at 66 columns: let paragraphs (and bullets) fill the width
            if bullet:
                flush()
            para.append(body)
            continue
        flush()
        if len(s) <= W - 3:
            L.append([("  " + s, style)])
        else:
            for piece in textwrap.wrap(s, W - 4) or [""]:
                L.append([("  " + piece, style)])
    flush()
    return L


def render_office(m, v, W, H, printing=False):
    F = v.fmt
    office = m.get("office") or {}
    pts = m.get("pts") or {}
    radio = m.get("radio") or {}
    nwr = pts.get("nwr") or {}
    ncols, col_w = ui.flow_columns(W) if not printing else (1, W)
    if ncols > 1:        # long reading: newspaper columns across the whole width, the sidebar included
        main_w, side_w, width = col_w, 0, col_w
    else:
        main_w, side_w = ui.sidebar_split(W, want=42) if not printing else (W, 0)
        width = min(main_w, 110)
    away = (m.get("notes") or {}).get("nws_points") or (m.get("off") or {}).get("nws_points")
    if away and not pts:
        L = [[("  NWS & Radio", "title")], []]
        L += wrap(f"Nothing to show here: {away.rstrip('.')}. The other screens use Open-Meteo for this "
                  "location.", width, "dim", 2)
        return {"lines": L}
    L = [[("  NOAA Weather Radio", "title")]] + wrap("The script NWS reads on the air for this point; press s to "
                                                    "listen.", width, "dim", 2)
    bits = []
    tx = radio.get("transmitter") or nwr.get("transmitter")
    if tx:
        bits.append(f"transmitter {tx}")
    same = radio.get("same") or nwr.get("sameCode")
    if same:
        bits.append(f"SAME code {same}")
    if bits:
        L.append([("  " + "   ".join(bits), "label")])
    text = radio.get("text")
    hl = getattr(v, "speech_highlight", None)
    if text:
        L.append([])
        for chunk in re.split(r"\n\s*\n", text):
            rows = [r.strip() for r in chunk.split("\n") if r.strip()]
            if not rows:
                continue
            # a short first line without a period ('Tuesday Night') is a heading; the rest is one paragraph
            head = rows[0] if len(rows) > 1 and len(rows[0]) < 30 and not rows[0].endswith(".") else None
            body = " ".join(rows[1:] if head else rows)
            if head:
                L.append([("  " + head, "title" if not (hl and hl in head) else "speakhi")])
            style = "title" if body.isupper() and len(body) < 60 else "text"
            if hl and hl in body:
                style = "speakhi"
            L += wrap(body, width, style, 4)
            L.append([])
    else:
        L.append([("  No broadcast script is available for this point right now.", "dim")])
    L.append([])
    L.append([(f"  NWS {pts.get('gridId') or ''} office", "title")])
    L += wrap("Briefing, weather stories, headlines and the forecast discussion.", width, "dim", 2)
    brief = office.get("briefing")
    if brief:
        L.append([])
        L.append([("  Briefing  ", "label"), (brief["title"], "value"),
                  (f"   updated {F.dtime(brief['updated'])}" if brief.get("updated") else "", "dim")])
        L += wrap(brief["text"], width, "text", 4)
        if brief.get("link"):
            L += labeled_wrap("Download", brief["link"], width, lw=12, style="dim", indent=4)
    stories = office.get("stories") or []
    if stories:
        L.append([])
        L.append([("  Weather stories", "title"), ("   NWS graphics, in words", "dim")])
        for s in stories:
            L.append([])
            L.append([("  ▸ " if s["priority"] else "  · ", "accent"), (s["title"] or "Weather story", "value"),
                      (f"   until {F.dtime(s['end'])}" if s.get("end") else "", "dim")])
            L += wrap(s["text"], width, "text", 4)
            if s.get("alt") and s["alt"] != s["text"]:
                L += wrap(f"Image shows: {s['alt']}", width, "dim", 4)
    heads = office.get("headlines") or []
    if heads:
        L.append([])
        L.append([("  Headlines", "title")])
        for h in heads[:8]:
            L.append([("  ! " if h["important"] else "  · ", "warn" if h["important"] else "accent"),
                      (h["title"], "value"), (f"   {F.dtime(h['issued'])}" if h.get("issued") else "", "dim")])
            if h.get("text"):
                L += wrap(h["text"], width, "text", 4)
    if not (brief or stories or heads):
        L.append([])
        L.append([("  No briefing, weather stories, or headlines are posted right now.", "dim")])
    L.append([])
    L += product_lines(m.get("hwo"), "Hazardous weather outlook", F, width)
    L.append([])
    L += product_lines(m.get("afd"), "Area forecast discussion", F, width)
    L += ui.error_lines(m, ("nws_points", "nws_radio", "nws_afd", "nws_hwo", "nws_headlines", "nws_stories",
                            "nws_briefing"), width)
    side = []
    if side_w or printing or ncols > 1:
        sw = side_w or (col_w if ncols > 1 else W)
        side.append(ui.section("Listen", sw))
        side += wrap("Press s on any forecast screen to have skydrop read it aloud. Press s again "
                     "(or Esc) to stop; [ and ] skip between sentences.", sw, "text", 2)
        eng = getattr(v, "speech", None)
        if eng is not None:
            side.append([])
            side.append(ui.kv("Voice", eng.describe(), sw, 9))
        if tx or same:
            side.append([])
            side.append(ui.section("Weather radio", sw))
            if tx:
                side.append(ui.kv("Transmitter", tx, sw, 13))
            if same:
                side.append(ui.kv("SAME code", same, sw, 13))
            side += wrap("Program a weather radio with this SAME code to get alerts for your county.", sw, "dim", 2)
        if pts.get("gridId"):
            side.append([])
            side.append(ui.section("Your NWS office", sw))
            side.append(ui.kv("Office", pts.get("gridId"), sw, 10))
            side.append(ui.kv("Grid", f"{pts.get('gridX')},{pts.get('gridY')}", sw, 10))
            side.append(ui.kv("Radar", pts.get("radarStation") or "--", sw, 10))
            side.append(ui.kv("Zone", (pts.get("forecastZone") or "").rsplit("/", 1)[-1], sw, 10))
    if ncols > 1:
        # the short facts first, then the reading, flowed down the columns
        return {"lines": ui.flow(side + [[]] + L, ncols, col_w, ascii_only=v.ascii)}
    return with_side(L, side, side_w, printing)
