"""Weather icons: classify a condition, then draw it as pixels (kitty/sixel),
colored line art (block terminals) or plain ASCII art.
"""

import math

from . import gfx

KINDS = ("clear", "mostly_clear", "partly", "mostly_cloudy", "cloudy", "fog", "haze", "smoke", "dust",
         "wind", "drizzle", "rain", "showers", "heavy_rain", "thunder", "snow", "flurries", "sleet",
         "freezing", "mix", "unknown")

PRECIP_KINDS = {"drizzle", "rain", "showers", "heavy_rain", "thunder", "snow", "flurries", "sleet",
                "freezing", "mix"}


def from_text(text):
    t = (text or "").lower()
    if not t:
        return "unknown"
    if "tornado" in t or "thunder" in t or "t-storm" in t or "tstorm" in t:
        return "thunder"
    if "freezing" in t or "ice pellets" in t or "glaze" in t:
        return "freezing" if "fog" not in t or "rain" in t or "drizzle" in t else "fog"
    if "sleet" in t:
        return "sleet"
    if "snow" in t and ("rain" in t or "wintry" in t):
        return "mix"
    if "blizzard" in t or "heavy snow" in t:
        return "snow"
    if "flurr" in t or "snow shower" in t or "light snow" in t:
        return "flurries"
    if "snow" in t:
        return "snow"
    if "heavy rain" in t or "heavy shower" in t or "downpour" in t:
        return "heavy_rain"
    if "shower" in t:
        return "showers"
    if "drizzle" in t:
        return "drizzle"
    if "rain" in t:
        return "rain"
    if "fog" in t or "mist" in t:
        return "fog"
    if "smoke" in t:
        return "smoke"
    if "haze" in t:
        return "haze"
    if "dust" in t or "sand" in t or "ash" in t:
        return "dust"
    last = t.split(" then ")[-1]
    if "overcast" in last or ("cloudy" in last and "mostly" not in last and "partly" not in last):
        return "cloudy"
    if "mostly cloudy" in last or "considerable cloud" in last or "broken" in last:
        return "mostly_cloudy"
    if "partly" in last or "scattered" in last or "few clouds" in last or "partly sunny" in last:
        return "partly"
    if "mostly sunny" in last or "mostly clear" in last or "fair" in last:
        return "mostly_clear"
    if "sunny" in last or "clear" in last or "hot" in last:
        return "clear"
    if "wind" in last or "breezy" in last or "blustery" in last or "gust" in last:
        return "wind"
    if "cloud" in last:
        return "mostly_cloudy"
    return "unknown"


def from_wmo(code):
    if code is None:
        return "unknown"
    c = int(code)
    table = {0: "clear", 1: "mostly_clear", 2: "partly", 3: "cloudy", 45: "fog", 48: "fog",
             51: "drizzle", 53: "drizzle", 55: "drizzle", 56: "freezing", 57: "freezing",
             61: "rain", 63: "rain", 65: "heavy_rain", 66: "freezing", 67: "freezing",
             71: "flurries", 73: "snow", 75: "snow", 77: "flurries", 80: "showers", 81: "showers",
             82: "heavy_rain", 85: "flurries", 86: "snow", 95: "thunder", 96: "thunder", 99: "thunder"}
    return table.get(c, "unknown")


def from_owm(wid):
    if wid is None:
        return "unknown"
    w = int(wid)
    if 200 <= w < 300:
        return "thunder"
    if 300 <= w < 400:
        return "drizzle"
    if w in (500, 501):
        return "rain"
    if 502 <= w <= 504:
        return "heavy_rain"
    if w == 511:
        return "freezing"
    if 520 <= w < 600:
        return "showers"
    if w in (611, 612, 613):
        return "sleet"
    if w in (615, 616):
        return "mix"
    if w in (600, 620):
        return "flurries"
    if 600 <= w < 700:
        return "snow"
    if w in (701, 741):
        return "fog"
    if w == 711:
        return "smoke"
    if w == 721:
        return "haze"
    if w in (731, 751, 761, 762):
        return "dust"
    if w in (771, 781):
        return "wind"
    return {800: "clear", 801: "mostly_clear", 802: "partly", 803: "mostly_cloudy", 804: "cloudy"}.get(w, "unknown")


def from_clouds(clouds, pop=None):
    if pop is not None and pop >= 50:
        return "showers"
    if clouds is None:
        return "unknown"
    if clouds < 12:
        return "clear"
    if clouds < 35:
        return "mostly_clear"
    if clouds < 65:
        return "partly"
    if clouds < 88:
        return "mostly_cloudy"
    return "cloudy"


def label(kind):
    return {"clear": "Clear", "mostly_clear": "Mostly clear", "partly": "Partly cloudy",
            "mostly_cloudy": "Mostly cloudy", "cloudy": "Cloudy", "fog": "Fog", "haze": "Haze",
            "smoke": "Smoke", "dust": "Dust", "wind": "Windy", "drizzle": "Drizzle", "rain": "Rain",
            "showers": "Showers", "heavy_rain": "Heavy rain", "thunder": "Thunderstorms", "snow": "Snow",
            "flurries": "Flurries", "sleet": "Sleet", "freezing": "Freezing rain", "mix": "Wintry mix"
            }.get(kind, "")


# ----------------------------------------------------------------------------
# line-art icons: 5 rows x 13 columns
# ----------------------------------------------------------------------------

_SUN = ["   \\  │  /   ",
        "    ╭───╮    ",
        " ── │   │ ── ",
        "    ╰───╯    ",
        "   /  │  \\   "]
_MOON = ["    .--.   * ",
         "   /  ,'     ",
         "  |  (    *  ",
         "   \\  `.     ",
         "    `--'  *  "]
_CLOUD = ["             ",
          "     .--.    ",
          "  .-(    ).  ",
          " (___.__)__) ",
          "             "]
_CLOUD_HI = ["     .--.    ",
             "  .-(    ).  ",
             " (___.__)__) ",
             "             ",
             "             "]
_PARTLY_SUN = ["\\ │ /        ",
               "─( )─  .--.  ",
               "/ │ \\.(    ).",
               "   (___.__)_)",
               "             "]
_PARTLY_MOON = ["  .-.        ",
                " (  (  .--.  ",
                "  `-'.(    ).",
                "   (___.__)_)",
                "             "]
_MOSTLY_CLOUDY = ["  \\ /        ",
                  " ─( ).--.    ",
                  "  .-(    ).  ",
                  " (___.__)__) ",
                  "             "]
_FOG = ["             ",
        " _ ‒ _ ‒ _ ‒ ",
        "  _ ‒ _ ‒ _  ",
        " _ ‒ _ ‒ _ ‒ ",
        "             "]
_WIND = ["             ",
         "  ─────────╮ ",
         " ──────────╯ ",
         "   ──────╮   ",
         "   ──────╯   "]
_TAILS = {
    "drizzle": ["   '  '  '   ", "  '  '  '    "],
    "rain": ["  ╱ ╱ ╱ ╱    ", " ╱ ╱ ╱ ╱     "],
    "heavy_rain": [" ╱╱╱╱╱╱╱╱   ", "╱╱╱╱╱╱╱╱    "],
    "showers": ["  ╱   ╱  ╱   ", "   ╱   ╱     "],
    "thunder": ["   /_  ╱ /_  ", "    /  ╱  /  "],
    "snow": ["  *  *  *  * ", " *  *  *  *  "],
    "flurries": ["   *    *    ", "     *    *  "],
    "sleet": ["  * ╱ * ╱    ", " ╱ * ╱ *     "],
    "freezing": ["  ╱ ╱ ╱ ╱    ", " ~ ~ ~ ~     "],
    "mix": ["  * ╱ * ╱    ", " ╱ * ╱ *     "],
}
_TAIL_STYLE = {"drizzle": "rain", "rain": "rain", "heavy_rain": "rain", "showers": "rain", "thunder": "accent",
               "snow": "snow", "flurries": "snow", "sleet": "snow", "freezing": "rain", "mix": "snow"}
_ASCII_MAP = str.maketrans({"│": "|", "─": "-", "╭": ".", "╮": ".", "╰": "'", "╯": "'", "╱": "/", "‒": "-"})


def _rows(rows, styles):
    return [[(r, s)] for r, s in zip(rows, styles)]


def art(kind, is_day=True, ascii_only=False):
    """5 lines of 13 columns."""
    sun, cloud, dark = "title", "value", "dim"
    if kind in ("clear", "mostly_clear"):
        rows = _SUN if is_day else _MOON
        out = _rows(rows, [sun if is_day else "t_mild"] * 5)
    elif kind == "partly":
        rows = _PARTLY_SUN if is_day else _PARTLY_MOON
        out = []
        for i, r in enumerate(rows):
            split = 5 if i < 3 else 0
            if i == 1:
                out.append([(r[:5], sun if is_day else "t_mild"), (r[5:], cloud)])
            elif i == 2:
                out.append([(r[:5], sun if is_day else "t_mild"), (r[5:], cloud)])
            elif i == 0:
                out.append([(r, sun if is_day else "t_mild")])
            else:
                out.append([(r[split:], cloud)] if split else [(r, cloud)])
    elif kind == "mostly_cloudy":
        out = [[(_MOSTLY_CLOUDY[0], sun if is_day else "t_mild")],
               [(_MOSTLY_CLOUDY[1][:5], sun if is_day else "t_mild"), (_MOSTLY_CLOUDY[1][5:], cloud)],
               [(_MOSTLY_CLOUDY[2], cloud)], [(_MOSTLY_CLOUDY[3], cloud)], [(_MOSTLY_CLOUDY[4], cloud)]]
    elif kind == "cloudy":
        out = _rows(_CLOUD, [cloud] * 5)
    elif kind in ("fog", "haze", "smoke", "dust"):
        st = {"fog": "dim", "haze": "warn", "smoke": "dim", "dust": "accent"}[kind]
        out = _rows(_FOG, [st] * 5)
    elif kind == "wind":
        out = _rows(_WIND, ["label"] * 5)
    elif kind in _TAILS:
        cst = dark if kind in ("thunder", "heavy_rain") else cloud
        out = _rows(_CLOUD_HI[:3], [cst] * 3) + _rows(_TAILS[kind], [_TAIL_STYLE[kind]] * 2)
    else:
        rows = list(_CLOUD)
        rows[2] = "  .-(  ? ).  "
        out = _rows(rows, ["dim"] * 5)
    if ascii_only:
        out = [[(t.translate(_ASCII_MAP), s) for t, s in ln] for ln in out]
    return out


def mini(kind, is_day=True, ascii_only=False):
    """A two-character tag for tight table cells."""
    if ascii_only:
        return {"clear": "Sun", "mostly_clear": "Sun", "partly": "P/C", "mostly_cloudy": "M/C", "cloudy": "Cld",
                "fog": "Fog", "rain": "Rn", "showers": "Shw", "thunder": "Tst", "snow": "Sn"}.get(kind, "")
    return {"clear": ("☼" if is_day else "☾"), "mostly_clear": ("☼" if is_day else "☾")}.get(kind, "")


# ----------------------------------------------------------------------------
# pixel icons (Pillow)
# ----------------------------------------------------------------------------

def _cloud_shape(draw, cx, cy, w, fill, outline=None):
    """Draw a puffy cloud centered at (cx, cy), w wide."""
    h = w * 0.55
    base_y = cy + h * 0.22
    puffs = [(cx - w * 0.26, base_y - h * 0.18, w * 0.22), (cx - w * 0.02, base_y - h * 0.42, w * 0.28),
             (cx + w * 0.25, base_y - h * 0.16, w * 0.22)]
    for (x, y, r) in puffs:
        draw.ellipse([x - r, y - r, x + r, y + r], fill=fill)
    draw.rounded_rectangle([cx - w * 0.48, base_y - h * 0.22, cx + w * 0.48, base_y + h * 0.25],
                           radius=h * 0.22, fill=fill)


def _sun_shape(draw, cx, cy, r, rays=True):
    if rays:
        for k in range(12):
            a = k * math.pi / 6
            x0, y0 = cx + math.cos(a) * r * 1.25, cy + math.sin(a) * r * 1.25
            x1, y1 = cx + math.cos(a) * r * 1.7, cy + math.sin(a) * r * 1.7
            draw.line([x0, y0, x1, y1], fill=(255, 196, 40, 255), width=max(2, int(r * 0.18)))
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 214, 40, 255))
    draw.ellipse([cx - r * 0.72, cy - r * 0.78, cx + r * 0.55, cy + r * 0.4], fill=(255, 236, 120, 255))


def _moon_shape(draw, cx, cy, r, bg):
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(246, 236, 180, 255))
    # cut the crescent out of the disc (the layer is transparent, so this leaves a hole)
    draw.ellipse([cx - r * 0.45, cy - r * 1.05, cx + r * 1.45, cy + r * 0.85], fill=(0, 0, 0, 0))


def pixel_icon(kind, is_day, w, h, bg=(11, 22, 92), outline=None):
    """Return an RGB PIL image w x h of the icon over `bg`; `outline` rims every shape
    in that color (used on light themes, where white clouds would vanish)."""
    if not gfx.HAVE_PIL:
        return None
    S = 4
    W, H = max(8, w * S), max(8, h * S)
    bg = tuple(bg[:3])
    img = gfx.Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = gfx.ImageDraw.Draw(img)
    u = min(W, H * 1.15)
    cx, cy = W / 2, H / 2
    white, gray, dark = (245, 247, 255, 255), (200, 206, 222, 255), (120, 128, 150, 255)
    if kind in ("clear", "mostly_clear"):
        if is_day:
            _sun_shape(d, cx, cy, u * 0.24)
        else:
            _moon_shape(d, cx, cy, u * 0.3, bg)
            for (sx, sy) in ((0.78, 0.22), (0.86, 0.6), (0.2, 0.8)):
                d.ellipse([W * sx - S * 2, H * sy - S * 2, W * sx + S * 2, H * sy + S * 2], fill=white)
        if kind == "mostly_clear":
            _cloud_shape(d, cx + u * 0.22, cy + u * 0.22, u * 0.42, white)
    elif kind in ("partly", "mostly_cloudy"):
        if is_day:
            _sun_shape(d, cx - u * 0.16, cy - u * 0.12, u * 0.2)
        else:
            _moon_shape(d, cx - u * 0.18, cy - u * 0.14, u * 0.22, bg)
        _cloud_shape(d, cx + u * 0.08, cy + u * 0.12, u * (0.62 if kind == "partly" else 0.78),
                     white if kind == "partly" else gray)
    elif kind == "cloudy":
        _cloud_shape(d, cx - u * 0.12, cy - u * 0.08, u * 0.55, dark)
        _cloud_shape(d, cx + u * 0.06, cy + u * 0.06, u * 0.75, gray)
    elif kind in ("fog", "haze", "smoke", "dust"):
        col = {"fog": gray, "haze": (230, 200, 120, 255), "smoke": (170, 160, 160, 255),
               "dust": (210, 160, 90, 255)}[kind]
        for k in range(4):
            y = H * (0.28 + k * 0.15)
            off = (k % 2) * W * 0.08
            d.rounded_rectangle([W * 0.12 + off, y, W * 0.88 - off, y + H * 0.06], radius=H * 0.03, fill=col)
    elif kind == "wind":
        col = (170, 210, 255, 255)
        for k, (y, l) in enumerate(((0.32, 0.72), (0.5, 0.86), (0.68, 0.6))):
            d.line([W * 0.1, H * y, W * l, H * y], fill=col, width=int(S * 2.5))
            d.arc([W * l - H * 0.08, H * y - H * 0.16, W * l + H * 0.08, H * y], 270, 180, fill=col,
                  width=int(S * 2.5))
    else:
        cloud = dark if kind in ("thunder", "heavy_rain") else gray if kind in ("rain", "freezing") else white
        _cloud_shape(d, cx, cy - u * 0.14, u * 0.78, cloud)
        top, bot = cy + u * 0.12, cy + u * 0.42
        if kind in ("rain", "drizzle", "showers", "heavy_rain", "freezing"):
            n = {"drizzle": 3, "showers": 3, "rain": 4, "heavy_rain": 6, "freezing": 4}[kind]
            col = (90, 200, 255, 255) if kind != "freezing" else (180, 230, 255, 255)
            for k in range(n):
                x = cx - u * 0.3 + k * (u * 0.6 / max(1, n - 1))
                ln = 0.5 if kind == "drizzle" else 1.0
                d.line([x, top, x - u * 0.08 * ln, top + (bot - top) * ln], fill=col, width=int(S * 2.2))
        if kind in ("snow", "flurries", "sleet", "mix"):
            n = 2 if kind == "flurries" else 3
            for k in range(n):
                x = cx - u * 0.22 + k * (u * 0.44 / max(1, n - 1))
                y = top + (bot - top) * (0.35 + 0.3 * (k % 2))
                r = u * 0.06
                for a in range(3):
                    ang = a * math.pi / 3
                    d.line([x - math.cos(ang) * r, y - math.sin(ang) * r, x + math.cos(ang) * r,
                            y + math.sin(ang) * r], fill=white, width=int(S * 1.6))
            if kind in ("sleet", "mix"):
                d.line([cx + u * 0.3, top, cx + u * 0.24, bot], fill=(90, 200, 255, 255), width=int(S * 2.2))
        if kind == "thunder":
            pts = [(cx + u * 0.02, top - u * 0.02), (cx - u * 0.12, cy + u * 0.3), (cx - u * 0.01, cy + u * 0.3),
                   (cx - u * 0.1, bot + u * 0.06), (cx + u * 0.14, cy + u * 0.22), (cx + u * 0.02, cy + u * 0.22),
                   (cx + u * 0.12, top - u * 0.02)]
            d.polygon(pts, fill=(255, 210, 40, 255))
    out = gfx.Image.new("RGBA", (W, H), bg + (255,))
    if outline is not None:
        # grow the shapes' mask by a few pixels (shifted copies, cheap at any size)
        r = max(int(S * 1.25), int(min(W, H) * 0.014))   # at least a pixel once scaled down
        a = gfx.Image.new("L", (W + 2 * r + 2, H + 2 * r + 2), 0)   # padded, so shifts don't wrap
        a.paste(img.getchannel("A").point(lambda v: 255 if v > 96 else 0), (r + 1, r + 1))
        grown = a
        for k in (r, max(1, r // 2)):
            q = max(1, int(k * 0.7))
            for dx, dy in ((k, 0), (-k, 0), (0, k), (0, -k), (q, q), (q, -q), (-q, q), (-q, -q)):
                grown = gfx.ImageChops.lighter(grown, gfx.ImageChops.offset(a, dx, dy))
        rim = gfx.Image.new("RGBA", (W + 2 * r + 2, H + 2 * r + 2), tuple(outline[:3]) + (255,))
        rim.putalpha(grown)
        rim.alpha_composite(img, (r + 1, r + 1))
        # shapes that touch the edge would lose their rim there: shrink the drawing to fit
        img = rim.resize((W, H), gfx.LANCZOS)
    out.alpha_composite(img)
    return out.resize((w, h), gfx.LANCZOS).convert("RGB")


def raindrop_icon(size=256):
    """skydrop's app icon: a raindrop on a rounded royal-blue tile (RGBA, transparent corners)."""
    if not gfx.HAVE_PIL:
        return None
    S = 4
    N = size * S
    img = gfx.Image.new("RGBA", (N, N), (0, 0, 0, 0))
    # the tile: navy at the top to royal blue at the bottom
    tile = gfx.Image.new("RGBA", (N, N), (0, 0, 0, 0))
    td = gfx.ImageDraw.Draw(tile)
    top, bot = (10, 22, 84), (34, 76, 178)
    for y in range(N):
        f = y / (N - 1)
        td.line([0, y, N, y], fill=tuple(int(a + (b - a) * f) for a, b in zip(top, bot)) + (255,))
    mask = gfx.Image.new("L", (N, N), 0)
    gfx.ImageDraw.Draw(mask).rounded_rectangle([N * 0.04, N * 0.04, N * 0.96, N * 0.96], radius=N * 0.2, fill=255)
    img.paste(tile, (0, 0), mask)
    # the drop: x = sin t * sin^m(t/2), y = cos t (point at the top)
    cx, cy, rw, rh = N * 0.5, N * 0.52, N * 0.27, N * 0.36
    pts = []
    for k in range(361):
        t = math.radians(k)
        x = math.sin(t) * math.sin(t / 2) ** 1.25
        y = math.cos(t)
        pts.append((cx + x * rw * 1.45, cy - y * rh))
    drop_mask = gfx.Image.new("L", (N, N), 0)
    gfx.ImageDraw.Draw(drop_mask).polygon(pts, fill=255)
    grad = gfx.Image.new("RGBA", (N, N), (0, 0, 0, 0))
    gd = gfx.ImageDraw.Draw(grad)
    y0, y1 = cy - rh, cy + rh
    c0, c1 = (176, 232, 255), (24, 116, 236)
    for y in range(int(y0), int(y1) + 1):
        f = max(0.0, min(1.0, (y - y0) / (y1 - y0)))
        gd.line([0, y, N, y], fill=tuple(int(a + (b - a) * f) for a, b in zip(c0, c1)) + (255,))
    # a soft dark rim so the drop stands off the tile
    rim = gfx.Image.new("RGBA", (N, N), (4, 12, 48, 170))
    rim.putalpha(drop_mask.filter(gfx.ImageFilter.GaussianBlur(N * 0.012)).point(lambda v: int(v * 0.75)))
    img.alpha_composite(rim, (int(N * 0.006), int(N * 0.012)))
    img.paste(grad, (0, 0), drop_mask)
    # highlight: a white sliver on the upper left of the bulb
    hl = gfx.Image.new("L", (N, N), 0)
    hd = gfx.ImageDraw.Draw(hl)
    hd.arc([cx - rw * 0.95, cy - rh * 0.1, cx + rw * 0.55, cy + rh * 0.88], 160, 235, fill=235, width=int(N * 0.035))
    img.paste(gfx.Image.new("RGBA", (N, N), (255, 255, 255, 255)), (0, 0), hl)
    hd2 = gfx.ImageDraw.Draw(img)
    r = N * 0.022
    hx, hy = cx - rw * 0.62, cy + rh * 0.02
    hd2.ellipse([hx - r, hy - r, hx + r, hy + r], fill=(255, 255, 255, 220))
    return img.resize((size, size), gfx.LANCZOS)
