"""skydrop - a retro "Weather Channel" style weather dashboard for the terminal."""

APP = "skydrop"
VERSION = "3.1.1"
