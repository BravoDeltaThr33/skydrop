"""The WeatherSTAR-style "lower display line" along the bottom of the screen."""

import time

from . import ui
from .radar import summary_lines
from .wxmath import aqi_cat, compass, moon_info


def build_items(m, F, radar_res=None):
    items = []
    loc = m.get("loc") or {}
    now = m.get("now") or {}
    temp = now.get("temp")
    desc = now.get("desc") or ""
    name = loc.get("name") or "your location"
    for a in (m.get("alerts") or [])[:3]:
        until = f" until {F.dtime(a['end'])}" if a.get("end") else ""
        items.append(("ALERT", f"{a['event']}{until}", "ldlalert"))
    if temp is not None:
        items.append((f"Conditions at {name}", f"{desc.capitalize() or 'Reported'}   {F.t(temp, True)}", "ldl"))
    feels, rh, dew = now.get("feels"), now.get("rh"), now.get("dew")
    bits = []
    if feels is not None:
        bits.append(f"Feels like {F.t(feels)}")
    if rh is not None:
        bits.append(f"Humidity {rh:.0f}%")
    if dew is not None:
        bits.append(f"Dew point {F.t(dew)}")
    if bits:
        items.append(("Comfort", "   ".join(bits), "ldl"))
    wind = now.get("wind")
    if wind is not None:
        deg, gust = now.get("wind_deg"), now.get("gust")
        w = "Calm" if wind < 0.5 else f"{compass(deg)} {F.wind(wind)}"
        if gust and gust > wind + 1:
            w += f"   Gusts {F.wind(gust)}"
        press = now.get("press")
        if press is not None:
            tr = (m.get("obs") or {}).get("trend")
            word = "" if tr is None else " rising" if tr > 0.6 else " falling" if tr < -0.6 else " steady"
            w += f"   Pressure {F.press(press)}{word}"
        items.append(("Wind", w, "ldl"))
    for pname, text in ui.periods_text(m, 2):
        short = text.split(". ")[0].rstrip(".") + "."
        items.append((pname, short, "ldl"))
    if radar_res is not None:
        lines = summary_lines(radar_res, F, compact=True)
        if lines:
            items.append(("Radar", "  ".join(t for t, _s in lines[:2]), "ldl"))
    air = m.get("air") or {}
    if air.get("us") is not None:
        items.append(("Air quality", f"{air['us']} {aqi_cat(air['us'])[0]}" +
                      (f"   mainly {air['dominant']}" if air.get("dominant") else ""), "ldl"))
    a = m.get("almanac") or {}
    if a.get("normal_hi") is not None:
        s = f"Normal {F.t(a['normal_hi'])}/{F.t(a['normal_lo'])}"
        if a.get("rec_hi") is not None:
            s += f"   Record high {F.t(a['rec_hi'])} ({a.get('rec_hi_year')})   Record low {F.t(a.get('rec_lo'))} ({a.get('rec_lo_year')})"
        items.append(("Almanac", s, "ldl"))
    sr, ss, _ = ui.sun_pair(m, F)
    if sr and ss:
        age, illum, mname = moon_info(time.time())
        items.append(("Sun & moon", f"Sunrise {F.time(sr)}   Sunset {F.time(ss)}   {mname} {illum * 100:.0f}%", "ldl"))
    st = (m.get("stations") or {}).get("summary") or {}
    if st.get("n"):
        items.append(("Area stations", f"{st['n']} reporting   {F.t(st['min'])} to {F.t(st['max'])}"
                      + (f"   warmest {st['warm']['name']}" if st.get("warm") else ""), "ldl"))
    for o in (m.get("outlooks") or [])[:2]:
        if o["category"] == "CATEGORICAL" and (o.get("level") or 0) >= 1:
            items.append(("Outlook", f"{o['word']} risk of {o['kind'].lower()} on day {o['day']}", "ldl"))
    return items


class Ticker:
    def __init__(self):
        self.items = []
        self.t0 = time.time()

    def update(self, items):
        if [i[:2] for i in items] != [i[:2] for i in self.items]:
            self.items = items

    def page(self, now):
        """Index of the item to show and seconds into it (paged mode)."""
        if not self.items:
            return -1, 0
        durs = [4.0 + max(0, len(i[0]) + len(i[1]) - 50) / 12.0 for i in self.items]
        total = sum(durs)
        t = (now - self.t0) % total
        for k, d in enumerate(durs):
            if t < d:
                return k, t
            t -= d
        return len(self.items) - 1, 0

    def render(self, W, mode="paged", now=None):
        now = now or time.time()
        if not self.items or mode == "off":
            return [(" " * W, "ldl")]
        if mode == "crawl":
            parts = []
            for label, text, st in self.items:
                parts.append((f"{label}: ", "ldllabel" if st == "ldl" else st))
                parts.append((f"{text}", "ldl" if st == "ldl" else st))
                parts.append(("   •   ", "ldldim"))
            flat = []
            for text, st in parts:
                flat += [(ch, st) for ch in text]
            n = len(flat)
            off = int((now - self.t0) * 10) % n
            seq = (flat[off:] + flat[:off]) * (W // n + 2)
            seq = seq[:W]
            out = []
            for ch, st in seq:
                if out and out[-1][1] == st:
                    out[-1] = (out[-1][0] + ch, st)
                else:
                    out.append((ch, st))
            return out
        k, t = self.page(now)
        label, text, st = self.items[k]
        lab = f" {label} "
        room = W - len(lab) - 2
        body = text
        if len(body) > room > 10:
            shift = int(max(0.0, t - 1.5) * 12)
            span = len(body) - room
            body = body[min(shift, span):][:room]
        seg_style = "ldl" if st == "ldl" else st
        lab_style = "ldllabel" if st == "ldl" else st
        out = [(lab, lab_style), ("  ", seg_style), (body, seg_style)]
        used = len(lab) + 2 + len(body)
        dots = f" {k + 1}/{len(self.items)} "
        if W - used > len(dots) + 2:
            out.append((" " * (W - used - len(dots)), seg_style))
            out.append((dots, "ldldim" if st == "ldl" else st))
        else:
            out.append((" " * max(0, W - used), seg_style))
        return out


SPEEDS = {"slow": 6.0, "normal": 10.0, "fast": 16.0}


class AlertCrawl:
    """The warnings crawl along the bottom: every watch, warning and storm report in
    the chosen area, colour-coded, restarting at the newest one when it arrives."""

    def __init__(self):
        self.items = []
        self.t0 = time.time()
        self.keys = set()

    def update(self, items, now=None):
        now = now or time.time()
        keys = {i[4] for i in items}
        arrived = [i for i in items if i[4] not in self.keys and i[3]]
        if arrived and self.keys is not None:
            # put what just arrived first and start the crawl over so it's seen right away
            first = arrived[0][4]
            items = sorted(items, key=lambda i: 0 if i[4] == first else 1)
            self.t0 = now
        self.items = items
        self.keys = keys

    @staticmethod
    def _shade(rgb, f):
        return tuple(int(c * f) for c in rgb)

    def render(self, W, now, calm, speed="normal", ascii_only=False):
        if not self.items:
            return calm
        flat = []
        blink = int(now * 2) % 2 == 0
        for label, text, rgb, new, _key in self.items:
            dark = sum(rgb) / 3 > 140 and rgb[0] > 200 and rgb[1] > 180
            fg = (10, 10, 30) if dark else (255, 255, 255)
            lab_style = ("rgb", fg, rgb, "b")
            body_style = ("rgb", (255, 255, 255), self._shade(rgb, 0.32), "")
            if new:
                tag = " NEW " if not ascii_only else " NEW "
                flat += [(ch, ("rgb", (20, 10, 0), (255, 214, 0) if blink else (255, 150, 0), "b")) for ch in tag]
            flat += [(ch, lab_style) for ch in f" {label} "]
            flat += [(ch, body_style) for ch in f" {text} "]
            flat += [(ch, "status") for ch in ("   ◆   " if not ascii_only else "   *   ")]
        n = len(flat)
        if n <= W:
            seq = flat + [(" ", "status")] * (W - n)
        else:
            off = int((now - self.t0) * SPEEDS.get(speed, 10.0)) % n
            seq = (flat[off:] + flat[:off] + flat)[:W]
        out = []
        for ch, st in seq:
            if out and out[-1][1] == st:
                out[-1] = (out[-1][0] + ch, st)
            else:
                out.append((ch, st))
        return out
