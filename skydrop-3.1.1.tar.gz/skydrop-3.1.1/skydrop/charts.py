"""Charts: pixel versions for kitty/sixel terminals, text versions for the rest."""

import math

from . import gfx
from .text import BLOCKS, braille_plot, resample
from .theme import blend, full_palette


class Ink:
    """The colors a chart is drawn with, taken from the theme so charts read on any page,
    light or dark."""

    def __init__(self, theme=None, bg=None):
        p = theme.pal if theme is not None else full_palette("weatherstar")
        self.light = bool(p.get("light"))
        self.bg = tuple(bg) if bg is not None else p["bg"]
        self.grid, self.axis, self.day, self.text = p["faint"], p["label"], p["title"], p["value"]
        self.feels, self.pop = p["dim"], p["rain"]
        self.amount = blend(p["rain"], p["value"], 0.35)
        self.lo, self.hi = p["t_cold"], p["t_warm"]
        self.sun, self.sun_line = p["title_bg"], p["t_warm"]
        self.twilight, self.night = p["label"], p["faint"]
        self.band = (0, 0, 0, 12) if self.light else (255, 255, 255, 10)
        self.stops = [(0, p["t_frigid"]), (32, p["t_cold"]), (50, p["t_cool"]), (65, p["t_mild"]),
                      (75, p["t_warm"]), (85, p["t_hot"]), (100, p["t_scorch"])]

    def temp(self, c):
        return _temp_rgb(c, self)


def _temp_rgb(c, ink=None):
    """Color for a temperature in Celsius along the theme's cold-to-hot scale."""
    if ink is not None and not isinstance(ink, Ink):
        ink = Ink(ink)                     # a Theme
    if c is None:
        return ink.feels if ink else (200, 200, 200)
    f = c * 9 / 5 + 32
    stops = ink.stops if ink else Ink().stops
    if f <= stops[0][0]:
        return stops[0][1]
    for (f0, c0), (f1, c1) in zip(stops, stops[1:]):
        if f <= f1:
            return blend(c0, c1, (f - f0) / (f1 - f0))
    return stops[-1][1]


def hourly_chart(rows, F, w, h, bg=None, theme=None):
    """Temperature line, feels-like line, precip-chance bars and amounts."""
    ink = Ink(theme, bg)
    bg = ink.bg
    S = 2
    W, H = w * S, h * S
    img = gfx.Image.new("RGB", (W, H), bg)
    d = gfx.ImageDraw.Draw(img, "RGBA")
    if not rows:
        return img.resize((w, h), gfx.LANCZOS)
    fsz = max(10, int(H * 0.075))
    fnt = gfx.font(fsz, bold=True)
    small = gfx.font(max(9, int(fsz * 0.85)), bold=False)
    left, right, top, bottom = int(fsz * 3.0), int(fsz * 1.2), int(fsz * 1.6), int(fsz * 2.2)
    pw, ph = W - left - right, H - top - bottom
    n = len(rows)
    temps = [F.tv(r.get("temp")) for r in rows]
    feels = [F.tv(r.get("feels")) for r in rows]
    vals = [v for v in temps + feels if v is not None]
    if not vals:
        return img.resize((w, h), gfx.LANCZOS)
    lo, hi = min(vals), max(vals)
    pad = max(2.0, (hi - lo) * 0.15)
    lo, hi = math.floor(lo - pad), math.ceil(hi + pad)

    def X(i):
        return left + (i + 0.5) * pw / n

    def Y(v):
        return top + (hi - v) / (hi - lo) * ph

    # grid
    stepv = 5 if hi - lo <= 30 else 10
    v = math.ceil(lo / stepv) * stepv
    while v <= hi:
        y = Y(v)
        d.line([left, y, W - right, y], fill=ink.grid + (150,), width=1)
        gfx.draw_text(d, (left - 6, y), f"{v:.0f}°", small, ink.axis + (255,), anchor="rm")
        v += stepv
    # precip chance bars
    for i, r in enumerate(rows):
        p = r.get("pop")
        if p:
            x0, x1 = left + i * pw / n + 1, left + (i + 1) * pw / n - 1
            y = top + ph - p / 100 * ph
            d.rectangle([x0, y, x1, top + ph], fill=ink.pop + (60 + int(p),))
        amt = (r.get("rain") or 0) + (r.get("snow") or 0)
        if amt > 0.05:
            x0, x1 = left + i * pw / n + 2, left + (i + 1) * pw / n - 2
            hh = min(ph * 0.35, amt / 5.0 * ph * 0.35 + 3)
            d.rectangle([x0, top + ph - hh, x1, top + ph], fill=ink.amount + (230,))
    # day separators and hour labels
    for i, r in enumerate(rows):
        t = F.local(r["t"])
        x = X(i)
        if t.hour == 0 and i:
            xs = left + i * pw / n
            d.line([xs, top, xs, top + ph], fill=ink.day + (140,), width=S)
            gfx.draw_text(d, (xs + 4, top + 2), f"{t:%a}", small, ink.day + (255,), anchor="lt")
        if t.hour % 3 == 0:
            lab = f"{t.hour % 12 or 12}{'a' if t.hour < 12 else 'p'}"
            gfx.draw_text(d, (x, top + ph + 6), lab, small, ink.axis + (255,), anchor="mt")
    # lines
    def poly(series, width, colfn, dash=False):
        # Joins neighbouring hours only, so a missing hour leaves a gap.
        for k in range(1, len(series)):
            a, b = series[k - 1], series[k]
            if a is None or b is None or (dash and k % 2):
                continue
            d.line([(X(k - 1), Y(a)), (X(k), Y(b))], fill=colfn((a + b) / 2) + (255,), width=width)

    poly(feels, S * 2, lambda v: ink.feels, dash=True)
    poly(temps, S * 3, lambda v: ink.temp(None if v is None else (v - 32) * 5 / 9 if F.imp else v))
    # labels at extremes
    tv = [(v, i) for i, v in enumerate(temps) if v is not None]
    if tv:
        vmax, imax = max(tv)
        vmin, imin = min(tv)
        for v, i, off in ((vmax, imax, -8), (vmin, imin, 14)):
            gfx.draw_text(d, (X(i), Y(v) + off), f"{v:.0f}°", fnt, ink.text + (255,), anchor="ms",
                          stroke=2, stroke_fill=bg)
    # legend
    lx = left
    gfx.draw_text(d, (lx, 4), "Temperature", small, ink.hi + (255,), anchor="lt")
    lx += gfx.text_width(d, "Temperature  ", small)
    gfx.draw_text(d, (lx, 4), "Feels like", small, ink.feels + (255,), anchor="lt")
    lx += gfx.text_width(d, "Feels like  ", small)
    gfx.draw_text(d, (lx, 4), "Precip chance", small, ink.pop + (255,), anchor="lt")
    return img.resize((w, h), gfx.LANCZOS)


def hourly_text(rows, F, width, height, ascii_only=False):
    """Braille temperature line over block-element precip bars."""
    n = len(rows)
    if not n or width < 10:
        return []
    temps = [F.tv(r.get("temp")) for r in rows]
    pops = [r.get("pop") for r in rows]
    tv = [t for t in temps if t is not None]
    if not tv:
        return []
    out = []
    lab_w = 5
    plot_w = max(8, width - lab_w)
    hi, lo = max(tv), min(tv)
    if ascii_only:
        from .text import spark
        out.append([(f"{hi:>3.0f}° ", "label"), (spark(resample(temps, plot_w), ascii_only=True), "t_warm")])
        out.append([(f"{lo:>3.0f}° ", "label"), (spark(resample(pops, plot_w), 0, 100, zero="_", ascii_only=True), "rain")])
        return out
    th = max(2, height - 2)
    plot = braille_plot([(temps, "t_warm")], plot_w, th, lo - 1, hi + 1)
    for i, ln in enumerate(plot):
        lab = f"{hi:>3.0f}° " if i == 0 else f"{lo:>3.0f}° " if i == th - 1 else " " * lab_w
        out.append([(lab, "label")] + ln)
    bars = []
    for p in resample(pops, plot_w):
        k = 0 if not p else max(1, int(round(p / 100 * 7)))
        bars.append(BLOCKS[k] if p else " ")
    out.append([("rain ", "label"), ("".join(bars), "rain")])
    # hour axis
    axis = [" "] * plot_w
    for i, r in enumerate(rows):
        hr = F.local(r["t"]).hour
        if hr % 6 == 0:
            pos = int(i * plot_w / n)
            lab = f"{hr % 12 or 12}{'a' if hr < 12 else 'p'}" if hr else F.local(r["t"]).strftime("%a")
            for k, ch in enumerate(lab):
                if pos + k < plot_w:
                    axis[pos + k] = ch
    out.append([(" " * lab_w, "text"), ("".join(axis), "dim")])
    return out


def moon_image(frac, w, h, bg=(11, 22, 92), waxing=True, theme=None):
    """Moon disc lit by phase fraction frac (0 new, 0.5 full)."""
    ink = Ink(theme, bg)
    S = 4
    W, H = w * S, h * S
    img = gfx.Image.new("RGB", (W, H), bg)
    d = gfx.ImageDraw.Draw(img)
    r = min(W, H) * 0.42
    cx, cy = W / 2, H / 2
    lit, dark = (238, 232, 196), (52, 58, 96)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=dark)
    # terminator: draw lit half then an ellipse to add/remove light
    phase = frac % 1.0
    illum = (1 - math.cos(2 * math.pi * phase)) / 2
    right_lit = phase < 0.5
    k = abs(1 - 2 * illum)  # ellipse half-width factor
    if right_lit:
        d.pieslice([cx - r, cy - r, cx + r, cy + r], -90, 90, fill=lit)
    else:
        d.pieslice([cx - r, cy - r, cx + r, cy + r], 90, 270, fill=lit)
    ex = r * k
    if illum < 0.5:
        d.ellipse([cx - ex, cy - r, cx + ex, cy + r], fill=dark)
    else:
        d.ellipse([cx - ex, cy - r, cx + ex, cy + r], fill=lit)
    # a few craters for texture
    for (ox, oy, rr) in ((-0.3, -0.25, 0.12), (0.2, 0.1, 0.16), (-0.1, 0.35, 0.09), (0.35, -0.35, 0.07)):
        x, y, q = cx + ox * r, cy + oy * r, rr * r
        px = img.getpixel((int(x), int(y)))
        if sum(px) < sum(lit) * 0.8:
            continue                      # craters only show on the lit face
        shade = tuple(max(0, c - 22) for c in px)
        d.ellipse([x - q, y - q, x + q, y + q], fill=shade)
    if ink.light:
        # on a light page the lit face would melt into the background: ring it
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=ink.feels, width=max(2, S))
    return img.resize((w, h), gfx.LANCZOS)


ASCII_MOON = {
    "New moon": ["   _..._   ", " .:::::::. ", ":::::::::::", ":::::::::::", "`:::::::::'", "  `':::'`  "],
    "Waxing crescent": ["   _..._   ", " .::::. `. ", ":::::::  :", ":::::::  :", "`::::::  .'", "  `'::.'`  "],
    "First quarter": ["   _..._   ", " .::::  `. ", "::::::    :", "::::::    :", "`:::::   .'", "  `'::.'`  "],
    "Waxing gibbous": ["   _..._   ", " .::'   `. ", ":::       :", ":::       :", "`::.     .'", "  `':..'`  "],
    "Full moon": ["   _..._   ", " .'     `. ", ":         :", ":         :", "`.       .'", "  `-...-'  "],
    "Waning gibbous": ["   _..._   ", " .'   `::. ", ":       :::", ":       :::", "`.     .::'", "  `-..:'`  "],
    "Last quarter": ["   _..._   ", " .'  ::::. ", ":    ::::::", ":    ::::::", "`.   :::::'", "  `-.::'`  "],
    "Waning crescent": ["   _..._   ", " .' .::::. ", ":  :::::::", ":  :::::::", "`. ::::::'", "  `-.::'`  "],
}


def sun_path_image(points, now_t, F, w, h, bg=None, theme=None):
    """Solar elevation across the day: points [(epoch, altitude)]."""
    ink = Ink(theme, bg)
    bg = ink.bg
    S = 2
    W, H = w * S, h * S
    img = gfx.Image.new("RGB", (W, H), bg)
    d = gfx.ImageDraw.Draw(img, "RGBA")
    if not points:
        return img.resize((w, h))
    fnt = gfx.font(max(9, int(H * 0.11)), bold=True)
    top, bottom = H * 0.12, H * 0.82
    horizon = top + (bottom - top) * 0.62
    amax = max(10.0, max(a for _t, a in points))
    amin = min(-20.0, min(a for _t, a in points))

    def Y(a):
        if a >= 0:
            return horizon - a / amax * (horizon - top)
        return horizon + a / amin * (bottom - horizon)

    n = len(points)
    for i, (t, a) in enumerate(points):
        x = i * W / max(1, n - 1)
        col = ink.sun if a > 0 else ink.twilight if a > -6 else ink.night
        d.line([x, horizon, x, Y(a)], fill=col + (110 if ink.light else 60,), width=S)
    d.line([(i * W / max(1, n - 1), Y(a)) for i, (t, a) in enumerate(points)], fill=ink.sun_line + (255,), width=S * 2)
    d.line([0, horizon, W, horizon], fill=ink.axis + (200,), width=S)
    # now marker
    t0, t1 = points[0][0], points[-1][0]
    if t0 <= now_t <= t1:
        i = (now_t - t0) / (t1 - t0) * (n - 1)
        a = points[int(i)][1]
        x = (now_t - t0) / (t1 - t0) * W
        r = S * 5
        d.ellipse([x - r, Y(a) - r, x + r, Y(a) + r], fill=ink.sun + (255,), outline=ink.text + (255,))
    for hr in (6, 12, 18):
        x = hr / 24 * W
        gfx.draw_text(d, (x, H - 4), {6: "6a", 12: "noon", 18: "6p"}[hr], fnt, ink.axis + (255,), anchor="mb")
    return img.resize((w, h), gfx.LANCZOS)


def _interp(vals, n):
    """Linear interpolation of day-centered values onto n samples (keeps gaps)."""
    m = len(vals)
    if m == 0 or n <= 0:
        return []
    out = []
    for i in range(n):
        x = (i + 0.5) * m / n - 0.5
        a = max(0, min(m - 1, int(math.floor(x))))
        b = min(m - 1, a + 1)
        f = min(1.0, max(0.0, x - a))
        va, vb = vals[a], vals[b]
        if va is None or vb is None:
            out.append(va if f < 0.5 else vb)
        else:
            out.append(va + (vb - va) * f)
    return out


def daily_chart(rows, F, w, h, bg=None, theme=None):
    """Highs and lows as lines with labels, precipitation chance as bars, one column per day."""
    ink = Ink(theme, bg)
    bg = ink.bg
    S = 2
    W, H = w * S, h * S
    img = gfx.Image.new("RGB", (W, H), bg)
    d = gfx.ImageDraw.Draw(img, "RGBA")
    rows = [r for r in rows if r.get("hi") is not None or r.get("lo") is not None]
    if not rows:
        return img.resize((w, h), gfx.LANCZOS)
    n = len(rows)
    fsz = max(10, int(H * 0.085))
    fnt = gfx.font(fsz, bold=True)
    small = gfx.font(max(9, int(fsz * 0.8)), bold=False)
    top, bottom = int(fsz * 1.6), int(fsz * 1.8)
    ph = H - top - bottom
    colw = W / n
    his = [F.tv(r.get("hi")) for r in rows]
    los = [F.tv(r.get("lo")) for r in rows]
    vals = [x for x in his + los if x is not None]
    lo, hi = min(vals), max(vals)
    pad = max(2.0, (hi - lo) * 0.25)
    lo, hi = lo - pad, hi + pad

    def X(i):
        return (i + 0.5) * colw

    def Y(v):
        return top + (hi - v) / (hi - lo) * ph * 0.78

    # day bands and precip chance bars along the bottom
    bar_h = ph * 0.22
    base = top + ph
    for i, r in enumerate(rows):
        if i % 2:
            d.rectangle([i * colw, top - fsz * 0.4, (i + 1) * colw, base], fill=ink.band)
        pop = r.get("pop") or 0
        if pop:
            bh = bar_h * pop / 100
            d.rectangle([X(i) - colw * 0.28, base - bh, X(i) + colw * 0.28, base], fill=ink.pop + (70 + int(pop),))
            if pop >= 10:
                gfx.draw_text(d, (X(i), base - bh - 2), f"{pop:.0f}%", small, ink.pop + (255,), anchor="mb")
    # lines
    for series, col in ((los, ink.lo + (255,)), (his, ink.hi + (255,))):
        pts = [(X(i), Y(v)) for i, v in enumerate(series) if v is not None]
        if len(pts) >= 2:
            d.line(pts, fill=col, width=S * 2)
    for i in range(n):
        for v, raw, above in ((his[i], rows[i].get("hi"), True), (los[i], rows[i].get("lo"), False)):
            if v is None:
                continue
            x, y = X(i), Y(v)
            r = S * 3
            d.ellipse([x - r, y - r, x + r, y + r], fill=ink.temp(raw) + (255,), outline=ink.text + (220,))
            gfx.draw_text(d, (x, y - r - 2) if above else (x, y + r + 2), f"{v:.0f}°", fnt,
                          ink.temp(raw) + (255,), anchor="mb" if above else "mt", stroke=S, stroke_fill=bg)
    # day labels
    for i, r in enumerate(rows):
        lab = "Today" if r["date"] == F.today() else f"{r['date']:%a}"
        gfx.draw_text(d, (X(i), H - 3), lab, small, ink.axis + (255,), anchor="mb")
    return img.resize((w, h), gfx.LANCZOS)


def daily_text(rows, F, width, height, ascii_only=False):
    """Text version: braille high/low lines, rain-chance blocks and a day axis."""
    rows = [r for r in rows if r.get("hi") is not None or r.get("lo") is not None]
    n = len(rows)
    if not n or width < 20:
        return []
    lab_w = 5
    colw = max(3, (width - lab_w) // n)
    pw = colw * n
    his = [F.tv(r.get("hi")) for r in rows]
    los = [F.tv(r.get("lo")) for r in rows]
    vals = [x for x in his + los if x is not None]
    hi, lo = max(vals), min(vals)
    out = []
    if ascii_only:
        from .text import spark
        out.append([(f"{hi:>3.0f}° ", "label"), (spark(_interp(his, pw), lo, hi, ascii_only=True), "t_warm")])
        out.append([(f"{lo:>3.0f}° ", "label"), (spark(_interp(los, pw), lo, hi, ascii_only=True), "t_cool")])
    else:
        th = max(2, height - 3)
        plot = braille_plot([(_interp(los, pw * 2), "t_cool"), (_interp(his, pw * 2), "t_warm")], pw, th, lo - 1, hi + 1)
        for i, ln in enumerate(plot):
            lab = f"{hi:>3.0f}° " if i == 0 else f"{lo:>3.0f}° " if i == th - 1 else " " * lab_w
            out.append([(lab, "label")] + ln)
    rain = []
    for r in rows:
        p = r.get("pop") or 0
        k = 0 if p < 5 else max(1, int(round(p / 100 * 7)))
        cell = (BLOCKS[k] if not ascii_only else " .:-=+*#"[k]) if k else " "
        txt = (f"{p:.0f}%" if p >= 10 else "").center(colw)
        rain.append((txt if p >= 10 and colw >= 4 else cell * (colw - 1) + " ", "rain"))
    out.append([("rain ", "label")] + rain)
    out.append([(" " * lab_w, "text")] + [(("Today" if r["date"] == F.today() else f"{r['date']:%a}")[:colw - 1].center(colw), "dim")
                                          for r in rows])
    return out
