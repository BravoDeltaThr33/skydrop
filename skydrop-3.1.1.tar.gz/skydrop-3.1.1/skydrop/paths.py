"""Where skydrop keeps its files (XDG locations)."""

import os

from . import APP

_CFG_HOME = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
_CACHE_HOME = os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache")
_DATA_HOME = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")

CONFIG_DIR = os.path.join(_CFG_HOME, APP)
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
CACHE_DIR = os.path.join(_CACHE_HOME, APP)
USAGE_PATH = os.path.join(CACHE_DIR, "owm_usage.json")
DISK_CACHE_DIR = os.path.join(CACHE_DIR, "http")
TTS_DIR = os.path.join(CACHE_DIR, "speech")
DATA_DIR = os.path.join(_DATA_HOME, APP)
VOICES_DIR = os.path.join(DATA_DIR, "voices")
LOG_PATH = os.path.join(CACHE_DIR, "skydrop.log")


def pretty_path(p):
    home = os.path.expanduser("~")
    return "~" + p[len(home):] if p.startswith(home) else p


def ensure(path):
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass
    return path
