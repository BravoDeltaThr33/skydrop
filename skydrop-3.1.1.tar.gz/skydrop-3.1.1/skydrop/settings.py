"""Settings screen (0)."""

import os
import re
import threading
import time

from . import sources as S
from . import ui
from .config import DEFAULT_NWS_BASE, DEFAULT_OWM_BASE, DEFAULTS
from .errlog import LOG
from .net import Http
from .paths import CONFIG_PATH, pretty_path
from .speech import VOICE_CHOICES, engine_status, find_player, voice_path
from .store import FALLBACK_COORDS, ONECALL_MSG, check_connections, geocode
from .term import (KEY_BACKSPACE, KEY_BTAB, KEY_DC, KEY_DOWN, KEY_END, KEY_ENTER, KEY_HOME, KEY_LEFT, KEY_NPAGE,
                   KEY_PPAGE, KEY_RIGHT, KEY_SLEFT, KEY_SRIGHT, KEY_UP, Paste)
from .text import clip, labeled_wrap, wrap
from .util import num

ONOFF = "choice:on,off"

# ("sec", title) | ("fld", key, label, type, help) | ("btn", action, label, None, help) | ("src", id)
FIELDS = [
    ("sec", "Location"),
    ("fld", "zip", "ZIP code", "zip",
     "A U.S. ZIP code, or a place such as Memphis, TN. Save (or press z on any screen) to pull its weather."),
    ("fld", "location_name", "Display name", "text",
     "Shown in the header. Leave blank to use the city NWS reports for the location."),
    ("fld", "lat", "Latitude", "lat",
     "Optional. When latitude and longitude are both set they're used instead of the ZIP code."),
    ("fld", "lon", "Longitude", "lon",
     "Optional. When latitude and longitude are both set they're used instead of the ZIP code."),
    ("fld", "country", "Country code", "country",
     "Two-letter code used for ZIP and place lookups. NWS, radar and station data cover the U.S."),
    ("fld", "nws_station", "NWS station", "station",
     "Observation station ID used for current conditions, such as KLIT. Leave blank for the nearest airport. "
     "Tip: on the Stations screen (5), press Enter on any station to use it."),
    ("sec", "Display"),
    ("fld", "units", "Units", "choice:imperial,metric", "Enter switches. The u key does the same on any screen."),
    ("fld", "theme", "Theme", "choice:weatherstar,midnight,retro8s,star4000,magnetic",
     "weatherstar: royal blue and gold, the classic Local on the 8s. midnight: near-black, easy on the eyes "
     "at night. retro8s: steel and sky-blue panels, gold headings, a navy-to-orange title bar. star4000: "
     "WeatherSTAR 4000 blue-violet with red-orange bars and yellow numbers. magnetic: light, the pale blue "
     "1970s TV weather board with yellow and black magnets."),
    ("fld", "graphics", "Graphics", "choice:auto,kitty,sixel,blocks,ascii",
     "auto picks the best your terminal supports: kitty (kitty, Ghostty, WezTerm) and sixel draw real "
     "pixels; blocks uses colored half-block characters (Tilix, GNOME Terminal); ascii is plain text."),
    ("fld", "color_mode", "Colors", "choice:auto,truecolor,256,16",
     "auto detects 24-bit color. Pick 256 or 16 if colors look wrong."),
    ("fld", "ticker", "Bottom ticker", "choice:paged,crawl,off",
     "The WeatherSTAR-style line along the bottom: paged shows one item at a time, crawl scrolls."),
    ("fld", "clock_seconds", "Clock seconds", ONOFF, "Show seconds on the header clock."),
    ("fld", "mouse", "Mouse", ONOFF, "Click tabs and rows, scroll with the wheel. Hold Shift to select text "
                                     "while the mouse is on."),
    ("fld", "refresh_seconds", "Refresh every", "int:10:3600",
     "Seconds between checks for new data: alerts, warnings, radar scans and observations (10 to 3600). "
     "Forecasts and other slow products still refresh on their own schedule, so 30 costs very little."),
    ("fld", "hourly_hours", "Hourly hours", "int:12:96", "How many hours the Hourly screen shows."),
    ("fld", "daily_days", "Daily days", "int:5:16", "How many days the 10-Day screen shows (NWS covers 7; "
                                                   "Open-Meteo extends to 16)."),
    ("sec", "Tornado alarm"),
    ("fld", "tornado_alarm", "Tornado alarm", ONOFF,
     "Sound an alarm when a new Tornado Warning covers your ZIP code (or upgrades to a Tornado Emergency). "
     "A red banner stays up until you press any key."),
    ("fld", "tornado_alarm_sound", "Alarm sound", "choice:noaa,nwr,eas",
     "noaa: the SAME data bursts then the 1050 Hz tone, the way NOAA Weather Radio sounds; nwr: the tone alone; "
     "eas: the two-tone broadcast attention signal."),
    ("fld", "tornado_alarm_repeat", "Repeat every", "int:0:30",
     "Minutes between repeats until you press a key; 0 plays it once."),
    ("fld", "tornado_alarm_voice", "Read it aloud", ONOFF, "Read the warning aloud after the alarm tone."),
    ("fld", "warning_alarm", "Other warnings", "choice:chime,nwr,off",
     "Sound for other new warnings that cover your ZIP code (severe thunderstorm, flash flood, and so on)."),
    ("fld", "auto_read_warnings", "Read warnings", ONOFF, "Also read those other warnings aloud."),
    ("fld", "background_watch", "Watch when closed", ONOFF,
     "Keep watching for tornado warnings after skydrop closes, and from the moment you log in: a small "
     "background watch sounds the same alarm and shows a desktop notification. Starts when you save."),
    ("btn", "test_alarm", "Test tornado alarm", None, "Play the tornado alarm exactly as it will sound, "
                                                       "with a test message instead of a warning. Key: A."),
    ("sec", "Warnings crawl"),
    ("fld", "alert_ticker", "Warnings crawl", ONOFF,
     "A crawl of watches, warnings and storm reports along the bottom, updated at every refresh."),
    ("fld", "ticker_area", "Crawl covers", "choice:zip,county,25,50,100,200,state",
     "Which alerts the crawl shows: your ZIP code; your county; warnings and watches within 25 to 200 miles "
     "(plus everything for your county); or everything issued for your state."),
    ("fld", "ticker_advisories", "Advisories too", ONOFF,
     "Include advisories and statements in the crawl, not just watches and warnings."),
    ("fld", "ticker_reports", "Storm reports", ONOFF,
     "Include local storm reports (tornado, hail, wind damage) in the crawl as they come in."),
    ("fld", "ticker_speed", "Crawl speed", "choice:slow,normal,fast", "How fast the warnings crawl moves."),
    ("sec", "Radar"),
    ("fld", "radar_source", "Radar source", "choice:site,mosaic",
     "site shows one NEXRAD radar at full resolution with all its Level 3 products, like Supercell Wx; mosaic "
     "is the national NOAA MRMS composite."),
    ("fld", "radar_site", "Radar site", "radarsite",
     "auto follows the radar nearest the map center; type an ID such as KFWS to stay on one radar."),
    ("fld", "radar_product", "Product", "choice:ref,vel,srv,cc,zdr,kdp,hc,hhc,et,vil,rate,p1h,pst,cr",
     "ref reflectivity, vel velocity, srv storm-relative velocity, cc correlation coefficient, zdr differential "
     "reflectivity, kdp specific differential phase, hc / hhc hydrometeor class, et echo tops, vil liquid water, "
     "rate rain rate, p1h / pst rainfall totals, cr composite reflectivity. Press i on the Radar screen for more."),
    ("fld", "radar_panes", "Panes", "choice:1,2,4", "One map, or two or four linked maps that pan and zoom together."),
    ("fld", "radar_pane_products", "Pane products", "products",
     "Products for the extra panes, in order, separated by commas (for example ref,vel,cc,zdr)."),
    ("fld", "radar_smooth", "Smoothing", ONOFF, "Blend neighbouring radar bins for a smoother picture."),
    ("fld", "radar_cells", "Storm tracks", ONOFF,
     "Storm cell tracks and forecast positions, hail, mesocyclones and tornado vortex signatures."),
    ("fld", "radar_min_dbz", "Hide below", "choice:-30,-10,0,5,10,15,20",
     "Hide reflectivity weaker than this many dBZ (5 hides most clear-air clutter)."),
    ("fld", "radar_opacity", "Opacity", "choice:30,40,50,60,70,80,90,100", "How solid the radar colors are, in percent."),
    ("fld", "radar_hover", "Hover readout", ONOFF, "Show the value under the mouse pointer in the radar sidebar."),
    ("fld", "placefiles", "Placefiles", "text",
     "GRLevelX placefile addresses (spotters, lightning, storm attributes, station plots), separated by spaces "
     "or commas. Local files work too, such as ~/wx/mine.txt. Toggle them with Placefiles on the Radar screen."),
    ("fld", "map_markers", "Map markers", "text", "Your own pins, such as Work: 32.78, -96.80; Home: 32.84, -96.78"),
    ("fld", "radar_span", "Map width", "choice:15,30,60,120,240,480,960", "Miles across the radar map; + and - "
                                                                          "change it on the Radar screen."),
    ("fld", "radar_frames", "Loop frames", "int:1:20", "Scans in the radar loop."),
    ("fld", "radar_step", "Frame spacing", "choice:2,5,10,15,20,30", "Minutes between loop frames."),
    ("fld", "radar_speed", "Loop speed", "int:1:10", "Frames per second."),
    ("fld", "radar_layer", "Mosaic layer", "choice:reflectivity,type,satellite,radar+sat",
     "For the national mosaic: reflectivity is classic radar; type colors rain, snow and ice; satellite adds "
     "GOES infrared clouds."),
    ("fld", "radar_basemap", "Background", "choice:classic,imagery,topo,osm,plain",
     "classic draws Census map lines on blue; imagery and topo use USGS; osm needs the OpenStreetMap source "
     "turned on below."),
    ("fld", "radar_labels", "City names", ONOFF, "Label towns on the map."),
    ("fld", "radar_stations", "Station temps", ONOFF, "Show live station temperatures on the map."),
    ("fld", "radar_warnings", "Warning boxes", ONOFF, "Draw storm-based warning polygons and watches."),
    ("sec", "Station feed"),
    ("fld", "station_radius", "Radius", "int:1:100", "Miles around the ZIP code to gather stations from."),
    ("fld", "station_max", "Max stations", "int:5:120", "Most NWS stations to poll for live observations."),
    ("sec", "Voice and sound"),
    ("fld", "voice_engine", "Speech engine", "choice:auto,piper,pico,espeak,festival,spd,off",
     "auto uses Piper when its voice is downloaded, then pico2wave, espeak-ng, festival or speech-dispatcher."),
    ("fld", "voice", "Piper voice", "choice:" + ",".join(VOICE_CHOICES),
     "Natural voices from the Piper project (about 60 MB each). Use Download voice after changing it."),
    ("fld", "voice_rate", "Speaking rate", "int:50:200", "Percent of normal speed."),
    ("fld", "audio_player", "Audio player", "choice:auto,pw-play,paplay,aplay,ffplay", "Program used to play sound."),
    ("fld", "narrate", "Narrate Local 8s", ONOFF, "Read each page aloud in Local on the 8s mode (L)."),
    ("fld", "local8s_seconds", "Page seconds", "int:5:60", "Seconds per page in Local on the 8s mode."),
    ("btn", "voice_dl", "Download voice", None, "Download the selected Piper voice from Hugging Face."),
    ("btn", "voice_test", "Test voice", None, "Speak a short sample with the current settings."),
    ("sec", "OpenWeather (optional)"),
    ("fld", "owm_api_key", "API key", "secret",
     "Optional: your own free key from openweathermap.org (My API keys). NWS and Open-Meteo cover "
     "forecasts without it. New keys can take a few hours to start working."),
    ("fld", "owm_shared_secret", "Shared secret", "secret", "Saved for later. OpenWeather doesn't use one today."),
    ("fld", "owm_onecall_version", "One Call version", "choice:auto,4.0,3.0,off",
     "auto tries 4.0, then 3.0, then the free endpoints; off uses only the free endpoints."),
    ("fld", "owm_daily_cap", "Daily call cap", "int:0:100000",
     "Stop billed One Call requests after this many in a UTC day. 1,000 a day are free; 0 turns One Call off."),
    ("fld", "owm_base_url", "API address", "url:" + DEFAULT_OWM_BASE,
     "Change only if OpenWeather moves its API. Clear the field to restore the default."),
    ("sec", "National Weather Service"),
    ("fld", "nws_user_agent", "User-Agent", "text",
     "Optional. Sent with every NWS request; the NWS asks every app to identify itself. Left empty, skydrop "
     "sends a generic one. Put your own, such as skydrop (you@example.com), so the NWS can reach you."),
    ("fld", "nws_api_key", "API key", "secret", "Sent as the API-Key header. The NWS API stays free."),
    ("fld", "nws_shared_secret", "Shared secret", "secret", "Saved for later. NWS doesn't use one today."),
    ("fld", "nws_feature_flags", "Feature flags", "flags",
     "Sent as the Feature-Flags header, comma-separated."),
    ("fld", "nws_base_url", "API address", "url:" + DEFAULT_NWS_BASE,
     "Change only if NWS moves its API. Clear the field to restore the default."),
    ("sec", "Data sources"),
] + [("src", s.id) for s in S.SOURCES] + [
    ("btn", "restore", "Restore deleted sources", None,
     "Bring back every data source you deleted. Key: R, from anywhere on this screen."),
    ("btn", "save", "Save and refresh", None,
     "Save these values and pull fresh data with them. Key: S or Ctrl-S, from anywhere on this screen."),
    ("btn", "test", "Test connections", None,
     "Check every enabled source with your current values. Key: T, from anywhere on this screen."),
    ("btn", "revert", "Discard changes", None,
     "Put back the saved values. Key: D twice, from anywhere on this screen."),
]
FIELD_BY_KEY = {it[1]: it for it in FIELDS if it[0] == "fld"}
LOCATION_KEYS = {"zip", "lat", "lon", "nws_station", "country"}
CREDENTIAL_KEYS = {"owm_api_key", "nws_user_agent", "nws_api_key", "owm_daily_cap", "owm_onecall_version",
                   "owm_base_url", "nws_base_url", "nws_feature_flags"}
DISPLAY_KEYS = {"theme", "graphics", "color_mode", "mouse"}
RADAR_KEYS = {"radar_source", "radar_site", "radar_product", "radar_panes", "radar_smooth", "radar_cells",
              "radar_labels", "radar_stations", "radar_warnings", "radar_layer", "radar_span"}
PLACE_RE = re.compile(r"[^\W\d_][\w .'-]*(,\s*[^\W\d_][\w .'-]*){0,2}")  # any alphabet: Zürich, Montréal
BUTTON_ROWS = [("test_alarm",), ("voice_dl", "voice_test"), ("restore",), ("save", "test", "revert")]
# keyboard shortcuts for the buttons (shown on them), and the keys that also work
BUTTON_KEYS = {"save": "S", "test": "T", "revert": "D", "restore": "R", "test_alarm": "A"}
SHORTCUTS = {"S": "save", "\x13": "save", "T": "test", "t": "test", "D": "revert", "R": "restore",
             "A": "test_alarm"}
KEY_LEGEND = [("↑↓", "move"), ("PgUp PgDn", "section"), ("Shift ←→", "column"), ("←→", "change"), ("Enter", "edit"),
              ("/", "find"), ("S", "save"), ("T", "test"), ("D", "discard"), ("R", "restore sources"),
              ("A", "test alarm"), ("v", "show keys"), ("x", "delete source"), ("e", "edit address"),
              ("Esc", "cancel")]


def nice_steps(lo, hi):
    """Round values between lo and hi for stepping a number with the arrow keys."""
    vals = {lo, hi}
    for e in range(0, 7):
        for m in (1, 1.5, 2, 2.5, 3, 4, 5, 6, 7.5, 8):
            v = m * 10 ** e
            if v == int(v) and lo <= v <= hi:
                vals.add(int(v))
    return sorted(vals)


def active_errors_panel(F, width):
    """Every problem since skydrop started that hasn't cleared yet."""
    items = LOG.active()
    out = [ui.section("Active errors", width, f"{len(items)} now" if items else "")]
    if not items:
        out.append([("  ✓ ", "good"), ("None right now.", "good")])
    for it in items:
        out.append(clip([("  ✗ ", "bad"), (it["label"], "bad")], width))
        out += wrap(it["msg"], width, "warn", 4)
        when = f"since {F.time(it['first'])}"
        if it["count"] > 1:
            when += f" · {it['count']} times · last {F.time(it['last'])}"
        out.append(clip([("    " + when, "dim")], width))
    note = f"skydrop started at {F.time(LOG.started)}"
    if LOG.cleared:
        note += f"; {LOG.cleared} error{'s' if LOG.cleared != 1 else ''} cleared since then"
    out += wrap(note + ". An error leaves this list as soon as that part works again.", width, "faint", 2)
    return out


def parse_field(item, raw):
    key, label, typ = item[1], item[2], item[3]
    raw = (raw or "").strip()
    if typ in ("text", "secret"):
        return raw, None
    if typ == "zip":
        mt = re.fullmatch(r"(\d{5})(?:-?\d{4})?", raw)
        if mt:
            return mt.group(1), None
        if not raw:
            return "", None
        if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 -]{1,9}", raw) and any(c.isdigit() for c in raw):
            return raw.upper(), None  # postal codes outside the U.S. (K1A 0B1, SW1A 1AA, 2000)
        if len(raw) <= 60 and PLACE_RE.fullmatch(raw):
            return ", ".join(p.strip() for p in raw.split(",")), None
        return None, "Enter a ZIP or postal code, or a place such as Memphis, TN."
    if typ == "country":
        val = raw.upper() or "US"
        if not re.fullmatch(r"[A-Z]{2}", val):
            return None, "Use a two-letter country code, such as US."
        return val, None
    if typ == "flags":
        flags = [f.strip() for f in raw.split(",") if f.strip()]
        if any(not re.fullmatch(r"[A-Za-z0-9_]+", f) for f in flags):
            return None, "Feature flags are words made of letters, digits, and underscores, separated by commas."
        return ",".join(flags), None
    if typ.startswith("url:"):
        default = typ.split(":", 1)[1]
        if not raw:
            return default, None
        val = raw.rstrip("/")
        if not re.fullmatch(r"https?://[^\s/]+(/[^\s]*)?", val):
            return None, f"{label} must start with https:// (or clear it to use {default})."
        return val, None
    if typ == "station":
        val = raw.upper()
        if val and not re.fullmatch(r"[A-Z0-9]{3,9}", val):
            return None, "Station IDs are 3 to 9 letters or digits, like KLIT."
        return val, None
    if typ in ("lat", "lon"):
        if not raw:
            return "", None
        lim = 90 if typ == "lat" else 180
        val = num(raw)
        if val is None or abs(val) > lim:
            return None, f"{label} must be a number from -{lim} to {lim}."
        return val, None
    if typ.startswith("int:"):
        _, lo, hi = typ.split(":")
        lo, hi = int(lo), int(hi)
        val = int(raw) if re.fullmatch(r"\d+", raw) else None
        if val is None or not lo <= val <= hi:
            return None, f"{label} must be a whole number from {lo} to {hi}."
        return val, None
    if typ.startswith("choice:"):
        choices = typ.split(":", 1)[1].split(",")
        val = raw if raw in choices else choices[0]
        if key in ("radar_span", "radar_step", "radar_panes", "radar_min_dbz", "radar_opacity"):
            return int(val), None
        return val, None
    if typ == "radarsite":
        val = raw.upper() or "AUTO"
        if val == "AUTO":
            return "auto", None
        if not re.fullmatch(r"[KTPR][A-Z0-9]{3}", val):
            return None, "Radar IDs are 4 characters, such as KFWS (or type auto)."
        return val, None
    if typ == "products":
        from .nexrad import PRODUCT_BY_KEY
        keys = [k.strip().lower() for k in re.split(r"[,\s]+", raw) if k.strip()]
        bad = [k for k in keys if k not in PRODUCT_BY_KEY]
        if bad:
            return None, f"Unknown product {bad[0]}; use: {', '.join(PRODUCT_BY_KEY)}."
        return ",".join(keys) or "ref,vel,cc,zdr", None
    return raw, None


UNITS = {"radar_opacity": "%", "radar_min_dbz": " dBZ", "radar_span": " mi across", "radar_step": " min apart",
         "radar_frames": " scans", "radar_speed": " frames/s", "hourly_hours": " hours", "daily_days": " days",
         "station_radius": " mi", "station_max": " stations", "local8s_seconds": " s a page",
         "ticker_area": " mi"}


def with_unit(key, val):
    """A setting's value with its unit, for display ('90%', '120 mi across')."""
    text = str(val)
    unit = UNITS.get(key)
    if unit and text.lstrip("-").isdigit():
        return text + unit
    return text


def control_segs(val, focused, ascii_only=False):
    """An on/off setting drawn as a switch: ■ on (bright) or □ off (dim); highlighted when focused."""
    is_on = str(val).lower() == "on"
    if focused:
        return [((("[x] " if ascii_only else "■ ") if is_on else ("[ ] " if ascii_only else "□ ")) + str(val) + " ",
                 "fieldon")]
    if is_on:
        return [("[x]" if ascii_only else "■", "tgonmk"), (" on", "tgon")]
    return [("[ ]" if ascii_only else "□", "tgoffmk"), (" off", "tgoff")]


def as_text(val):
    return "" if val is None else str(val)


def mask(val):
    if not val:
        return ""
    if len(val) <= 8:
        return "•" * len(val)
    return val[:4] + "•" * min(len(val) - 8, 16) + val[-4:]


class Settings:
    def __init__(self, app):
        self.app = app
        self.focus = 0
        self.editing = False
        self.quick = False
        self.edit_key_name = None
        self.buf = ""
        self.pos = 0
        self.show = False
        self.message = ("", "text")
        self.results = []
        self.testing = False
        self.version = 0
        self.draft = {}
        self.items = []
        self.sec_of = []          # section number of each item
        self.sections = []
        self.pos_of = {}          # item index -> (column, row) as last drawn, for ← → between columns
        self.finding = False      # "/" find a setting by name
        self.find_buf = ""
        self.find_from = 0
        self.armed = None         # (action, time): a second press confirms
        self.sync()

    # -- model -------------------------------------------------------------------
    def build_items(self):
        removed = set(self.draft.get("__removed__", "").split(",")) - {""}
        self.items, self.sec_of, self.sections = [], [], []
        for it in FIELDS:
            if it[0] == "sec":
                self.sections.append(it[1])
            elif not (it[0] == "src" and it[1] in removed):
                self.items.append(it)
                self.sec_of.append(max(0, len(self.sections) - 1))
        self.focus = max(0, min(self.focus, len(self.items) - 1))

    def bump(self):
        self.version += 1

    def say(self, text, style="text"):
        self.message = (text, style)
        self.bump()

    def sync(self):
        cfg = self.app.cfg
        self.draft = {it[1]: as_text(cfg.get(it[1], DEFAULTS.get(it[1]))) for it in FIELDS if it[0] == "fld"}
        for s in S.SOURCES:
            self.draft[f"src:{s.id}:on"] = "on" if S.enabled_flag(cfg, s.id) else "off"
            self.draft[f"src:{s.id}:url"] = S.url(cfg, s.id)
        self.draft["__removed__"] = ",".join(cfg.get("sources_removed") or [])
        self.build_items()

    def saved_view(self):
        cfg = self.app.cfg
        d = {it[1]: as_text(cfg.get(it[1], DEFAULTS.get(it[1]))) for it in FIELDS if it[0] == "fld"}
        for s in S.SOURCES:
            d[f"src:{s.id}:on"] = "on" if S.enabled_flag(cfg, s.id) else "off"
            d[f"src:{s.id}:url"] = S.url(cfg, s.id)
        d["__removed__"] = ",".join(cfg.get("sources_removed") or [])
        return d

    def adopt(self, *keys):
        """A setting was changed outside this screen (a hotkey): show the new value
        without throwing away other unsaved edits."""
        cfg = self.app.cfg
        for k in keys:
            self.draft[k] = as_text(cfg.get(k, DEFAULTS.get(k)))
        self.bump()

    def dirty(self):
        saved = self.saved_view()
        return {k for k, val in self.draft.items() if val != saved.get(k)}

    def on_show(self):
        if not self.dirty() and not self.editing:
            self.sync()

    def focus_key(self, key):
        for i, it in enumerate(self.items):
            if it[1] == key:
                self.focus = i
                return it
        return None

    def begin_edit(self, key=None, quick=False, url_of=None):
        if key:
            self.focus_key(key)
        it = self.items[self.focus]
        self.editing = True
        self.quick = quick
        if url_of:
            self.edit_key_name = f"src:{url_of}:url"
        else:
            self.edit_key_name = it[1]
        self.buf = "" if quick else self.draft.get(self.edit_key_name, "")
        self.pos = len(self.buf)
        if quick:
            self.say("Type a ZIP code (or a place such as Memphis, TN) and press Enter. Esc cancels.", "accent")
        self.bump()

    # -- keys ---------------------------------------------------------------------
    @property
    def capturing(self):
        """Typing goes to this screen (a field being edited, or the find prompt)."""
        return self.editing or self.finding

    def label_of(self, it):
        return S.SOURCE_BY_ID[it[1]].name if it[0] == "src" else it[2]

    def section_step(self, step):
        sec = self.sec_of[self.focus]
        first = self.sec_of.index(sec)
        if step < 0 and self.focus != first:
            self.focus = first                 # back to the top of this section first
            return
        target = sec + step
        while 0 <= target < len(self.sections) and target not in self.sec_of:
            target += step                     # a section with nothing left in it
        if 0 <= target < len(self.sections):
            self.focus = self.sec_of.index(target)

    def column_step(self, step):
        """Move to the setting beside this one in the next column over (as drawn)."""
        here = self.pos_of.get(self.focus)
        if not here:
            return
        col, row = here
        best = None
        for i, (c, r) in self.pos_of.items():
            if c == col + step:
                d = (abs(r - row), r)
                if best is None or d < best[0]:
                    best = (d, i)
        if best:
            self.focus = best[1]

    def step_number(self, it, step):
        lo, hi = (int(x) for x in it[3].split(":")[1:3])
        cur = num(self.draft.get(it[1]))
        cur = int(cur) if cur is not None else lo
        vals = nice_steps(lo, hi)
        if step > 0:
            nxt = next((v for v in vals if v > cur), hi)
        else:
            nxt = next((v for v in reversed(vals) if v < cur), lo)
        self.draft[it[1]] = str(nxt)

    def shortcut(self, action):
        if action == "revert":
            n = len(self.dirty())
            if not n:
                self.say("No unsaved changes to discard.", "dim")
                return
            if not (self.armed and self.armed[0] == "revert" and time.time() - self.armed[1] < 5):
                self.armed = ("revert", time.time())
                self.say(f"Press D again to discard {n} unsaved change{'s' if n != 1 else ''}.", "warn")
                return
        self.armed = None
        if action == "restore" and not self.draft.get("__removed__"):
            self.say("No deleted sources to restore.", "dim")
            return
        {"save": self.save, "test": self.start_test, "revert": self.revert, "restore": self.restore,
         "test_alarm": self.test_alarm}[action]()

    def start_find(self):
        self.finding, self.find_buf, self.find_from = True, "", self.focus
        self.show_find()

    def show_find(self, note=""):
        self.say(f"Find a setting: {self.find_buf}▏   Enter stays here, Esc goes back, ↓ ↑ next and previous "
                 f"match{note}", "accent")

    def find_matches(self):
        q = self.find_buf.strip().lower()
        if not q:
            return []
        hits = [i for i, it in enumerate(self.items) if q in self.label_of(it).lower()]
        more = [i for i, it in enumerate(self.items) if i not in hits and
                (q in it[1].lower() or q in self.sections[self.sec_of[i]].lower())]
        return hits + more

    def find_key(self, k):
        if k == KEY_ENTER:
            self.finding = False
            self.say(f"{self.label_of(self.items[self.focus])}.", "dim")
        elif k == "\x1b":
            self.finding = False
            self.focus = self.find_from
            self.say("", "text")
        elif k in (KEY_DOWN, KEY_UP, "\t", KEY_BTAB):
            hits = self.find_matches()
            if hits:
                at = hits.index(self.focus) if self.focus in hits else -1
                self.focus = hits[(at + (1 if k in (KEY_DOWN, "\t") else -1)) % len(hits)]
            self.show_find(f"   ({len(hits)} found)" if hits else "")
            return
        else:
            if k == KEY_BACKSPACE:
                self.find_buf = self.find_buf[:-1]
            elif isinstance(k, Paste):
                self.find_buf += "".join(ch for ch in k.text if ch.isprintable())
            elif isinstance(k, str) and len(k) == 1 and k.isprintable():
                self.find_buf += k
            hits = self.find_matches()
            if hits:
                self.focus = hits[0]
            self.show_find(f"   ({len(hits)} found)" if hits else "   (no match)" if self.find_buf.strip() else "")
        self.bump()

    def nav_key(self, k):
        it = self.items[self.focus]
        if k in (KEY_DOWN, "j"):
            self.focus = min(len(self.items) - 1, self.focus + 1)
        elif k in (KEY_UP, "k"):
            self.focus = max(0, self.focus - 1)
        elif k == KEY_NPAGE:
            self.section_step(1)
        elif k == KEY_PPAGE:
            self.section_step(-1)
        elif k in (KEY_HOME, "g"):
            self.focus = 0
        elif k in (KEY_END, "G"):
            self.focus = len(self.items) - 1
        elif k == "/":
            self.start_find()
        elif k in (KEY_SLEFT, KEY_SRIGHT, "<", ">"):
            self.column_step(1 if k in (KEY_SRIGHT, ">") else -1)
        elif k in (KEY_ENTER, " "):
            self.activate()
        elif k == "v":
            self.show = not self.show
        elif k in SHORTCUTS:
            self.shortcut(SHORTCUTS[k])
        elif it[0] == "src" and k in ("x", KEY_DC):
            removed = [x for x in self.draft["__removed__"].split(",") if x]
            removed.append(it[1])
            self.draft["__removed__"] = ",".join(removed)
            self.build_items()
            self.say(f"{S.SOURCE_BY_ID[it[1]].name} will be deleted when you save (Restore deleted sources "
                     "brings it back).", "warn")
        elif it[0] == "src" and k == "e":
            self.begin_edit(url_of=it[1])
        elif k in (KEY_LEFT, KEY_RIGHT, "h", "l"):
            # ← → change what can be changed; anywhere else they move between columns
            # (they never leave the Settings screen: use Tab or the number keys for that)
            step = 1 if k in (KEY_RIGHT, "l") else -1
            if it[0] == "src":
                key = f"src:{it[1]}:on"
                self.draft[key] = "off" if self.draft.get(key) == "on" else "on"
            elif it[0] == "fld" and it[3].startswith("choice:"):
                self.cycle(it, step)
            elif it[0] == "fld" and it[3].startswith("int:"):
                self.step_number(it, step)
            elif it[0] == "btn" and 0 <= self.focus + step < len(self.items) and \
                    self.items[self.focus + step][0] == "btn" and \
                    self.pos_of.get(self.focus + step, (None,))[0] == self.pos_of.get(self.focus, (None,))[0]:
                self.focus += step                 # along a row of buttons
            else:
                self.column_step(step)
        else:
            return False
        self.bump()
        return True

    def cycle(self, it, step=1):
        choices = it[3].split(":", 1)[1].split(",")
        cur = self.draft.get(it[1])
        idx = choices.index(cur) if cur in choices else -1
        self.draft[it[1]] = choices[(idx + step) % len(choices)]

    def activate(self):
        it = self.items[self.focus]
        if it[0] == "btn":
            {"save": self.save, "test": self.start_test, "revert": self.revert, "restore": self.restore,
             "voice_dl": self.voice_dl, "voice_test": self.voice_test, "test_alarm": self.test_alarm}[it[1]]()
            return
        if it[0] == "src":
            key = f"src:{it[1]}:on"
            self.draft[key] = "off" if self.draft.get(key) == "on" else "on"
            return
        if it[3].startswith("choice:"):
            self.cycle(it, 1)
            return
        self.begin_edit()

    def edit_key(self, k):
        if self.finding:
            return self.find_key(k)
        if isinstance(k, Paste):
            text = "".join(ch for ch in k.text if ch.isprintable())
            self.buf = self.buf[:self.pos] + text + self.buf[self.pos:]
            self.pos += len(text)
        elif k == KEY_ENTER:
            self.commit()
        elif k == "\x1b":
            self.editing = False
            if self.quick:
                self.quick = False
                self.app.back()
            self.say("Edit canceled.", "dim")
        elif k == KEY_BACKSPACE:
            if self.pos > 0:
                self.buf = self.buf[:self.pos - 1] + self.buf[self.pos:]
                self.pos -= 1
        elif k == KEY_DC:
            self.buf = self.buf[:self.pos] + self.buf[self.pos + 1:]
        elif k in (KEY_LEFT, KEY_SLEFT):
            self.pos = max(0, self.pos - 1)
        elif k in (KEY_RIGHT, KEY_SRIGHT):
            self.pos = min(len(self.buf), self.pos + 1)
        elif k in (KEY_HOME, "\x01"):
            self.pos = 0
        elif k in (KEY_END, "\x05"):
            self.pos = len(self.buf)
        elif k == "\x15":
            self.buf, self.pos = "", 0
        elif isinstance(k, str) and len(k) == 1 and k.isprintable():
            self.buf = self.buf[:self.pos] + k + self.buf[self.pos:]
            self.pos += 1
        self.bump()

    def commit(self):
        key = self.edit_key_name
        if key and key.startswith("src:"):
            val = self.buf.strip().rstrip("/")
            sid = key.split(":")[1]
            if val and not re.fullmatch(r"https?://[^\s/]+(/[^\s]*)?", val):
                self.say("Addresses must start with https:// (clear the field for the default).", "bad")
                return
            self.draft[key] = val or S.SOURCE_BY_ID[sid].url
            self.editing = False
            self.say(f"{S.SOURCE_BY_ID[sid].name} address changed. Choose Save and refresh to use it.", "accent")
            return
        it = FIELD_BY_KEY[key]
        val, err = parse_field(it, self.buf)
        if err:
            self.say(err, "bad")
            return
        self.draft[key] = as_text(val)
        self.editing = False
        if self.quick:
            self.quick = False
            if not val:
                self.say("Enter a ZIP code or a place.", "bad")
                return
            if self.save(only={"zip"}):
                self.app.back()
            return
        self.say(f"{it[2]} changed. Choose Save and refresh to use it.", "accent")

    # -- actions ----------------------------------------------------------------------
    def save(self, only=None):
        app, cfg, store = self.app, self.app.cfg, self.app.store
        parsed = {}
        for it in FIELDS:
            if it[0] != "fld":
                continue
            if only is not None and it[1] not in only:
                parsed[it[1]] = cfg.get(it[1], DEFAULTS.get(it[1]))
                continue
            val, err = parse_field(it, self.draft.get(it[1], ""))
            if err:
                self.focus_key(it[1])
                self.say(err, "bad")
                return False
            parsed[it[1]] = val
        changed = {k for k, val in parsed.items() if val != cfg.get(k, DEFAULTS.get(k))}
        if "zip" in changed:
            for k, blank in (("lat", ""), ("lon", ""), ("nws_station", ""), ("location_name", "")):
                if k not in changed or only is not None:
                    parsed[k] = blank
            changed |= {"lat", "lon"}
        if parsed.get("nws_station") and "country" in changed and parsed.get("country") != "US":
            parsed["nws_station"] = ""
        if (parsed["lat"] == "") != (parsed["lon"] == ""):
            self.say("Enter both latitude and longitude, or leave both blank.", "bad")
            return False
        if parsed["lat"] == "" and not parsed["zip"]:
            self.focus_key("zip")
            self.say("Enter a ZIP code or place (or both coordinates).", "bad")
            return False
        src_changed = False
        with store.cfg_lock:
            cfg.update(parsed)
            for k in changed:  # a setting changed here is no longer a run-only override
                (cfg.get("_runonly") or {}).pop(k, None)
            if only is None:
                for s in S.SOURCES:
                    on = self.draft.get(f"src:{s.id}:on") == "on"
                    if on != S.enabled_flag(cfg, s.id):
                        S.set_enabled(cfg, s.id, on)
                        src_changed = True
                    url = self.draft.get(f"src:{s.id}:url") or s.url
                    if url != S.url(cfg, s.id):
                        S.set_url(cfg, s.id, url)
                        src_changed = True
                removed = [x for x in self.draft.get("__removed__", "").split(",") if x]
                if sorted(removed) != sorted(cfg.get("sources_removed") or []):
                    cfg["sources_removed"] = removed
                    src_changed = True
            if changed & LOCATION_KEYS:
                for k in ("_geo", "_nws_points", "_nws_station", "_rev", "_acis"):
                    cfg.pop(k, None)
        store.persist()
        if changed & CREDENTIAL_KEYS or src_changed:
            store.reset_probes()
        if changed & LOCATION_KEYS or src_changed:
            store.forget_all()
            app.sel.update({"hourly": 0, "daily": 0, "stations": 0})
            app.radar_state.update({"lat": None, "lon": None})
        store.http.clear()
        if app.radar is not None:
            app.radar.invalidate()
        if changed & RADAR_KEYS:
            app.radar_from_cfg()
        watch_msg = ""
        if "background_watch" in changed and store.persist_enabled:
            from . import watch
            err = watch.sync(cfg)
            on_ = str(cfg.get("background_watch")) == "on"
            watch_msg = f" {err}." if err else (" The background watch is on, and starts when you log in." if on_
                                               else " The background watch is off.")
        app.units_override = None
        unsaved = dict(self.draft)
        self.sync()
        if only is not None:
            for k, val in unsaved.items():
                if k not in only and k not in ("lat", "lon", "nws_station", "location_name"):
                    self.draft[k] = val
        if changed & DISPLAY_KEYS or "radar_span" in changed or "radar_layer" in changed:
            app.apply_display()
        app.request_refresh()
        if "zip" in changed:
            what = f"ZIP {parsed['zip']}" if str(parsed["zip"]).isdigit() else parsed["zip"]
            self.say(f"Saved. Pulling weather for {what}…{watch_msg}", "good")
        elif changed or src_changed:
            self.say(f"Saved. Pulling fresh data…{watch_msg}", "good")
        else:
            self.say("Nothing changed. Pulling fresh data anyway…", "good")
        return True

    def test_alarm(self):
        """Play the tornado alarm with the sound and voice settings on screen (saved or not)."""
        trial = dict(self.app.cfg)
        for k in ("tornado_alarm_sound", "tornado_alarm_voice", "voice_engine", "voice", "voice_rate", "audio_player"):
            val, err = parse_field(FIELD_BY_KEY[k], self.draft.get(k))
            if not err:
                trial[k] = val
        if self.app.test_alarm(trial):
            self.say("Playing the tornado alarm test… press s or Esc to stop the voice.", "good")
        else:
            self.say("No audio player found: install alsa-utils (aplay) or PipeWire (pw-play).", "bad")

    def revert(self):
        self.sync()
        self.editing = False
        self.say("Changes discarded.", "dim")

    def restore(self):
        self.draft["__removed__"] = ""
        self.build_items()
        self.say("Deleted sources restored. Choose Save and refresh to keep this.", "accent")

    def voice_dl(self):
        name = self.draft.get("voice") or VOICE_CHOICES[0]
        sp = self.app.speech
        if sp.download_voice(name):
            self.say(f"Downloading {name}…", "accent")
        else:
            self.say(f"Couldn't start the download: {(sp.download or ('', 0, 0, 'busy'))[3]}", "bad")

    def voice_test(self):
        sp = self.app.speech
        trial = {}  # the voice settings on screen, saved or not
        for k in ("voice_engine", "voice", "voice_rate", "audio_player"):
            val, err = parse_field(FIELD_BY_KEY[k], self.draft.get(k))
            if not err:
                trial[k] = val
        ok = sp.speak("Voice test", "This is skydrop. Here is your local forecast: mostly sunny, with a high "
                                    "near 75 degrees and a light south wind.", overrides=trial)
        if not ok:
            self.say(f"Voice test failed: {sp.error}", "bad")
        else:
            self.say("Speaking… press s or Esc to stop.", "good")

    def start_test(self):
        if self.testing:
            return
        cfg = dict(self.app.cfg)
        for it in FIELDS:
            if it[0] == "fld":
                val, err = parse_field(it, self.draft.get(it[1], ""))
                if not err:
                    cfg[it[1]] = val
        srcs = {}
        for s in S.SOURCES:
            srcs[s.id] = {"enabled": self.draft.get(f"src:{s.id}:on") == "on"}
            if self.draft.get(f"src:{s.id}:url") and self.draft[f"src:{s.id}:url"] != s.url:
                srcs[s.id]["url"] = self.draft[f"src:{s.id}:url"]
        cfg["sources"] = srcs
        cfg["sources_removed"] = [x for x in self.draft.get("__removed__", "").split(",") if x]
        self.testing = True
        self.results = [("Testing", None, "checking every enabled source…")]
        self.bump()
        saved_loc = self.app.store.get("loc") or {}
        same_place = (cfg.get("zip") == self.app.cfg.get("zip") and cfg.get("country") == self.app.cfg.get("country"))

        def work():
            res = []
            try:
                lat, lon = num(cfg.get("lat")), num(cfg.get("lon"))
                if lat is None or lon is None:
                    if same_place and saved_loc:
                        lat, lon = saved_loc.get("lat"), saved_loc.get("lon")
                    else:
                        place = cfg.get("zip") or ""
                        try:
                            found = geocode(Http(timeout=10), cfg, place)
                            lat, lon = found["lat"], found["lon"]
                            where = ", ".join(str(x) for x in (found.get("name"), found.get("state")) if x)
                            res.append(("Location lookup", True, f"{place} is {where} ({lat:.3f}, {lon:.3f}) "
                                                                 f"via {found.get('how')}"))
                        except Exception as e:
                            lat, lon = FALLBACK_COORDS.get(place, (None, None))
                            res.append(("Location lookup", False, str(e)))
                if lat is None:
                    res.append(("Connections", False, "no coordinates to test with"))
                else:
                    res += check_connections(cfg, lat, lon, self.app.store.usage)
            except Exception as e:
                res.append(("Test", False, f"{type(e).__name__}: {e}"))
            self.results = res
            self.testing = False
            self.bump()
            self.app.term.wake()

        threading.Thread(target=work, daemon=True).start()

    # -- drawing -------------------------------------------------------------------------
    def render(self, W, H):
        app, cfg, store = self.app, self.app.cfg, self.app.store
        F = app.fmt
        # every setting and the status panels in balanced columns across the whole width
        ncols, col_w = ui.flow_columns(W, min_col=52, max_cols=3)
        main_w = W
        two = ncols > 1
        L = [[("  Settings", "title"), (f"   saved in {pretty_path(CONFIG_PATH)}", "dim")]]
        # the keys, as keycaps, wrapped to the width
        line, x = [("  ", "text")], 2
        for key, what in KEY_LEGEND:
            w = len(key) + 2 + 1 + len(what) + 2
            if x + w > main_w - 1 and x > 2:
                L.append(line)
                line, x = [("  ", "text")], 2
            line += [(f" {key} ", "btnact"), (f" {what}  ", "dim")]
            x += w
        L.append(line)
        errors_on_top = len(LOG) > 0
        if errors_on_top:
            # No sidebar: put current errors where they'll be seen, not 100 lines down.
            L.append([])
            L += active_errors_panel(F, main_w)
        lw = 18
        col_w = col_w if two else main_w
        vw = max(12, min(56, col_w - lw - 8))
        dirty = self.dirty()
        cursor = ccol = None
        blocks = [[]]          # one per section, laid out in columns afterwards
        focus_blk = None
        Lmain = L
        L = blocks[0]
        drawn_buttons = set()
        placed = []            # (item index, block, row in block) for ← → between columns
        index_of = {id(it): i for i, it in enumerate(self.items)}
        removed = set(self.draft.get("__removed__", "").split(",")) - {""}
        for it in FIELDS:
            if it[0] == "sec":
                blocks.append([])
                L = blocks[-1]
                L.append([("  " + it[1], "title")] + ([("   Enter or ← → on/off · x delete · e address", "dim")]
                                                     if it[1] == "Data sources" else []))
                continue
            if it[0] == "btn":
                row = next((r for r in BUTTON_ROWS if it[1] in r), (it[1],))
                if row in drawn_buttons:
                    continue
                drawn_buttons.add(row)
                L.append([])
                line, x = [("  ", "text")], 2
                for act in row:
                    b = next(x for x in FIELDS if x[0] == "btn" and x[1] == act)
                    on = b in self.items and self.items.index(b) == self.focus
                    sc = BUTTON_KEYS.get(act)
                    w = len(b[2]) + 2 + (len(sc) + 2 if sc else 0)
                    if x > 2 and x + w > col_w:          # wrap within the column
                        L.append(line)
                        line, x = [("  ", "text")], 2
                    if on:
                        cursor, focus_blk = len(L), len(blocks) - 1
                    if id(b) in index_of:
                        placed.append((index_of[id(b)], L, len(L)))
                    line += [(f" {b[2]} ", "tabon" if on else "btnact")]
                    if sc:
                        line.append((f" {sc} ", "stkey"))          # its shortcut key
                    line.append(("  ", "text"))
                    x += w + 2
                L.append(line)
                continue
            if it[0] == "src":
                if it[1] in removed:
                    continue
                src = S.SOURCE_BY_ID[it[1]]
                on = self.items.index(it) == self.focus if it in self.items else False
                state = self.draft.get(f"src:{src.id}:on") == "on"
                url = self.draft.get(f"src:{src.id}:url") or src.url
                mark = "*" if f"src:{src.id}:on" in dirty or f"src:{src.id}:url" in dirty else " "
                prefix = "  " + ("▸ " if on else "  ")
                badge = ("■ on  " if not self.app.ascii else "[x] on ", "tgonmk") if state else \
                    ("□ off " if not self.app.ascii else "[ ] off", "tgoffmk")
                if on and self.editing and self.edit_key_name == f"src:{src.id}:url":
                    start = max(0, self.pos - vw + 1)
                    shown = self.buf[start:start + vw]
                    ccol = len(prefix) + len(badge[0]) + 1 + (self.pos - start)
                    L.append([(prefix, "value"), badge, (" ", "text"), (shown.ljust(vw), "fieldon")])
                else:
                    name = src.name[:max(10, col_w - 14)]
                    keyless = src.id == "owm" and state and not str(self.draft.get("owm_api_key") or "").strip()
                    L.append(clip([(prefix, "value" if on else "label"), badge, (mark, "accent"),
                                   (name, "value" if on else "text")] +
                                  ([("  idle: needs your key", "dim")] if keyless else []), col_w))
                placed.append((index_of.get(id(it)), L, len(L) - 1))
                if on:
                    cursor, focus_blk = len(L) - 1, len(blocks) - 1
                    L.append(clip([("          ", "text"), (url, "dim")], col_w))
                    L += [[("          ", "text")] + ln for ln in wrap(src.provides, col_w - 10, "dim", 0)]
                    L += [[("          ", "text")] + ln for ln in
                          wrap(f"Key: {src.auth}.  License: {src.license}.", col_w - 10, "faint", 0)]
                continue
            key, label, typ = it[1], it[2], it[3]
            on = self.items.index(it) == self.focus
            prefix = "  " + ("▸ " if on else "  ") + label.ljust(lw - 1) + ("*" if key in dirty else " ") + " "
            choice = typ.startswith("choice:")
            if on and self.editing and self.edit_key_name == key:
                start = max(0, self.pos - vw + 1)
                shown = self.buf[start:start + vw]
                ccol = len(prefix) + (self.pos - start)
                val_seg = (shown.ljust(vw), "fieldon")
            elif choice:
                # a choice cycles with Enter or ← →: a switch (■ on, □ off) or ‹ value ›, never a box
                val = str(self.draft.get(key, ""))
                if typ == ONOFF:
                    segs = control_segs(val, on, self.app.ascii)
                else:
                    segs = [("‹ ", "dim" if not on else "fieldon"), (with_unit(key, val), "value" if not on else "fieldon"),
                            (" ›", "dim" if not on else "fieldon")]
                L.append([(prefix, "value" if on else "label")] + segs)
                placed.append((index_of.get(id(it)), L, len(L) - 1))
                if on:
                    cursor, focus_blk = len(L) - 1, len(blocks) - 1
                continue
            else:
                val = self.draft.get(key, "")
                shown = mask(val) if typ == "secret" and not self.show else val
                if choice:
                    shown = f"‹ {val} ›"
                elif key == "refresh_seconds" and val:
                    shown = f"{val} s" if int(num(val) or 0) < 120 else f"{val} s ({int(num(val)) // 60} min)"
                elif key == "tornado_alarm_repeat" and val is not None and val != "":
                    shown = "play once" if str(val) == "0" else f"{val} min"
                elif key in ("station_radius",) and val:
                    shown = f"{val} mi"
                elif key == "voice_rate" and val:
                    shown = f"{val}%"
                elif key in UNITS and val not in ("", None):
                    shown = with_unit(key, val)
                elif not val:
                    shown = {"lat": "(from ZIP code)", "lon": "(from ZIP code)", "nws_station": "(nearest)",
                             "location_name": "(from NWS)", "nws_feature_flags": "(none)",
                             "nws_user_agent": "(not set: a generic skydrop one is sent)",
                             "placefiles": "(none yet: paste placefile addresses here)",
                             "map_markers": "(none yet: Name: lat, lon; ...)"}.get(
                        key, "(not set)" if typ == "secret" else "")
                if key == "voice":
                    shown += "  ✓ downloaded" if os.path.exists(voice_path(val)) else "  (not downloaded)"
                placeholder = not val and shown.startswith("(")
                val_seg = (shown[:vw + 18].ljust(vw), "fieldon" if on else "inputdim" if placeholder else "input")
                if typ.startswith("int:"):
                    # a number steps with ← → (Enter types one): drawn like a choice, ‹ value ›
                    L.append([(prefix, "value" if on else "label"), ("‹ ", "dim" if not on else "fieldon"),
                              (shown, "value" if not on else "fieldon"), (" ›", "dim" if not on else "fieldon")])
                    placed.append((index_of.get(id(it)), L, len(L) - 1))
                    if on:
                        cursor, focus_blk = len(L) - 1, len(blocks) - 1
                    continue
            L.append([(prefix, "value" if on else "label"), val_seg])
            placed.append((index_of.get(id(it)), L, len(L) - 1))
            if on:
                cursor, focus_blk = len(L) - 1, len(blocks) - 1
        L = Lmain
        focus_ref = blocks[focus_blk] if focus_blk is not None else None
        it = self.items[self.focus] if self.items else None
        helptext = ""
        if it and it[0] in ("fld", "btn"):
            helptext = it[4]
        # the focused setting's help and the last message stay pinned at the bottom, always in view
        foot = []
        if self.message[0]:
            foot += wrap(self.message[0], min(main_w, 120), self.message[1], 2)
        if helptext:
            foot += wrap(helptext, min(main_w, 120), "dim", 2)
        foot_title = (it[2] if it and it[0] in ("fld", "btn") else
                      S.SOURCE_BY_ID[it[1]].name if it and it[0] == "src" else "Settings")
        # status panels: more blocks in the same columns
        S_ = []
        sw = col_w
        if self.results:
            S_.append(ui.section("Connection test", sw))
            for name, ok, msg in self.results:
                badge = ("  ok  ", "good") if ok is True else ("  ..  ", "dim") if ok is None else ("  no  ", "bad")
                body = labeled_wrap(name, msg, sw - 6, lw=16, indent=0)
                S_.append([badge] + body[0])
                S_ += [[("      ", "text")] + ln for ln in body[1:]]
            S_.append([])
        caps = app.term.caps if app.term else None
        S_.append(ui.section("Terminal", sw))
        if caps:
            S_.append(ui.kv("Detected", caps.name or "--", sw, 12))
            S_ += [[("  ", "text")] + ln for ln in wrap(caps.describe(), sw - 2, "dim", 12)]
        S_.append(ui.kv("Drawing", f"{app.gmode} graphics, {app.color_mode} color", sw, 12, "good"))
        S_.append([])
        S_.append(ui.section("Voice", sw))
        S_ += [[("  ", "text")] + ln for ln in wrap(app.speech.describe(), sw - 4, "value", 0)]
        es = engine_status()
        S_.append(clip([("  Engines  ", "label")] + [(f"{k}{'✓' if v else '✗'} ", "good" if v else "dim")
                                                       for k, v in es.items()], sw))
        S_.append(ui.kv("Player", find_player(cfg.get("audio_player") or "auto") or "none found", sw, 9))
        dl = app.speech.download
        if dl:
            name, done, total, err = dl
            if err:
                S_ += wrap(f"Download of {name} failed: {err}", sw, "bad", 2)
            elif total and done < total:
                S_.append(ui.kv("Download", f"{name} {done * 100 // total}% of {total // 1048576} MB", sw, 9, "accent"))
            elif done:
                S_.append(ui.kv("Download", f"{name} ready", sw, 9, "good"))
        S_.append([])
        S_.append(ui.section("Status", sw))
        loc = store.get("loc") or {}
        pts = store.get("nws_points") or {}
        sta = store.get("nws_station") or {}
        mode = store.onecall_mode(cfg)
        live = store.oc_version in ("4.0", "3.0")
        if mode == "try":
            oc_txt = (f"version {store.oc_version} active" if live else "not checked yet"
                      if store.oc_version is None else "retrying on the next refresh")
        else:
            oc_txt = ONECALL_MSG.get(mode, mode)
        rows = [
            ("One Call", oc_txt, "good" if live and mode == "try" else "dim"),
            ("Calls today", f"{store.usage.get()} of {cfg.get('owm_daily_cap')} (UTC day)"),
            ("Location", f"{loc['lat']:.4f}, {loc['lon']:.4f} from {loc.get('how')}" if loc else "--"),
            ("NWS office", f"{pts.get('gridId')}, grid {pts.get('gridX')},{pts.get('gridY')}, "
                           f"{pts.get('city') or ''} {pts.get('state') or ''}" if pts else "--"),
            ("Station", f"{sta.get('id')} {sta.get('name') or ''}" if sta else "--"),
            ("Last update", F.time(store.last_done) if store.last_done else "not yet"),
            ("Data used", f"{store.http.requests} requests, {store.http.bytes_in / 1048576:.1f} MB this session"),
        ]
        for row in rows:
            S_ += labeled_wrap(row[0], row[1], sw, lw=13, style=row[2] if len(row) > 2 else "value", indent=2)
        if not errors_on_top:
            S_.append([])
            S_ += active_errors_panel(F, sw)
        for ln in S_:                      # split the panels at their headings
            if ln and ln[0][0].startswith(("━━", "--")):
                blocks.append([ln])
            elif blocks and (ln or blocks[-1][-1]):
                blocks[-1].append(ln)
        for b in blocks:
            while b and not b[-1]:
                b.pop()
        blocks = [b for b in blocks if b]
        fb = next((i for i, b in enumerate(blocks) if b is focus_ref), None)
        L.append([])
        top = len(L)
        rows, where = ui.columns(blocks, ncols if two else 1, col_w, ascii_only=self.app.ascii)
        L += rows
        block_no = {id(b): i for i, b in enumerate(blocks)}
        self.pos_of = {}
        for i, blk, r in placed:
            if i is not None and id(blk) in block_no:
                k, r0 = where[block_no[id(blk)]]
                self.pos_of[i] = (k, r0 + r)
        if fb is not None and cursor is not None:
            k, r0 = where[fb]
            cursor = top + r0 + cursor
            if ccol is not None:
                ccol += k * (col_w + 3)
        out = {"lines": L, "cursor": cursor, "ccol": ccol}
        if foot:
            out["footer"], out["footer_title"] = foot, foot_title
        return out
