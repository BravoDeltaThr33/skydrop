"""Terminal I/O without curses: raw mode, key and mouse parsing, and probing
the terminal for graphics support (kitty graphics protocol, sixel), color
depth and cell size in pixels.
"""

import codecs
import fcntl
import locale
import os
import re
import select
import signal
import struct
import sys
import termios
import time

KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT = "KEY_UP", "KEY_DOWN", "KEY_LEFT", "KEY_RIGHT"
KEY_SLEFT, KEY_SRIGHT = "KEY_SLEFT", "KEY_SRIGHT"      # with Shift (or Ctrl, Alt) held
KEY_HOME, KEY_END, KEY_PPAGE, KEY_NPAGE = "KEY_HOME", "KEY_END", "KEY_PPAGE", "KEY_NPAGE"
KEY_DC, KEY_IC, KEY_BACKSPACE, KEY_BTAB = "KEY_DC", "KEY_IC", "KEY_BACKSPACE", "KEY_BTAB"
KEY_ENTER, KEY_ESC, KEY_RESIZE = "\n", "\x1b", "KEY_RESIZE"
KEY_F = {n: f"KEY_F{n}" for n in range(1, 13)}
CTRL_C, CTRL_Z, CTRL_L = "\x03", "\x1a", "\x0c"

ESC_DELAY = 0.03      # a lone Esc key
SEQ_DELAY = 0.5       # an escape sequence that arrives in pieces (ssh, tmux)
PASTE_TIMEOUT = 3.0   # give up on a paste whose end marker never comes

_TILDE = {1: KEY_HOME, 2: KEY_IC, 3: KEY_DC, 4: KEY_END, 5: KEY_PPAGE, 6: KEY_NPAGE, 7: KEY_HOME,
          8: KEY_END, 11: KEY_F[1], 12: KEY_F[2], 13: KEY_F[3], 14: KEY_F[4], 15: KEY_F[5],
          17: KEY_F[6], 18: KEY_F[7], 19: KEY_F[8], 20: KEY_F[9], 21: KEY_F[10], 23: KEY_F[11],
          24: KEY_F[12]}
_CSI_LETTER = {"A": KEY_UP, "B": KEY_DOWN, "C": KEY_RIGHT, "D": KEY_LEFT, "H": KEY_HOME,
               "F": KEY_END, "Z": KEY_BTAB, "P": KEY_F[1], "Q": KEY_F[2], "S": KEY_F[4]}
_SS3 = {"A": KEY_UP, "B": KEY_DOWN, "C": KEY_RIGHT, "D": KEY_LEFT, "H": KEY_HOME, "F": KEY_END,
        "P": KEY_F[1], "Q": KEY_F[2], "R": KEY_F[3], "S": KEY_F[4], "M": KEY_ENTER}


class Mouse:
    """A mouse event: kind is press, release, drag, wheel_up or wheel_down."""
    __slots__ = ("kind", "button", "x", "y")

    def __init__(self, kind, button, x, y):
        self.kind, self.button, self.x, self.y = kind, button, x, y

    def __repr__(self):
        return f"Mouse({self.kind},{self.button},{self.x},{self.y})"


class Paste:
    __slots__ = ("text",)

    def __init__(self, text):
        self.text = text


class Caps:
    """What the terminal can do."""

    def __init__(self):
        self.name = ""            # e.g. "kitty 0.35.2", "Tilix (VTE 7600)"
        self.kitty = False        # kitty graphics protocol answered OK
        self.sixel = False        # DA1 advertises sixel
        self.truecolor = False
        self.colors = 16
        self.utf8 = True
        self.cell_w = 0
        self.cell_h = 0
        self.tmux = False
        self.da1 = ""
        self.xtversion = ""
        self.probed = False

    def graphics_auto(self):
        if self.tmux:
            return "blocks" if self.utf8 else "ascii"
        if self.kitty:
            return "kitty"
        if self.sixel:
            return "sixel"
        return "blocks" if self.utf8 else "ascii"

    def color_auto(self):
        if self.truecolor:
            return "truecolor"
        return "256" if self.colors >= 256 else "16"

    def describe(self):
        bits = []
        if self.kitty:
            bits.append("kitty graphics")
        if self.sixel:
            bits.append("sixel")
        if not bits:
            bits.append("no pixel graphics")
        bits.append("24-bit color" if self.truecolor else f"{self.colors} colors")
        if self.cell_w and self.cell_h:
            bits.append(f"cell {self.cell_w}x{self.cell_h} px")
        return ", ".join(bits)


def _env_caps(caps):
    env = os.environ
    term = env.get("TERM", "")
    prog = env.get("TERM_PROGRAM", "")
    caps.tmux = bool(env.get("TMUX")) or term.startswith("screen") or term.startswith("tmux")
    vte = env.get("VTE_VERSION", "")
    ct = env.get("COLORTERM", "").lower()
    caps.truecolor = (ct in ("truecolor", "24bit") or term.endswith("-direct") or "kitty" in term
                      or "ghostty" in term or prog in ("ghostty", "WezTerm", "iTerm.app", "vscode")
                      or bool(env.get("KITTY_WINDOW_ID")) or bool(env.get("KONSOLE_VERSION"))
                      or bool(env.get("WT_SESSION")) or (vte.isdigit() and int(vte) >= 3600))
    if caps.truecolor or "256" in term or "kitty" in term or "ghostty" in term:
        caps.colors = 256
    elif term in ("linux", "vt100", "vt220", "dumb"):
        caps.colors = 8
    else:
        caps.colors = 16 if term else 8
    enc = (getattr(sys.stdout, "encoding", "") or locale.getpreferredencoding(False) or "").lower()
    caps.utf8 = "utf" in enc and term not in ("linux", "vt100", "dumb")
    names = []
    if env.get("KITTY_WINDOW_ID") or "kitty" in term:
        names.append("kitty")
    if prog == "ghostty" or "ghostty" in term or env.get("GHOSTTY_RESOURCES_DIR"):
        names.append("Ghostty")
    if env.get("TILIX_ID"):
        names.append("Tilix")
    if env.get("KONSOLE_VERSION"):
        names.append("Konsole")
    if prog == "WezTerm":
        names.append("WezTerm")
    if vte and not names:
        names.append("VTE terminal")
    if vte:
        names.append(f"VTE {vte}")
    if not names and prog:
        names.append(prog)
    caps.name = " / ".join(names) or (term or "unknown terminal")
    return caps


class Terminal:
    def __init__(self):
        self.fd_in = sys.stdin.fileno()
        self.fd_out = sys.stdout.fileno()
        self._saved = None
        self.buf = b""
        self.out = []
        self.esc_at = 0.0
        self.paste = None
        self.paste_at = 0.0
        self.responses = []       # replies to queries that arrived mid-session
        self.resized = True
        self.resumed = False      # set after fg; the app then redraws every picture
        self.suspended = False
        self.active = False
        self.mouse = False
        self.motion = False
        self._wake_r, self._wake_w = os.pipe()
        for fd in (self._wake_r, self._wake_w):
            fl = fcntl.fcntl(fd, fcntl.F_GETFL)
            fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
        self._decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.caps = _env_caps(Caps())

    # -- modes -----------------------------------------------------------------
    def raw(self):
        if self._saved is None:
            self._saved = termios.tcgetattr(self.fd_in)
        mode = termios.tcgetattr(self.fd_in)
        mode[0] &= ~(termios.BRKINT | termios.ICRNL | termios.INPCK | termios.ISTRIP | termios.IXON)
        mode[2] &= ~(termios.CSIZE | termios.PARENB)
        mode[2] |= termios.CS8
        mode[3] &= ~(termios.ECHO | termios.ICANON | termios.IEXTEN | termios.ISIG)
        mode[6][termios.VMIN] = 1
        mode[6][termios.VTIME] = 0
        termios.tcsetattr(self.fd_in, termios.TCSAFLUSH, mode)

    def cooked(self):
        if self._saved is not None:
            try:
                termios.tcsetattr(self.fd_in, termios.TCSAFLUSH, self._saved)
            except termios.error:
                pass

    def enter(self, mouse=True):
        self.raw()
        self.mouse = mouse
        seq = "\x1b[?1049h\x1b[?25l\x1b[?7l\x1b[?2004h\x1b[H\x1b[2J"
        if mouse:
            seq += "\x1b[?1000h\x1b[?1006h"
            if getattr(self, "motion", False):
                seq += "\x1b[?1003h"
        self.write(seq)
        self.flush()
        self.active = True
        self.resized = True

    def leave(self):
        if not self.active:
            self.cooked()
            return
        seq = ""
        if self.caps.kitty:
            seq += "\x1b_Ga=d,d=A,q=2\x1b\\"
        seq += "\x1b[?1003l\x1b[?1006l\x1b[?1000l\x1b[?2004l\x1b[0m\x1b[?7h\x1b[?25h\x1b[2J\x1b[?1049l"
        self.out = [seq]
        try:
            self.flush()
        except OSError:
            pass
        self.cooked()
        self.active = False

    def set_mouse(self, on):
        if on == self.mouse:
            return
        self.mouse = on
        if not on and getattr(self, "motion", False):
            self.write("\x1b[?1003l")
            self.motion = False
        self.write("\x1b[?1000h\x1b[?1006h" if on else "\x1b[?1006l\x1b[?1000l")

    def set_motion(self, on):
        """Report mouse movement too (used on the radar map for hover readouts and dragging)."""
        on = bool(on) and bool(self.mouse)
        if on == getattr(self, "motion", False):
            return
        self.motion = on
        self.write("\x1b[?1003h" if on else "\x1b[?1003l")

    def install_signals(self):
        def on_winch(_sig, _frm):
            self.resized = True
            self.wake()

        def on_cont(_sig, _frm):
            if self.suspended:
                self.suspended = False
                self.enter(self.mouse)
                self.resumed = True
                self.wake()

        def on_tstp(_sig, _frm):  # `kill -TSTP` or a job-control stop from outside
            if self.active and not self.suspended:
                self.suspend()

        def on_term(sig, _frm):   # closing the window or `kill`: unwind so the terminal is restored
            raise SystemExit(128 + sig)

        signal.signal(signal.SIGWINCH, on_winch)
        signal.signal(signal.SIGCONT, on_cont)
        signal.signal(signal.SIGTSTP, on_tstp)
        signal.signal(signal.SIGTERM, on_term)
        signal.signal(signal.SIGHUP, on_term)

    def suspend(self):
        """Ctrl-Z: hand the terminal back to the shell, stop, resume on fg."""
        mouse = self.mouse
        self.leave()
        self.mouse = mouse
        self.suspended = True
        os.kill(os.getpid(), signal.SIGSTOP)

    def wake(self):
        try:
            os.write(self._wake_w, b"x")
        except OSError:
            pass

    # -- size -------------------------------------------------------------------
    def size(self):
        """(cols, rows, xpixels, ypixels)."""
        for fd in (self.fd_out, self.fd_in):
            try:
                raw = fcntl.ioctl(fd, termios.TIOCGWINSZ, b"\0" * 8)
                rows, cols, xp, yp = struct.unpack("HHHH", raw)
                if cols and rows:
                    return cols, rows, xp, yp
            except OSError:
                continue
        try:
            sz = os.get_terminal_size()
            return sz.columns, sz.lines, 0, 0
        except OSError:
            return 80, 24, 0, 0

    def cell_px(self):
        cols, rows, xp, yp = self.size()
        if xp and yp and cols and rows:
            w, h = xp // cols, yp // rows
            if 4 <= w <= 64 and 8 <= h <= 128:
                return w, h
        if self.caps.cell_w and self.caps.cell_h:
            return self.caps.cell_w, self.caps.cell_h
        return 10, 20

    # -- output -----------------------------------------------------------------
    def write(self, s):
        self.out.append(s)

    def flush(self):
        if not self.out:
            return
        data = "".join(self.out).encode("utf-8", "replace")
        self.out = []
        view = memoryview(data)
        while view:
            try:
                n = os.write(self.fd_out, view)
            except BlockingIOError:
                select.select([], [self.fd_out], [], 0.5)
                continue
            except InterruptedError:
                continue
            view = view[n:]

    # -- input ------------------------------------------------------------------
    def read_events(self, timeout):
        """Wait up to `timeout` seconds; return a list of keys/events."""
        events = []
        deadline = time.time() + max(0.0, timeout)
        while True:
            wait = max(0.0, deadline - time.time())
            if self.buf.startswith(b"\x1b") and len(self.buf) < 64:
                wait = min(wait, ESC_DELAY)
            if self.paste is not None:
                wait = min(wait, 0.25)
                if time.time() - self.paste_at > PASTE_TIMEOUT:  # the end marker never came
                    events.append(Paste(self.paste + self._decoder.decode(b"", final=True)))
                    self._decoder.reset()
                    self.paste = None
            try:
                ready, _, _ = select.select([self.fd_in, self._wake_r], [], [], wait)
            except (InterruptedError, OSError):
                ready = []
            if self._wake_r in ready:
                try:
                    os.read(self._wake_r, 4096)
                except OSError:
                    pass
            if self.fd_in in ready:
                try:
                    chunk = os.read(self.fd_in, 65536)
                except (BlockingIOError, InterruptedError):
                    chunk = b""
                except OSError:
                    chunk = b""
                if chunk:
                    if not self.buf:
                        self.esc_at = time.time()
                    if self.paste is not None:
                        self.paste_at = time.time()
                    self.buf += chunk
            events += self._parse(final=self.fd_in not in ready)
            if self.resized:
                events.append(KEY_RESIZE)
                self.resized = False
            if events or time.time() >= deadline or self._wake_r in ready:
                return events

    def _parse(self, final=False):
        out = []
        b = self.buf
        i, n = 0, len(b)
        while i < n:
            if self.paste is not None:
                end = b.find(b"\x1b[201~", i)
                if end < 0:
                    # keep a tail that may be the start of a split end marker
                    k = b.find(b"\x1b", max(i, n - 5))
                    cut = k if k >= 0 else n
                    self.paste += self._decoder.decode(b[i:cut])
                    i = cut
                    break
                self.paste += self._decoder.decode(b[i:end], final=True)
                self._decoder.reset()
                out.append(Paste(self.paste))
                self.paste = None
                i = end + 6
                continue
            c = b[i]
            if c == 0x1b:
                if i + 1 >= n:
                    if final:
                        out.append(KEY_ESC)
                        i += 1
                        continue
                    break
                nx = b[i + 1]
                late = time.time() - self.esc_at > SEQ_DELAY
                if nx == 0x5b:  # CSI
                    j = i + 2
                    while j < n and not (0x40 <= b[j] <= 0x7e):
                        j += 1
                    if j >= n:
                        if (final and late) or n - i > 64:  # stale or garbage: drop it
                            i = n
                        break
                    ev = self._csi(b[i + 2:j].decode("latin-1"), chr(b[j]))
                    if ev is not None:
                        out.append(ev)
                    i = j + 1
                    continue
                if nx == 0x4f:  # SS3
                    if i + 2 >= n:
                        if final:
                            out.append(KEY_ESC)
                            i += 2
                            continue
                        break
                    key = _SS3.get(chr(b[i + 2]))
                    if key:
                        out.append(key)
                    i += 3
                    continue
                if nx in (0x5f, 0x50, 0x5d, 0x58, 0x5e):  # APC, DCS, OSC, SOS, PM strings
                    st = b.find(b"\x1b\\", i + 2)
                    bel = b.find(b"\x07", i + 2) if nx == 0x5d else -1
                    ends = [e for e in (st, bel) if e >= 0]
                    if not ends:
                        if n - i > 8192:
                            i = n
                        elif final and late:
                            i += 1  # no string followed: it was Alt+key (Alt+], Alt+P ...)
                            continue
                        break
                    e = min(ends)
                    self.responses.append(b[i:e].decode("latin-1"))
                    i = e + (2 if e == st else 1)
                    continue
                # Alt+key: report the key on its own
                i += 1
                continue
            if c < 0x20 or c == 0x7f:
                if c in (0x0d, 0x0a):
                    out.append(KEY_ENTER)
                elif c == 0x09:
                    out.append("\t")
                elif c in (0x7f, 0x08):
                    out.append(KEY_BACKSPACE)
                else:
                    out.append(chr(c))
                i += 1
                continue
            # UTF-8 text
            if c < 0x80:
                need = 1
            elif c >> 5 == 0x6:
                need = 2
            elif c >> 4 == 0xe:
                need = 3
            elif c >> 3 == 0x1e:
                need = 4
            else:
                i += 1
                continue
            if i + need > n:
                break
            ch = b[i:i + need].decode("utf-8", "replace")
            out.append(ch)
            i += need
        self.buf = b[i:]
        return out

    def _csi(self, params, final):
        if params.startswith("<") and final in "Mm":
            try:
                bt, x, y = (int(v) for v in params[1:].split(";")[:3])
            except ValueError:
                return None
            x, y = x - 1, y - 1
            if bt & 64:
                if bt & 3 >= 2:  # sideways scrolling
                    return None
                return Mouse("wheel_up" if (bt & 3) == 0 else "wheel_down", 0, x, y)
            button = bt & 3
            if bt & 32:
                return Mouse("move" if button == 3 else "drag", button, x, y)
            return Mouse("press" if final == "M" else "release", button, x, y)
        if final == "~":
            first = params.split(";")[0]
            if first == "200":
                self.paste = ""
                self.paste_at = time.time()
                self._decoder.reset()
                return None
            if first.isdigit():
                return _TILDE.get(int(first))
            return None
        if final in "ct" or (final == "R" and params.startswith("?")):
            self.responses.append("\x1b[" + params + final)
            return None
        if final in ("I", "O", "u"):
            return None
        if final == "R" and ";" in params and not params.startswith("1;"):
            return None  # a cursor position report
        if final in "CD" and ";" in params:
            return KEY_SRIGHT if final == "C" else KEY_SLEFT
        return _CSI_LETTER.get(final)

    # -- probing ------------------------------------------------------------------
    def probe(self, timeout=0.6):
        """Ask the terminal what it supports. Call in raw mode, before drawing."""
        caps = self.caps
        caps.probed = True
        queries = "\x1b_Gi=31,s=1,v=1,a=q,t=d,f=24;AAAA\x1b\\" + "\x1b[>q" + "\x1b[16t" + "\x1b[14t" + "\x1b[c"
        if caps.tmux:
            queries = "\x1b[c"
        try:
            os.write(self.fd_out, queries.encode())
        except OSError:
            return caps
        got = b""
        deadline = time.time() + timeout
        while time.time() < deadline:
            r, _, _ = select.select([self.fd_in], [], [], max(0.0, deadline - time.time()))
            if not r:
                break
            try:
                chunk = os.read(self.fd_in, 4096)
            except OSError:
                break
            if not chunk:
                break
            got += chunk
            if re.search(rb"\x1b\[\?[0-9;]*c", got):
                time.sleep(0.02)
                r, _, _ = select.select([self.fd_in], [], [], 0)
                if r:
                    try:
                        got += os.read(self.fd_in, 4096)
                    except OSError:
                        pass
                break
        text = got.decode("latin-1")
        if re.search(r"\x1b_Gi=31;OK", text):
            caps.kitty = True
        m = re.search(r"\x1b\[\?([0-9;]*)c", text)
        if m:
            caps.da1 = m.group(1)
            if "4" in m.group(1).split(";"):
                caps.sixel = True
        m = re.search(r"\x1bP>\|([^\x1b]*)\x1b\\", text)
        if m:
            caps.xtversion = m.group(1).strip()
        m = re.search(r"\x1b\[6;(\d+);(\d+)t", text)
        if m:
            h, w = int(m.group(1)), int(m.group(2))
            if 4 <= w <= 64 and 8 <= h <= 128:
                caps.cell_w, caps.cell_h = w, h
        if not caps.cell_w:
            m = re.search(r"\x1b\[4;(\d+);(\d+)t", text)
            cols, rows, _xp, _yp = self.size()
            if m and cols and rows:
                h, w = int(m.group(1)) // rows, int(m.group(2)) // cols
                if 4 <= w <= 64 and 8 <= h <= 128:
                    caps.cell_w, caps.cell_h = w, h
        xt = caps.xtversion.lower()
        if xt:
            if "kitty" in xt or "ghostty" in xt or "wezterm" in xt or "foot" in xt:
                caps.truecolor = True
                caps.colors = 256
            name = caps.xtversion.replace("(", " ").replace(")", "")
            caps.name = name if not caps.name or caps.name.startswith("xterm") else f"{name} ({caps.name})"
        if caps.kitty and not caps.truecolor:
            caps.truecolor = True
            caps.colors = 256
        # leftovers (rare) are kept so they don't show up as keystrokes
        rest = re.sub(rb"\x1b_G[^\x1b]*\x1b\\|\x1bP[^\x1b]*\x1b\\|\x1b\[[0-9;?>]*[ct]", b"", got)
        if rest.strip():
            self.buf += rest
        return caps
